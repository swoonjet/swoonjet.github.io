"""Loose knit in bulky wool: big soft loops pulled through each other, row on row.

Built the way it is knitted:

  yarn     thick, soft, lightly twisted plies with a halo of loose fibre (Twist, Fuzz)
  stitch   every stitch is a loop pulled through the loop below; from the front it shows as a V,
           its two legs leaning in, the bottom of the V tucked behind the row underneath
  gauge    on big needles the loops stand apart and the ground shows between them (Loose)
  hand     no two stitches are pulled quite the same: they lean, swell and wander (Uneven)
  pattern  columns of purl (the loop seen from the back, a bump across) make a rib; the yarn
           can be changed every few rows (Stripes, to the second colour)

On the strokes each stroke is a knitted strip, rows stacked across it; on its own ("Swatch") it is
one piece of fabric hanging in soft folds. Lengths are in pixels (f = pixels per reference px).
"""
import numpy as np

import stone
from crochet import _capsule
from fields import blur, fbm, hash1
from shag import recolour

UV = True
KEYS = ("kn_stitch", "kn_loose", "kn_uneven", "kn_twist", "kn_fuzz", "kn_rib")
SHADE_KEYS = ("kn_stripes",)


def _tube(X, Y, a, b, r, twist, lift_a, lift_b):
    """Height of a round yarn tube from a to b over (X, Y), with its plies and a lean in height."""
    d, along, side = _capsule(X, Y, a, b, r)
    L = np.hypot(b[0] - a[0], b[1] - a[1]) + 1e-6
    r = r * (0.72 + 0.38 * np.sin(np.pi * np.clip(along / L, 0, 1)))  # a loop is plump in the middle
    prof = np.sqrt(np.clip(1 - (d / r) ** 2, 0, 1))
    ply = np.sin(2 * np.pi * (along / (0.6 * r) + side * d / r * 0.6))
    h = lift_a + (lift_b - lift_a) * along / L + r * prof * (1 + twist * 0.07 * ply)
    return np.where(d < r, h, -np.inf)


def surface(p, base, theta, f, uv=None):
    H, W = base.shape
    sw = p["kn_stitch"] * f
    rh = sw * 0.74
    loose = p["kn_loose"]
    r = sw * 0.3 * (1 - 0.35 * loose)
    if uv is None or p["host"] == "slab":  # a hanging swatch: rows across the page, sagging in folds
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        sag = fbm(W, H, 700 * f, p["seed"] + 2, 2) * 40 * f
        X, Yr = xx + fbm(W, H, 500 * f, p["seed"] + 4, 2) * 18 * f, yy + sag
        on = np.ones((H, W), bool)
        drape = fbm(W, H, 420 * f, p["seed"], 3) * 30 * f
    else:
        uu, vv, hh = uv
        on = np.isfinite(vv)
        X, Yr = uu, np.where(on, vv + hh, 0)
        drape = 0
    row = np.floor(Yr / rh)
    # the hand: each stitch pulled a little differently
    un = p["kn_uneven"]
    col = np.floor(X / sw)
    jx = un * 0.12 * sw * (hash1(col * 1.31 + row * 7.7 + p["seed"]) - 0.5) * 2
    col = np.floor((X + jx) / sw)
    fx = (X + jx) / sw - col
    Yl = Yr - row * rh
    Xl = fx * sw
    swell = 1 + un * 0.18 * (hash1(col * 3.7 + row * 1.9) - 0.5) * 2
    rr = r * swell
    tw = p["kn_twist"]
    rib = int(p["kn_rib"])
    purl = ((col // rib) % 2 == 1) if rib > 0 else np.zeros_like(col, bool)
    ground = np.full((H, W), -1.4 * r, np.float32)
    yarn = ground.copy()
    for dy in (-rh, 0.0, rh):  # this row, and the loops of the rows either side that reach into it
        Y = Yl - dy
        # knit: the V, its legs leaning in, the bottom tucked behind the row below
        for side in (-1, 1):
            a = (0.5 * sw + side * 0.06 * sw, -0.18 * rh)
            b = (0.5 * sw + side * 0.3 * sw, 1.05 * rh)
            h = _tube(Xl, Y, a, b, rr, tw, -0.5 * r, 0.35 * r)
            yarn = np.where(~purl & (h > yarn), h, yarn)
        # purl: the bump of the loop seen from the back, across
        h = _tube(Xl, Y, (-0.05 * sw, 0.55 * rh), (1.05 * sw, 0.55 * rh), rr * 1.05, tw, 0.2 * r, 0.2 * r)
        h2 = _tube(Xl, Y, (0.1 * sw, 0.05 * rh), (0.9 * sw, 0.05 * rh), rr * 0.8, tw, -0.4 * r, -0.4 * r)
        yarn = np.where(purl & (np.maximum(h, h2) > yarn), np.maximum(h, h2), yarn)
    # the halo: loose fibre standing off the yarn, half filling the gaps
    fz = p["kn_fuzz"]
    halo = blur(np.maximum(yarn, ground), 0.12 * sw) - 0.35 * r
    yarn = np.maximum(yarn, halo * min(fz, 1) + ground * (1 - min(fz, 1)))
    yarn += fz * 0.1 * r * fbm(W, H, 2.5 * f, p["seed"] + 19, 2)
    z = base + drape + np.where(on, yarn, -1.6 * r)
    return dict(H=z.astype(np.float32), row=np.where(on, row, -1).astype(np.int32), on=on)


def tone(p, S, light, f):
    t = stone.tone(p, S["H"], light, f, local=25 * f)
    t += p["kn_fuzz"] * 0.06 * blur(np.clip(t, 0, 1), 2.5 * f)  # light scatters in the halo
    return np.where(S["on"], t, stone.ground(p, t, 0.03))


def paint(p, img, S, f):
    n = int(p["kn_stripes"])
    if n <= 0:
        return img
    row = S["row"]
    return recolour(img, (row >= 0) & ((row // n) % 2 == 1), p["color"], p["yarn"])
