"""Shared fields for the material modes: noise, cells, splatting, a vortex flow, normals, colour.

Everything works on pixel grids; callers pass sizes in pixels and scales already multiplied by f
(pixels per reference px), so a preview and a full render are the same picture.
"""
import cv2
import numpy as np

from bristle import hash1, hex_rgb, noise1, noise2, smoothstep  # noqa: F401  (re-exported for the modes)


def lin(h):
    """Hex colour -> linear-light RGB 0..1."""
    c = np.array(hex_rgb(h), np.float32) / 255
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def srgb(c):
    """Linear-light RGB 0..1 -> sRGB 0..255 float."""
    c = np.clip(c, 0, 1)
    return np.where(c <= 0.0031308, c * 12.92, 1.055 * c ** (1 / 2.4) - 0.055) * 255


def fbm(W, H, scale, seed, octaves=4):
    """Smooth value-noise fbm in about -1..1, features ~scale px. Worked out on a coarse grid and
    resized, since nothing in it is finer than its last octave."""
    step = max(1.0, scale / (3 * 2 ** (octaves - 1)))
    gw, gh = int(np.ceil(W / step)) + 2, int(np.ceil(H / step)) + 2
    ys, xs = np.mgrid[0:gh, 0:gw].astype(np.float64)
    x, y = xs * step / scale, ys * step / scale
    out = np.zeros((gh, gw))
    amp, tot = 1.0, 0.0
    for o in range(octaves):  # each octave turned a little, so the value-noise grid never lines up
        a = 0.62 + 1.1 * o + seed * 0.37
        xr, yr = x * np.cos(a) - y * np.sin(a), x * np.sin(a) + y * np.cos(a)
        out += amp * (noise2(xr * 2 ** o + seed * 17.31 + o * 31.7, yr * 2 ** o + seed * 9.13 - o * 13.3) - 0.5) * 2
        tot += amp
        amp *= 0.5
    out = cv2.resize((out / tot * 1.6).astype(np.float32), (int(gw * step), int(gh * step)), interpolation=cv2.INTER_CUBIC)
    if step > 2:  # cubic upsampling leaves seams along the coarse grid that curvature shading picks up
        out = cv2.GaussianBlur(out, (0, 0), 0.6 * step)
    return out[:H, :W]


def worley(W, H, cell, rng, theta=None, stretch=1.0):
    """Jittered cells: distance to the nearest and second-nearest point, and the nearest's id.
    With theta (a per-pixel angle) the metric is drawn out by stretch along it."""
    pad = 2
    gw, gh = int(W / cell) + 2 * pad + 1, int(H / cell) + 2 * pad + 1
    cx = (np.arange(gw)[None, :] - pad + 0.5 + 0.8 * (rng.random((gh, gw)) - 0.5)) * cell
    cy = (np.arange(gh)[:, None] - pad + 0.5 + 0.8 * (rng.random((gh, gw)) - 0.5)) * cell
    d1 = np.empty((H, W), np.float32)
    d2 = np.empty((H, W), np.float32)
    nid = np.empty((H, W), np.int32)
    reach = range(-1, 2) if stretch <= 1.0 else range(-2, 3)
    for r0 in range(0, H, 512):
        r1 = min(H, r0 + 512)
        ys, xs = np.mgrid[r0:r1, 0:W].astype(np.float32)
        gi, gj = (xs / cell).astype(int) + pad, (ys / cell).astype(int) + pad
        a = np.full(xs.shape, 1e9, np.float32)
        b = a.copy()
        idn = np.zeros(xs.shape, np.int32)
        if theta is not None:
            ct, st = np.cos(theta[r0:r1]), np.sin(theta[r0:r1])
        for oj in reach:
            for oi in reach:
                j, i = np.clip(gj + oj, 0, gh - 1), np.clip(gi + oi, 0, gw - 1)
                dx, dy = xs - cx[j, i], ys - cy[j, i]
                if theta is not None:
                    dx, dy = (dx * ct + dy * st) / stretch, -dx * st + dy * ct
                d = np.hypot(dx, dy)
                closer = d < a
                b = np.where(closer, a, np.minimum(b, d))
                idn = np.where(closer, j * gw + i, idn)
                a = np.where(closer, d, a)
        d1[r0:r1], d2[r0:r1], nid[r0:r1] = a, b, idn
    return d1, d2, nid


def deposit(buf, x, y, w=None):
    """Add w (or 1) at the nearest pixel of each (x, y), in place. One bincount, so millions are cheap."""
    H, W = buf.shape
    xi, yi = np.rint(x).astype(np.int64), np.rint(y).astype(np.int64)
    ok = (xi >= 0) & (xi < W) & (yi >= 0) & (yi < H)
    wt = None if w is None else (np.broadcast_to(w, x.shape)[ok])
    buf += np.bincount(yi[ok] * W + xi[ok], weights=wt, minlength=W * H).reshape(H, W).astype(np.float32)


class Vortices:
    """The sum of a few vortices (same law as gart's VectorField.vortex), vectorised over points."""

    def __init__(self, rng, W, H, eyes, inside=False):
        S = min(W, H)
        self.v = []
        for _ in range(max(1, int(eyes))):
            if inside:
                x, y = rng.uniform(0.15, 0.85) * W, rng.uniform(0.15, 0.85) * H
            else:
                while True:
                    x, y = W * rng.uniform(-0.4, 1.4), H * rng.uniform(-0.4, 1.4)
                    if max(-x, x - W, -y, y - H) > 0.08 * S:
                        break
            sign = rng.choice([-1, 1]) if inside else 1  # spun centres turn either way
            self.v.append((x, y, -rng.uniform(0.6, 1.4) * sign, (S * 0.3 * rng.uniform(0.7, 1.3)) ** 2))

    def __call__(self, x, y):
        vx, vy = np.zeros_like(x), np.zeros_like(y)
        for cx, cy, spin, r2max in self.v:
            dx, dy = x - cx, y - cy
            r2 = dx * dx + dy * dy + 1e-6
            w = 1 / (1 + r2 / r2max) / np.sqrt(r2)
            vx -= dy * spin * w
            vy += dx * spin * w
        return vx, vy

    def angle(self, W, H, step=16):
        """The flow's direction at every pixel, from a coarse grid."""
        gy, gx = np.mgrid[0:H + step:step, 0:W + step:step].astype(np.float32)
        vx, vy = self(gx, gy)
        th = np.arctan2(vy, vx)
        c = cv2.resize(np.cos(th), (W, H), interpolation=cv2.INTER_LINEAR)
        s = cv2.resize(np.sin(th), (W, H), interpolation=cv2.INTER_LINEAR)
        return np.arctan2(s, c).astype(np.float32)


def normals(Hf, relief=1.0):
    gy, gx = np.gradient(Hf.astype(np.float32))
    n = np.dstack([-gx * relief, -gy * relief, np.ones_like(gx)])
    return n / np.linalg.norm(n, axis=2, keepdims=True)


def light3(light):
    return np.array([light[0], light[1], np.sqrt(max(1 - (light ** 2).sum(), 0))], np.float32)


def blur(a, sigma):
    return cv2.GaussianBlur(a, (0, 0), max(0.3, float(sigma)))


def strokes_sample(geo, n, rng, spread=1.0):
    """n points on the strokes, uniform by area: positions and the stroke direction there."""
    pts, nrm, arc, half, ex = geo
    w = half * np.r_[np.hypot(*np.diff(pts, axis=0).T), 0.0]
    k = rng.choice(len(pts), n, p=w / w.sum())
    v = rng.uniform(-1, 1, n) * spread
    xy = pts[k] + nrm[k] * (v * half[k])[:, None]
    return xy, np.arctan2(-nrm[k, 0], nrm[k, 1])
