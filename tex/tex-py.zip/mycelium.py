"""Mycelium: a fungus spreading through its ground as a net of white threads.

Built in the order it grows:

  spore    it starts from a few spots (Starts) and sends out threads (hyphae) in every direction
  grow     every thread grows at its tip, wavering (Wander), and now and then forks (Branching);
           a tip that runs into ground already full of threads stops there and fuses (Density),
           so the net fills the ground without piling up; on the strokes it keeps to them and
           leans along them
  cords    the oldest threads, near where it started, carry the most and thicken into cords
           (Cords); the young margin stays fine and fluffy (Glow)

The growth runs in reference px, so a preview and a full render grow the same net.
"""
import numpy as np

from fields import blur, deposit, fbm
import stone

KEYS = ("my_seeds", "my_time", "my_branch", "my_wander", "my_density")
SHADE_KEYS = ("my_cords", "my_glow")
STEP = 2.5  # reference px a tip grows each step


def _grow(p, mask, theta, f, rng):
    """Segments (x0, y0, x1, y1 in reference px) and the step each was laid down."""
    H, W = mask.shape
    Wr, Hr = W / f, H / f
    cell = 3.0
    occ = np.zeros((int(Hr / cell) + 2, int(Wr / cell) + 2), np.int16)
    ys, xs = np.nonzero(mask[::8, ::8])
    if not len(xs):
        return np.zeros((0, 4)), np.zeros(0)
    k = max(1, int(p["my_seeds"]))
    pick = rng.integers(0, len(xs), k)
    sx, sy = xs[pick] * 8 / f, ys[pick] * 8 / f
    m = 14
    x = np.repeat(sx, m).astype(np.float64)
    y = np.repeat(sy, m).astype(np.float64)
    h = rng.uniform(0, 2 * np.pi, k * m)
    segs, when = [], []
    T = int(p["my_time"])
    lim = int(p["my_density"])
    slab = p["host"] == "slab"
    for t in range(T):
        if not len(x):
            break
        h = h + rng.normal(0, 0.12 * p["my_wander"], len(h))
        if not slab:  # lean along the strokes
            th = theta[np.clip((y * f).astype(int), 0, H - 1), np.clip((x * f).astype(int), 0, W - 1)]
            d = np.angle(np.exp(1j * (th - h)))
            d = np.where(np.abs(d) > np.pi / 2, np.angle(np.exp(1j * (th + np.pi - h))), d)
            h = h + 0.08 * d
        nx, ny = x + np.cos(h) * STEP, y + np.sin(h) * STEP
        inb = (nx >= 0) & (nx < Wr) & (ny >= 0) & (ny < Hr)
        ok = inb & mask[np.clip((ny * f).astype(int), 0, H - 1), np.clip((nx * f).astype(int), 0, W - 1)]
        ci, cj = np.clip((ny / cell).astype(int), 0, occ.shape[0] - 1), np.clip((nx / cell).astype(int), 0, occ.shape[1] - 1)
        oi, oj = (y / cell).astype(int), (x / cell).astype(int)
        moved = (ci != oi) | (cj != oj)
        full = moved & (occ[ci, cj] >= lim)
        live = ok & ~full
        segs.append(np.stack([x, y, nx, ny], 1)[ok])  # a tip that hits the net still reaches it, and fuses
        when.append(np.full(ok.sum(), t))
        np.add.at(occ, (ci[live & moved], cj[live & moved]), 1)
        x, y, h = nx[live], ny[live], h[live]
        fork = rng.random(len(x)) < 0.05 * p["my_branch"]
        if fork.any():
            side = rng.choice([-1, 1], fork.sum()) * rng.uniform(0.4, 1.0, fork.sum())
            x, y, h = np.r_[x, x[fork]], np.r_[y, y[fork]], np.r_[h, h[fork] + side]
        if len(x) > 8000:
            keep = rng.permutation(len(x))[:8000]
            x, y, h = x[keep], y[keep], h[keep]
    if not segs:
        return np.zeros((0, 4)), np.zeros(0)
    return np.concatenate(segs), np.concatenate(when).astype(np.float32)


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 201)
    slab = p["host"] == "slab"
    mask = np.ones((H, W), bool) if slab else base > 0.5 * f
    seg, when = _grow(p, mask, theta, f, rng)
    T = max(1.0, float(p["my_time"]))
    # the threads, splatted along their length; the old ones carry more
    fine = np.zeros((H, W), np.float32)
    cord = np.zeros((H, W), np.float32)
    if len(seg):
        q = max(2, int(np.ceil(STEP * f / 0.7)))
        for s in np.linspace(0, 1, q, endpoint=False):
            px = (seg[:, 0] + (seg[:, 2] - seg[:, 0]) * s) * f
            py = (seg[:, 1] + (seg[:, 3] - seg[:, 1]) * s) * f
            deposit(fine, px, py)
            deposit(cord, px, py, (1 - when / T) ** 2)
    z = base.copy()
    if slab:  # damp ground: crumbs of soil and wood
        z += fbm(W, H, 40 * f, p["seed"], 4) * 4 * f + fbm(W, H, 400 * f, p["seed"] + 1, 2) * 10 * f
    return dict(H=z.astype(np.float32), fine=fine, cord=cord)


def tone(p, S, light, f):
    fine, cord = S["fine"], S["cord"]
    t = stone.tone(p, S["H"], light, f, local=50 * f) * 0.55  # the ground, kept dark under the net
    # threads: log density, so a single hypha shows and a cord does not burn out
    k = 3.5 * f  # a blurred line's peak falls as 1/f; this keeps the net the same at any size
    lf = np.log1p(blur(fine, 0.5 * f) * k) / np.log1p(30)
    lc = np.log1p(blur(cord, 1.2 * f) * k) / np.log1p(30)
    glow = blur(lf, 4 * f)
    net = np.clip(0.75 * lf + p["my_cords"] * 0.5 * lc + p["my_glow"] * 0.6 * glow, 0, 1.1)
    return t + (1.0 - t) * net
