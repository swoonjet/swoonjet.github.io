"""Elephant skin: thick, deeply wrinkled hide, cracked into a net that holds water and mud.

Built in the order the skin is made and used:

  folds    the skin is loose over the body and bends where it moves: long deep folds across the
           way it bends (the flow), with many shallower ones between, tapering at the ends
  net      the outer layer is too thick to stretch, so it splits into a network of channels; the
           plates between bulge up like cushions, drawn out across the flow; a finer net runs
           inside every plate. The channels wander, they never run straight
  mud      after a wallow, mud dries in the channels and the folds and stays there, lighter than
           the skin; on top it rubs off (Dust)
  hair     a few stiff bristles, here and there

surface() returns the height and where the channels are, for the dust.
"""
import cv2
import numpy as np

import stone
from fields import blur, fbm, hex_rgb, smoothstep, worley
from leather import _creases

KEYS = ("el_plate", "el_fine", "el_depth", "el_folds", "el_fold_depth", "el_bulge")
SHADE_KEYS = ("el_dust",)


def _wander(a, W, H, f, amount, seed):
    """Push a field around by smooth noise, so the cracks of a cell pattern meander."""
    dx = fbm(W, H, 90 * f, seed, 3) * amount
    dy = fbm(W, H, 90 * f, seed + 1, 3) * amount
    mx, my = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    return cv2.remap(a, mx + dx, my + dy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 111)
    z = base.copy()
    if p["host"] == "slab":  # the round of the body under it
        z += fbm(W, H, 900 * f, p["seed"], 2) * 60 * f
    across = theta + np.float32(np.pi / 2)

    # folds across the bend
    deep, fine = _creases(W, H, theta, f, rng, p["el_folds"], long=(260, 900), short=(60, 240), big_share=0.4,
                          thick=(6.0, 2.6), per=9000)
    deep, fine = blur(deep, 4 * f), blur(fine, 1.8 * f)
    z -= p["el_fold_depth"] * (16 * f * deep + 6 * f * fine)
    z += p["el_fold_depth"] * 4 * f * (blur(deep, 14 * f) - deep).clip(0)

    # the net: cushions between wandering channels, drawn out across the flow
    cell = p["el_plate"] * f
    d1, d2, _ = worley(W, H, cell, rng, across, 1.5)
    e = _wander((d2 - d1) * 0.5, W, H, f, 0.25 * cell, p["seed"] + 3)
    crev = np.exp(-(e / (1.3 * f)) ** 2)
    z += p["el_bulge"] * 7 * f * smoothstep(0, 0.45 * cell, e) ** 0.7
    z -= p["el_depth"] * 7 * f * crev
    cf = p["el_fine"] * f
    f1, f2, _ = worley(W, H, cf, rng)
    e2 = _wander((f2 - f1) * 0.5, W, H, f, 0.3 * cf, p["seed"] + 5)
    crev2 = np.exp(-(e2 / (0.8 * f)) ** 2)
    z += p["el_bulge"] * 1.6 * f * smoothstep(0, 0.4 * cf, e2) * smoothstep(0, 0.2 * cell, e)
    z -= p["el_depth"] * 2.2 * f * crev2
    z += 0.5 * f * fbm(W, H, 6 * f, p["seed"] + 7, 2)  # the skin itself is never smooth
    mud = np.clip(crev + 0.5 * crev2 + 1.2 * deep + 0.4 * fine, 0, 1)
    return dict(H=z, mud=mud)


def tone(p, S, light, f):
    z, mud = S["H"], S["mud"]
    H, W = z.shape
    t = stone.tone(p, z, light, f, local=50 * f)
    patch = smoothstep(-0.1, 0.5, fbm(W, H, 260 * f, p["seed"] + 9, 3))  # it has dried thicker in places
    t += p["el_dust"] * (0.34 * mud * (0.5 + 0.5 * patch) + 0.07 * patch)
    return t


def paint(p, img, S, f):
    """A few stiff dark bristles."""
    if p["el_hairs"] <= 0:
        return img
    H, W = img.shape[:2]
    rng = np.random.default_rng(p["seed"] * 31 + 113)
    n = int(p["el_hairs"] * W * H / (f * f) / 9000)
    col = tuple(int(c * 0.6) for c in hex_rgb(p["dark"]))
    for _ in range(n):
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        a, l = rng.uniform(0, 2 * np.pi), rng.uniform(8, 26) * f
        bx, by = x + np.cos(a) * l * 0.5, y + np.sin(a) * l * 0.5 + rng.normal(0, 2 * f)
        ex, ey = x + np.cos(a) * l, y + np.sin(a) * l
        pts = np.array([[x, y], [bx, by], [ex, ey]]) * 16
        cv2.polylines(img, [pts.astype(np.int32)], False, col, max(1, int(0.9 * f)), cv2.LINE_AA, shift=4)
    return img
