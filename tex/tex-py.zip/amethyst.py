"""Amethyst: the inside of a geode, packed with the points of purple quartz crystals.

Built the way it grows:

  points    quartz grows as six-sided prisms capped by a six-sided point; seen from inside the
            geode you look down onto a crowd of those points, big and small (Size, Density)
  lean      few stand straight up: most lean over, so one side of the prism shows as a long face
            running back from the point, below the steeper faces of the cap (Lean, Sharpness)
  crowd     they grow into each other, every crystal cut off where a neighbour stands higher, so
            nothing else shows between them; on the strokes they lean along them (Alignment)
  colour    the purple sits in the tips and fades toward milky white quartz at the base (Zoning);
            light goes into the stone and comes back out of the deep, coloured (Clarity)

Off the strokes the geode's wall shows: grey-blue chalcedony in fine bands. On its own ("Geode")
the whole page is crystals.
"""
import cv2
import numpy as np

from fields import blur, fbm, hash1, light3, normals

KEYS = ("am_size", "am_density", "am_lean", "am_sharp", "am_align")
SHADE_KEYS = ("am_zone", "am_clarity")


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 211)
    slab = p["host"] == "slab"
    on = np.ones((H, W), bool) if slab else base > 0.5 * f
    z = base + fbm(W, H, 300 * f, p["seed"], 3) * 6 * f  # the wall the crystals grow from
    floor = z.copy()
    cid = np.full((H, W), -1, np.int32)
    L0 = p["am_size"] * f
    ys, xs = np.nonzero(on[::4, ::4])
    if not len(xs):
        return dict(H=z.astype(np.float32), cid=cid, rise=np.zeros((H, W), np.float32), on=on)
    n = int(min(20000, p["am_density"] * on.sum() / (0.35 * L0 * L0)))
    pick = rng.integers(0, len(xs), n)
    order = np.argsort(rng.random(n))
    six = np.arange(6) * np.pi / 3
    sharp = p["am_sharp"]
    frac = np.zeros((H, W), np.float32)
    for i, j in enumerate(order):
        cx = xs[pick[j]] * 4 + rng.uniform(0, 4)
        cy = ys[pick[j]] * 4 + rng.uniform(0, 4)
        r = L0 * np.exp(rng.normal(0, 0.35)) * 0.5  # the width of the prism
        xi, yi = int(np.clip(cx, 0, W - 1)), int(np.clip(cy, 0, H - 1))
        a = theta[yi, xi] + rng.normal(0, 0.3) if (not slab and rng.random() < p["am_align"]) else rng.uniform(0, 2 * np.pi)
        lean = p["am_lean"] * rng.uniform(0.1, 1.0)
        hc = 0.9 * r * sharp  # the cap
        hp = 0.7 * L0 * rng.uniform(0.6, 1.0)  # the prism: about as long whatever its width, so small ones poke up too
        tip = hp + hc
        body = r + 2.5 * L0 * lean  # how far the leaning prism runs back from the point
        R = int(body + r + 3)
        x0, x1, y0, y1 = max(0, int(cx) - R), min(W, int(cx) + R + 1), max(0, int(cy) - R), min(H, int(cy) + R + 1)
        if x0 >= x1 or y0 >= y1:
            continue
        dx = np.arange(x0, x1, dtype=np.float32)[None, :] - cx
        dy = np.arange(y0, y1, dtype=np.float32)[:, None] - cy
        u = dx * np.cos(a) + dy * np.sin(a)  # along the lean: the point at 0, the prism behind (u < 0)
        v = -dx * np.sin(a) + dy * np.cos(a)
        spin = rng.integers(0, 2) * np.pi / 6  # a face or an edge toward the lean
        hexd = np.max([u * np.cos(s + spin) + v * np.sin(s + spin) for s in six], axis=0)
        h = np.where(hexd < r, tip - hc * hexd / r, -np.inf)  # the six faces of the point
        if lean > 0.05:  # the top of the leaning prism: two long faces meeting in a ridge
            pr = hp * (1 + u / body) - 0.35 * np.abs(v) * hp / body
            h = np.maximum(h, np.where((u < 0) & (u > -body) & (np.abs(v) < 0.87 * r), pr, -np.inf))
        zz = z[y0:y1, x0:x1]
        hb = floor[y0:y1, x0:x1] + h
        top = (h > 0) & (hb > zz) & on[y0:y1, x0:x1]
        zz[top] = hb[top]
        cid[y0:y1, x0:x1][top] = i
        frac[y0:y1, x0:x1][top] = (h / tip)[top]
    rise = frac  # how far up its crystal a point is: 0 at the base, 1 at the tip
    return dict(H=z.astype(np.float32), cid=cid, rise=rise.astype(np.float32), on=on)


def tone(p, S, light, f):
    z, cid, rise, on = S["H"], S["cid"], S["rise"], S["on"]
    H, W = z.shape
    n = normals(z, p["relief"])
    L = light3(light)
    lam = np.clip(n @ L, 0, 1)
    hv = L + np.array([0, 0, 1], np.float32)
    hv /= np.linalg.norm(hv)
    nh = np.clip(n @ hv, 0, 1)
    has = cid >= 0
    c = np.clip(cid, 0, None)
    # flat facets, each lit at its own angle; the deep between crystals in shadow
    cl = p["am_clarity"]
    glow = blur(np.clip(rise, 0, 1), 3 * f)  # light coming back out of the stone
    t = 0.1 + 0.42 * lam + cl * 0.2 * glow + 0.07 * (hash1(c * 0.93 + p["seed"]) - 0.5) * 2
    t *= 1 - p["outline"] * 0.4 * (1 - np.clip(rise * 1.5, 0, 1))
    t += p["glint"] * 2.4 * nh ** 90 + 0.12 * nh ** 12
    # the wall: grey-blue chalcedony in fine bands
    if not on.all():
        dist = cv2.distanceTransform((~on).astype(np.uint8), cv2.DIST_L2, 5)
        band = 0.5 + 0.5 * np.sin(dist / (3.5 * f) + fbm(W, H, 60 * f, p["seed"] + 5, 2) * 3)
        wall = 0.3 + 0.18 * band + 0.25 * (lam - L[2])
        t = np.where(has, t, wall)
    return t


def paint(p, img, S, f):
    """The colour sits in the tips: toward the base it fades to milky quartz; the wall is grey-blue."""
    im = img.astype(np.float32)
    lum = im.mean(2, keepdims=True)
    w = p["am_zone"] * np.clip(1.35 - S["rise"] * 1.6, 0, 1) ** 1.2
    milk = lum * 1.08 + 14
    out = im * (1 - w[..., None]) + milk * w[..., None]
    off = (S["cid"] < 0)[..., None]
    out = np.where(off, lum * np.array([0.9, 0.96, 1.06], np.float32), out)
    return np.clip(out, 0, 255).astype(np.uint8)
