"""Old leather: a hide that has been folded, dried out and polished for decades.

Built in the order things happened to the hide:

  grain    the animal's skin: pebbled cells with grooves between them, drawn out a little
           along the way the hide was stretched (the flow), and hair-follicle pores
  creases  every time the strap bent it creased across; a few deep folds, many fine ones
           between, each traced across the flow from where it started
  cracks   where it dried out most, the finish shrank and split into a craquelure of plates
           whose edges curl up
  wear     hands polished the high points smooth and light; grime and old dye settled in
           every low point (the patina); water and oil left stains

Heights are in pixels; f = pixels per reference px. surface() is the hide, tone() its finish.
"""
import cv2
import numpy as np

import stone
from fields import blur, fbm, hash1, smoothstep, worley

KEYS = ("lea_grain", "lea_grain_h", "lea_creases", "lea_crease_depth", "lea_cracks", "lea_crack_size", "lea_wear")
SHADE_KEYS = ("lea_wear", "lea_stain")


def _creases(W, H, theta, f, rng, amount, long=(80, 260), short=(14, 70), big_share=0.2, thick=(2.6, 1.3), per=5000):
    """Deep folds and fine creases, traced across the flow, tapering at both ends."""
    deep = np.zeros((H, W), np.uint8)
    fine = np.zeros((H, W), np.uint8)
    n = int(amount * W * H / (f * f) / per)
    for _ in range(n):
        big = rng.random() < big_share
        length = (rng.uniform(*long) if big else rng.uniform(*short)) * f
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        step = 2.0 * f
        line = [(x, y)]
        for sgn in (1, -1):  # out both ways from where it started
            px, py = x, y
            wob = 0.0
            for _ in range(int(length / 2 / step)):
                th = theta[int(np.clip(py, 0, H - 1)), int(np.clip(px, 0, W - 1))] + np.pi / 2
                wob += rng.normal(0, 0.06)
                px += sgn * np.cos(th + wob) * step
                py += sgn * np.sin(th + wob) * step
                if sgn > 0:
                    line.append((px, py))
                else:
                    line.insert(0, (px, py))
        pts = np.array(line)
        m = len(pts)
        th_max = (thick[0] if big else thick[1]) * f
        layer = deep if big else fine
        for i in range(m - 1):  # thickest in the middle of the fold
            t = abs(i / max(m - 2, 1) - 0.5) * 2
            w = max(1, int(round(th_max * (1 - t * t))))
            cv2.line(layer, tuple(np.int32(pts[i])), tuple(np.int32(pts[i + 1])), 255, w, cv2.LINE_AA)
    return deep.astype(np.float32) / 255, fine.astype(np.float32) / 255


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 31)
    z = base.copy()
    if p["host"] == "slab":  # a hide lying flat, but never quite flat
        z += fbm(W, H, 700 * f, p["seed"], 2) * 30 * f  # broad sag only: mid-size lumps read as blotches

    # grain: pebbles drawn out along the stretch, at slightly different heights, pores between
    cell = p["lea_grain"] * f
    d1, d2, cid = worley(W, H, cell, rng, theta, 1.35)
    pebble = smoothstep(0, 0.3 * cell, (d2 - d1) * 0.5) * (0.75 + 0.5 * hash1(cid * 0.731 + p["seed"]))
    z += p["lea_grain_h"] * 1.4 * f * pebble
    pores = np.zeros((H, W), np.float32)
    n = int(W * H / (f * f) / 45)
    xi, yi = rng.integers(0, W, n), rng.integers(0, H, n)
    pores[yi, xi] = 1
    z -= p["lea_grain_h"] * 1.8 * f * blur(pores, 0.7 * f) * (0.7 * f) ** 2 * 6.3

    # creases across the flow
    deep, fine = _creases(W, H, theta, f, rng, p["lea_creases"])
    deep, fine = blur(deep, 1.8 * f), blur(fine, 0.8 * f)
    z -= p["lea_crease_depth"] * (5.0 * f * deep + 1.6 * f * fine)
    z += p["lea_crease_depth"] * 1.2 * f * (blur(deep, 6 * f) - deep).clip(0)  # the hide bulges beside a fold

    # craquelure where it dried most: plates, split, edges curling up
    if p["lea_cracks"] > 0:
        c1, c2, _ = worley(W, H, p["lea_crack_size"] * f, rng)
        dry = fbm(W, H, 320 * f, p["seed"] + 5, 3) * 0.5 + 0.5
        mask = smoothstep(1.05 - p["lea_cracks"], 1.25 - p["lea_cracks"], dry)
        gap = (c2 - c1) * 0.5
        z -= mask * 4.0 * f * np.exp(-(gap / (0.9 * f)) ** 2)
        z += mask * 1.2 * f * np.exp(-(gap / (4.0 * f)) ** 2)

    # wear: the high points are rubbed smooth
    w = p["lea_wear"]
    if w > 0:
        high = smoothstep(0, 2.5 * f, z - blur(z, 10 * f))
        z = z + (blur(z, 2.2 * f) - z) * high * min(1.0, w)
    return z


def tone(p, z, light, f):
    H, W = z.shape
    t = stone.tone(p, z, light, f, local=40 * f)
    lift = z - blur(z, 12 * f)
    span = np.percentile(np.abs(lift[::4, ::4]), 98) + 1e-6
    t += p["lea_wear"] * 0.2 * smoothstep(0.1, 0.8, lift / span)  # polished, lighter high points
    t -= p["lea_wear"] * 0.16 * smoothstep(0.1, 0.9, -lift / span)  # patina in the low ones
    if p["lea_stain"] > 0:  # water and oil marks: mottling with a few hard-edged tide lines
        m = fbm(W, H, 260 * f, p["seed"] + 9, 4)
        t += p["lea_stain"] * (0.05 * m - 0.12 * np.exp(-((m - 0.35) / 0.03) ** 2))
    return t
