"""Delaunay triangles: the strokes (or a terrain) rebuilt as a faceted low-poly surface.

The process:

  sample     points are scattered over the form, more of them where it changes fastest (Adapt):
             the edges of the strokes, the bends of the terrain; Regular pushes them apart
  connect    the points are joined into the Delaunay triangulation: of all ways to join them,
             the one whose triangles are least like slivers
  lift       each corner takes the height of the form under it, plus a little of its own (Relief),
             and every triangle is a flat facet between its three corners
  cut        the facets are separated by a fine line or groove (Edges), and each catches the light
             at its own angle, with a little tone of its own (Tones)
"""
import cv2
import numpy as np

from fields import blur, fbm, hash1, light3

KEYS = ("dl_points", "dl_adapt", "dl_regular", "dl_relief")
SHADE_KEYS = ("dl_edges", "dl_tones")


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 191)
    slab = p["host"] == "slab"
    g = base.copy()
    if slab:
        g += fbm(W, H, 500 * f, p["seed"], 4) * 70 * f
    on = np.ones((H, W), bool) if slab else base > 0.5 * f
    # sample: density from how fast the form changes
    gy, gx = np.gradient(blur(g, 6 * f))
    detail = blur(np.hypot(gx, gy), 10 * f)
    dens = (1 - p["dl_adapt"]) + p["dl_adapt"] * detail / (np.percentile(detail[on], 95) + 1e-6) * 2
    dens = np.clip(dens, 0.05, 4) * on
    n = int(p["dl_points"] * on.mean())
    cand = max(n * 6, 10)
    cx, cy = rng.uniform(0, W, cand), rng.uniform(0, H, cand)
    keep = rng.random(cand) * dens.max() < dens[cy.astype(int).clip(0, H - 1), cx.astype(int).clip(0, W - 1)]
    cx, cy = cx[keep][:n * 3], cy[keep][:n * 3]
    # regular: drop points crowding their neighbours (a rough Poisson disc), then keep n
    if p["dl_regular"] > 0 and len(cx):
        r = p["dl_regular"] * 0.7 * np.sqrt(on.sum() / max(n, 1))
        cell = max(r, 1.0)
        taken = {}
        sel = []
        for i, (x, y) in enumerate(zip(cx, cy)):
            k = (int(x / cell), int(y / cell))
            near = [taken[(k[0] + a, k[1] + b)] for a in (-1, 0, 1) for b in (-1, 0, 1) if (k[0] + a, k[1] + b) in taken]
            if all((x - cx[j]) ** 2 + (y - cy[j]) ** 2 > r * r for j in near):
                taken[k] = i
                sel.append(i)
        cx, cy = cx[sel], cy[sel]
    cx, cy = cx[:n], cy[:n]
    # the page's corners and edges, so the triangulation covers it all
    m = max(4, int(np.sqrt(max(n, 1)) / 2))
    ex = np.r_[np.linspace(0, W - 1, m), np.linspace(0, W - 1, m), np.zeros(m), np.full(m, W - 1)]
    ey = np.r_[np.zeros(m), np.full(m, H - 1), np.linspace(0, H - 1, m), np.linspace(0, H - 1, m)]
    px, py = np.r_[cx, ex], np.r_[cy, ey]
    sub = cv2.Subdiv2D((0, 0, W, H))
    for x, y in zip(px, py):
        sub.insert((float(np.clip(x, 0, W - 1)), float(np.clip(y, 0, H - 1))))
    tri = sub.getTriangleList().reshape(-1, 3, 2)
    ok = ((tri[..., 0] >= 0) & (tri[..., 0] <= W) & (tri[..., 1] >= 0) & (tri[..., 1] <= H)).all(1)
    tri = tri[ok]
    # lift every corner: the form under it, plus its own
    xi, yi = tri[..., 0].clip(0, W - 1).astype(int), tri[..., 1].clip(0, H - 1).astype(int)
    zc = g[yi, xi] + p["dl_relief"] * 10 * f * (hash1(tri[..., 0] * 0.0137 + tri[..., 1] * 0.0291 + p["seed"]) - 0.5) * 2
    # plane per triangle: z = a x + b y + c
    A = np.dstack([tri[..., 0], tri[..., 1], np.ones(tri.shape[:2])])
    coef = np.linalg.solve(A + np.eye(3)[None] * 1e-9, zc[..., None])[..., 0]
    tid = np.full((H, W), -1, np.int32)
    for i, t in enumerate(tri):
        cv2.fillConvexPoly(tid, np.round(t * 16).astype(np.int32), i, cv2.LINE_8, shift=4)
    # strokes: only facets whose middle is on the form
    mid = tri.mean(1)
    live = on[mid[:, 1].clip(0, H - 1).astype(int), mid[:, 0].clip(0, W - 1).astype(int)]
    k = np.clip(tid, 0, None)
    has = (tid >= 0) & live[k]
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    z = coef[k, 0] * xx + coef[k, 1] * yy + coef[k, 2]
    edge = np.zeros((H, W), bool)
    edge[:, 1:] |= tid[:, 1:] != tid[:, :-1]
    edge[1:, :] |= tid[1:, :] != tid[:-1, :]
    return dict(H=np.where(has, z, g).astype(np.float32), tid=np.where(has, tid, -1), coef=coef, edge=edge)


def tone(p, S, light, f):
    tid, coef, edge = S["tid"], S["coef"], S["edge"]
    has = tid >= 0
    k = np.clip(tid, 0, None)
    rel = p["relief"]
    n = np.stack([-coef[:, 0] * rel, -coef[:, 1] * rel, np.ones(len(coef))], 1)
    n /= np.linalg.norm(n, axis=1, keepdims=True)
    L = light3(light)
    hv = L + np.array([0, 0, 1])
    hv /= np.linalg.norm(hv)
    face = 0.18 + 0.7 * np.clip(n @ L, 0, 1) + p["glint"] * np.clip(n @ hv, 0, 1) ** 40
    face += p["dl_tones"] * 0.16 * (hash1(np.arange(len(coef)) * 0.618 + p["seed"]) - 0.5) * 2
    t = face[k]
    w = p["dl_edges"] * p["outline"]
    if w > 0:
        line = cv2.dilate(edge.astype(np.uint8), np.ones((3, 3), np.uint8), iterations=max(0, int(round(w * f)) - 1)) if w * f >= 1.5 else edge
        t = np.where(line.astype(bool), t * (1 - min(1.0, w)) * 0.35, t)
    return np.where(has, t, 0.03)
