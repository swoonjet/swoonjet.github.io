"""Crochet: one yarn and a hook, worked stitch by stitch into rows or rounds.

Built the way it is worked:

  yarn     a few plies twisted together into a soft tube (Plumpness, Twist, Fuzz)
  stitch   every stitch is worked into the top of the one below: two legs (the post) rise from it,
           and the loops left on top lie as a V; a taller stitch is longer in the leg and has the
           yarn wrapped once across it (Tall)
  rows     on the strokes the work goes in rows along each stroke, stacked across it, so a stroke
           is a strip of fabric; on its own it is worked in the round: motifs that start at a
           centre and grow by about six stitches a round, the increases that keep a circle flat,
           and stop on a whole round where they meet their neighbours
  lace     in alternate rows some stitches are skipped and a chain is carried over the gap,
           which leaves the holes of lace (Lace)
  colour   the yarn is changed every few rows (Stripes), to the second yarn colour

Lengths are in pixels (f = pixels per reference px). surface() takes the strokes' coordinates (u
along, v across, in px) and returns the height, the row of every pixel and where the holes are.
"""
import numpy as np

import stone
from fields import fbm, hash1, smoothstep
from forms import _spread
from shag import recolour

UV = True
KEYS = ("cr_stitch", "cr_tall", "cr_lace", "cr_plump", "cr_twist", "cr_fuzz", "cr_motifs")
SHADE_KEYS = ("cr_stripes",)


def _rounds(p, W, H, sw, rh):
    """Motifs worked in the round: along (px), up (px into its round), round number, motif id."""
    rng = np.random.default_rng(p["seed"] * 7919 + 121)
    m = max(1, int(p["cr_motifs"]))
    S = min(W, H)
    C = _spread(rng, m, W, H, 0.05 * S)
    nn = np.array([np.min(np.hypot(*(np.delete(C, i, 0) - c).T)) if m > 1 else 2 * S for i, c in enumerate(C)])
    R = np.maximum(rh * 2, rh * np.round(0.5 * nn * rng.uniform(1.0, 1.12, m) / rh))  # finished on a whole round
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    best = np.full((H, W), np.inf, np.float32)
    X = np.zeros((H, W), np.float32)
    Y = np.zeros((H, W), np.float32)
    row = np.full((H, W), -1, np.int32)
    mid = np.full((H, W), -1, np.int32)
    for i, ((cx, cy), Rc) in enumerate(zip(C, R)):
        dx, dy = xx - cx, yy - cy
        r = np.hypot(dx, dy)
        q = r / Rc
        mine = (q < 1) & (q < best)
        if not mine.any():
            continue
        k = np.floor(r / rh)
        nk = np.maximum(6, np.round(2 * np.pi * (k + 0.5) * rh / sw))  # about six more stitches every round
        a = (np.arctan2(dy, dx) / (2 * np.pi) + 0.5 + hash1(k * 1.7 + i) * 0.5) * nk
        best = np.where(mine, q, best)
        X = np.where(mine, a * sw, X)
        Y = np.where(mine, r - k * rh, Y)
        row = np.where(mine, k.astype(np.int32), row)
        mid = np.where(mine, i, mid)
    return X, Y, row, mid


def _capsule(X, Y, a, b, r):
    """Distance from (X, Y) to segment a-b, how far along it (0..1), and which side."""
    (ax, ay), (bx, by) = a, b
    vx, vy = bx - ax, by - ay
    l2 = vx * vx + vy * vy + 1e-9
    t = np.clip(((X - ax) * vx + (Y - ay) * vy) / l2, 0, 1)
    px, py = X - ax - t * vx, Y - ay - t * vy
    return np.hypot(px, py), t * np.sqrt(l2), np.sign(px * vy - py * vx)


def surface(p, base, theta, f, uv=None):
    H, W = base.shape
    sw = p["cr_stitch"] * f
    rh = sw * (0.8 + 0.9 * p["cr_tall"])
    ry = min(0.17 * sw * p["cr_plump"], 0.32 * rh)
    if uv is None or p["host"] == "slab":  # in the round
        X, Y, row, mid = _rounds(p, W, H, sw, rh)
        on = row >= 0
    else:  # in rows along the strokes, stacked across them
        uu, vv, hh = uv
        on = np.isfinite(vv)
        y = np.where(on, vv + hh, 0)
        r = np.floor(y / rh)
        row = np.where(on, r, -1).astype(np.int32)
        X, Y = uu, y - r * rh
        mid = np.zeros((H, W), np.int32)
    st = np.floor(X / sw)
    fx = X / sw - st
    Xl, Yl = fx * sw, Y
    vb = max(rh - 0.42 * sw, 0.35 * rh)  # where the V of loops sits on its legs
    tubes = [((0.5, vb), (0.03, rh - 0.04 * sw), 0.55, 1.0),  # the V on top
             ((0.5, vb), (0.97, rh - 0.04 * sw), 0.55, 1.0),
             ((0.34, vb), (0.38, -0.05 * rh), 0.0, 1.0),  # the two legs
             ((0.66, vb), (0.62, -0.05 * rh), 0.0, 1.0)]
    if p["cr_tall"] > 0.3:  # yarn over: wrapped once across the leg
        tubes.append(((0.18, 0.62 * vb), (0.82, 0.36 * vb), 0.35, 0.9))
    hole = (row % 2 == 1) & ((st.astype(np.int64) + row // 2) % 3 == 1) & (hash1(row * 0.913 + mid * 3.1 + 0.2) < p["cr_lace"]) & on
    yarn = np.full((H, W), -0.9 * ry, np.float32)
    yarn[hole] = -2.5 * ry
    for (ax, ay), (bx, by), lift, rr in tubes:
        d, along, side = _capsule(Xl, Yl, (ax * sw, ay), (bx * sw, by), ry * rr)
        rad = ry * rr
        inn = d < rad
        prof = np.sqrt(np.clip(1 - (d / rad) ** 2, 0, 1))
        ply = np.sin(2 * np.pi * (along / (0.95 * rad) + side * d / rad * 0.7))  # the plies twist round the tube
        h = lift * ry + rad * prof * (1 + p["cr_twist"] * 0.16 * ply)
        if lift < 0.1:  # the legs are skipped over a hole
            inn = inn & ~hole
        yarn = np.where(inn & (h > yarn), h, yarn)
    # the chain carried over each hole
    d, along, side = _capsule(Xl, Yl, (0.0, 0.55 * rh), (sw, 0.55 * rh), 0.75 * ry)
    prof = np.sqrt(np.clip(1 - (d / (0.75 * ry)) ** 2, 0, 1))
    chain = 0.2 * ry + 0.75 * ry * prof * (1 + p["cr_twist"] * 0.16 * np.sin(2 * np.pi * along / (0.8 * ry)))
    yarn = np.where(hole & (d < 0.75 * ry), np.maximum(yarn, chain), yarn)
    yarn += p["cr_fuzz"] * 0.12 * ry * fbm(W, H, 2.2 * f, p["seed"] + 17, 2)  # loose fibre standing off the yarn
    z = base + np.where(on, yarn, -2.5 * ry)
    return dict(H=z.astype(np.float32), row=row, mid=mid, hole=hole)


def tone(p, S, light, f):
    t = stone.tone(p, S["H"], light, f, local=20 * f)
    return np.where(S["row"] < 0, 0.04 + 0.03 * t, t)  # the table under the work, in shadow


def paint(p, img, S, f):
    """Change yarn every few rows; motifs each start on their own colour."""
    n = int(p["cr_stripes"])
    if n <= 0:
        return img
    row, mid = S["row"], S["mid"]
    m = (row >= 0) & (((row // n) + mid) % 2 == 1)
    return recolour(img, m, p["color"], p["yarn"])
