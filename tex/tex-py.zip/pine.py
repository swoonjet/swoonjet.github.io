"""Pine needles: a forest floor of fallen needles, years of them.

Built in the order it happens:

  fall     needles drop in bundles of two or three held together at the base by a papery sheath;
           the bundle lands and its needles splay a little; they land along the wind (the flow)
           or anyhow (Alignment)
  pile     year on year they pile up, crossing every which way; each needle lies on the ones under
           it, so the later a needle fell the higher it sits (Depth)
  needle   long and thin, half round with a groove along its flat face, the sheath dark at the base
  decay    under the top layer they darken and break into pieces (Decay); the newest few are
           still green (Fresh, in the second colour)

Needles are drawn as line segments into an index buffer, in the order they fell, so the top needle
at each pixel is known; its shape there comes from that segment's geometry.
"""
import cv2
import numpy as np

import stone
from fields import fbm, hash1, smoothstep
from shag import recolour

KEYS = ("pn_density", "pn_length", "pn_width", "pn_align", "pn_depth", "pn_decay")
SHADE_KEYS = ("pn_fresh",)


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 141)
    slab = p["host"] == "slab"
    z0 = base.copy()
    if slab:
        z0 += fbm(W, H, 500 * f, p["seed"], 3) * 14 * f
    on = np.ones((H, W), bool) if slab else base > 0.5 * f
    ys, xs = np.nonzero(on[::4, ::4])
    L0, w0 = p["pn_length"] * f, p["pn_width"] * f
    nb = int(min(40000, p["pn_density"] * len(xs) * 16 / (L0 * w0 * 2.4) * 2.2)) if len(xs) else 0
    pick = rng.integers(0, max(len(xs), 1), nb)
    segs = []  # x0, y0, x1, y1, half width, needle id, t0, t1
    nid = 0
    for b in range(nb):
        cx, cy = xs[pick[b]] * 4 + rng.uniform(0, 4), ys[pick[b]] * 4 + rng.uniform(0, 4)
        th = theta[min(int(cy), H - 1), min(int(cx), W - 1)]
        a = th + rng.normal(0, 0.2) if rng.random() < p["pn_align"] else rng.uniform(0, 2 * np.pi)
        broken = rng.random() < p["pn_decay"] * (1 - b / max(nb, 1)) * 0.8  # the old ones are in pieces
        for k in range(2 if rng.random() < 0.7 else 3):
            l = L0 * np.exp(rng.normal(0, 0.12)) * (rng.uniform(0.2, 0.6) if broken else 1)
            ak = a + rng.normal(0, 0.12) + (k - 0.5) * rng.uniform(0.02, 0.2)
            bend = rng.normal(0, 0.25) / l
            hw = w0 * rng.uniform(0.85, 1.15) / 2
            pts = [(cx, cy)]
            for s in range(1, 5):
                h = ak + bend * l * s / 4
                x, y = pts[-1]
                pts.append((x + np.cos(h) * l / 4, y + np.sin(h) * l / 4))
            for s in range(4):
                segs.append((*pts[s], *pts[s + 1], hw, nid, s / 4, (s + 1) / 4))
            nid += 1
    seg = np.array(segs, np.float64).reshape(-1, 8)
    idx = np.full((H, W), -1, np.float32)
    for i, (x0, y0, x1, y1, hw, *_) in enumerate(seg):  # in the order they fell
        cv2.line(idx, (int(round(x0)), int(round(y0))), (int(round(x1)), int(round(y1))), float(i),
                 max(1, int(round(2 * hw))), cv2.LINE_8)
    k = idx.astype(np.int64)
    has = k >= 0
    k = np.clip(k, 0, None)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    if len(seg) == 0:
        return dict(H=z0, nid=np.full((H, W), -1), t=np.zeros((H, W)), rank=np.zeros((H, W)))
    x0, y0, x1, y1, hw = (seg[k, i].astype(np.float32) for i in range(5))
    dx, dy = x1 - x0, y1 - y0
    l2 = dx * dx + dy * dy + 1e-6
    tt = np.clip(((xx - x0) * dx + (yy - y0) * dy) / l2, 0, 1)
    v = ((xx - x0) * dy - (yy - y0) * dx) / np.sqrt(l2)
    q = np.clip(v / hw, -1, 1)
    # half round, flat face up with a groove along it
    prof = np.sqrt(1 - q * q) * (1 - 0.35 * np.exp(-(q / 0.25) ** 2))
    rank = seg[k, 5].astype(np.float32) / max(nid - 1, 1)
    z = z0 + has * (p["pn_depth"] * 12 * f * rank + hw * 1.1 * prof)
    t_n = seg[k, 6] + tt * (seg[k, 7] - seg[k, 6])
    return dict(H=z.astype(np.float32), nid=np.where(has, seg[k, 5], -1).astype(np.int64), t=t_n.astype(np.float32),
                rank=np.where(has, rank, 0).astype(np.float32))


def tone(p, S, light, f):
    t = stone.tone(p, S["H"], light, f, local=30 * f)
    nid, tn, rank = S["nid"], S["t"], S["rank"]
    has = nid >= 0
    c = np.clip(nid, 0, None)
    t += has * 0.1 * (hash1(c * 0.37 + p["seed"]) - 0.5) * 2
    t -= has * 0.3 * smoothstep(0.06, 0.0, tn)  # the sheath, dark at the base
    t -= p["pn_decay"] * 0.22 * (1 - rank) * has  # rotting underneath
    return np.where(has, t, 0.04 + 0.05 * t)


def paint(p, img, S, f):
    if p["pn_fresh"] <= 0:
        return img
    nid, rank = S["nid"], S["rank"]
    fresh = (nid >= 0) & (rank > 1 - p["pn_fresh"] * 0.6) & (hash1(np.clip(nid, 0, None) * 1.91) < 0.4 + 0.6 * p["pn_fresh"])
    return recolour(img, fresh, p["color"], p["yarn"])
