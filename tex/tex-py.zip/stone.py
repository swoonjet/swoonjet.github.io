"""Pumice: the strokes (or a plain slab) turned to porous stone. The atom is the void.

Pumice is frozen foam, and the stone is only the walls left between gas bubbles. So the thing laid
down here is the bubble: an ellipsoid with a power-law size (many small, few big), stretched along
the flow under it the way real vesicles are drawn out along the lava's flow. The host surface is a
height field (each stroke a dome, later passes higher, or flat for the slab); every bubble the
surface is inside drops it to the bubble's floor, which may open into the next bubble down, so
holes show holes. The result is shaded from above like the silk: light on its normals, darkness
collecting in pits and depth, the thin wall crests catching light, a little glint.

All lengths are in reference px (silk.REF short side), so a preview and a full render agree.
concepts/pumice/ has the sketches, and the 3D versions (Blender relief, true SDF volume).
"""
import cv2
import numpy as np

from fans import _field

KEYS = ("porosity", "bubble_min", "bubble_max", "mix", "stretch", "pdepth")
SHADE_KEYS = ()


def vesicles(p, Wr, Hr):
    """x, y, offset below the surface, and the three radii, all in reference px."""
    rng = np.random.default_rng(p["seed"] * 7919 + 21)
    rmin, rmax, alpha = p["bubble_min"], max(p["bubble_max"], p["bubble_min"] + 0.5), p["mix"]
    depth = p["pdepth"]
    k = 1 - (rmin / rmax) ** alpha
    goal = p["porosity"] * Wr * Hr * depth
    n = 0
    out = []
    vol = 0.0
    while vol < goal and n < 80000:
        m = 2048  # in batches: the loop is only for the stopping rule
        r = rmin * (1 - rng.random(m) * k) ** (-1 / alpha)
        a, b, c = r * p["stretch"], r, r * 0.9
        x, y = rng.uniform(-r, Wr + r), rng.uniform(-r, Hr + r)
        off = rng.uniform(-0.6, 1.0, m) * np.maximum(depth, c)
        v = np.cumsum(4.19 * a * b * c)
        take = int(np.searchsorted(v, goal - vol)) + 1
        take = min(take, m)
        out.append(np.stack([x, y, off, a, b, c], 1)[:take])
        vol += v[take - 1]
        n += take
    return np.concatenate(out)


def carve(z, ves, passes=4):
    """Drop the surface through every bubble it is inside (ves in pixels: x, y, zc, a, b, c, theta)."""
    Hh, Ww = z.shape
    order = np.argsort(-(ves[:, 2] + ves[:, 5]))  # highest tops first, fewer passes to settle
    ves = ves[order]
    for _ in range(passes):
        moved = 0
        for x, y, zc, a, b, c, th in ves:
            R = max(a, b)
            x0, x1 = int(max(0, x - R)), int(min(Ww, x + R + 1))
            y0, y1 = int(max(0, y - R)), int(min(Hh, y + R + 1))
            if x0 >= x1 or y0 >= y1:
                continue
            zz = z[y0:y1, x0:x1]
            if zz.min() <= zc - c:  # already carved below this bubble everywhere it could reach
                if zz.max() <= zc - c:
                    continue
            dx = np.arange(x0, x1, dtype=np.float32)[None, :] - x
            dy = np.arange(y0, y1, dtype=np.float32)[:, None] - y
            ct, st = np.cos(th), np.sin(th)
            q = ((dx * ct + dy * st) / a) ** 2 + ((-dx * st + dy * ct) / b) ** 2
            h = c * np.sqrt(np.clip(1 - q, 0, 1))
            hit = (q < 1) & (zz > zc - h) & (zz <= zc + h + 1e-3)
            if hit.any():
                zz[hit] = (zc - h)[hit]
                moved += 1
        if moved == 0:
            break
    return z


def slab_host(p, W, H, f):
    """A flat surface, and the direction of a vortex flow (the fans field) under every pixel."""
    Wr, Hr = W / f, H / f
    fld, _ = _field(np.random.default_rng(p["seed"]), Wr, Hr, int(p["eyes"]), min(Wr, Hr))
    step = 12
    gy, gx = np.mgrid[0:Hr + step:step, 0:Wr + step:step]
    th = np.array([[np.arctan2(*fld(float(x), float(y))[::-1]) for x, y in zip(rx, ry)] for rx, ry in zip(gx, gy)], np.float32)
    # resize the angle as a vector so it doesn't jump at +-pi
    c = cv2.resize(np.cos(th), (W, H), interpolation=cv2.INTER_LINEAR)
    s = cv2.resize(np.sin(th), (W, H), interpolation=cv2.INTER_LINEAR)
    return np.zeros((H, W), np.float32), np.arctan2(s, c).astype(np.float32)


def surface(p, base, theta, f):
    """The carved height field, in pixels. f = pixels per reference px."""
    Hh, Ww = base.shape
    v = vesicles(p, Ww / f, Hh / f)
    x, y = v[:, 0] * f, v[:, 1] * f
    cx = np.clip(x.astype(int), 0, Ww - 1)
    cy = np.clip(y.astype(int), 0, Hh - 1)
    zc = base[cy, cx] - v[:, 2] * f
    ves = np.stack([x, y, zc, v[:, 3] * f, v[:, 4] * f, v[:, 5] * f, theta[cy, cx]], 1)
    return carve(base.copy(), ves)


def ground(p, t, dark):
    """The dark ground in the gaps between things, lifted toward its own shading as Outline goes to 0."""
    return dark + (1 - min(p["outline"], 1)) * (t - dark)


def tone(p, Hf, light, f, local=None):
    """Shade the height field from above: 0..1 tones for silk's colour ramp. With local (px), depth is
    measured against the surroundings instead of the whole page, for surfaces that only sag."""
    Hf = Hf.astype(np.float32)
    gy, gx = np.gradient(Hf)
    rel = p["relief"]
    n = np.dstack([-gx * rel, -gy * rel, np.ones_like(gx)])
    n /= np.linalg.norm(n, axis=2, keepdims=True)
    L = np.array([light[0], light[1], np.sqrt(max(1 - (light ** 2).sum(), 0))], np.float32)
    lam = np.clip(n @ L, 0, 1)
    pit = np.clip(cv2.GaussianBlur(Hf, (0, 0), 12.8 * f) - Hf, 0, None)
    rel = Hf if local is None else Hf - cv2.GaussianBlur(Hf, (0, 0), local)
    lo, hi = np.percentile(rel[::4, ::4], [1, 99])
    span = hi - lo + 1e-6
    deep = np.clip((hi - rel) / span, 0, 1)
    crest = np.clip(-cv2.Laplacian(cv2.GaussianBlur(Hf, (0, 0), max(0.8, 1.9 * f)), cv2.CV_32F), 0, None)
    crest /= np.percentile(crest[::4, ::4], 99.5) + 1e-6
    hv = L + np.array([0, 0, 1], np.float32)
    hv /= np.linalg.norm(hv)
    spec = np.clip(n @ hv, 0, 1) ** 60
    dark = np.exp(-p["cavity"] * pit / (0.08 * span)) * (1 - 0.75 * deep ** 1.2)  # pits and the cracks between things
    t = (0.2 + 0.62 * lam) * dark ** p["outline"]
    t += p["rim"] * 0.25 * np.clip(crest, 0, 1) * lam + p["glint"] * spec
    return t
