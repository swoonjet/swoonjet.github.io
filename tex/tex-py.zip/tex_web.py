"""Tex in the browser: the studio server's render calls, for the Pyodide worker."""
import io
import json

import crystals
import silk
import skia

crystals._draw = skia.draw  # shards drawn by the browser's canvas


def config():
    return json.dumps({"defaults": silk.DEFAULTS, "presets": silk.PRESETS})


def clean(params):
    """Only known keys, coerced to the default's type."""
    return {k: type(silk.DEFAULTS[k])(v) for k, v in (params or {}).items() if k in silk.DEFAULTS}


def render(pjson, W, H, ss, fmt):
    p = {**silk.DEFAULTS, **clean(json.loads(pjson))}
    im = silk.render(p, int(W), int(H), ss=int(ss), log=lambda *a: None)
    buf = io.BytesIO()
    if fmt == "png":
        im.save(buf, "PNG")
    else:
        im.convert("RGB").save(buf, "JPEG", quality=88)
    return buf.getvalue()


def derive(color):
    d, l = silk.derive(color)
    return json.dumps({"dark": d, "light_color": l})
