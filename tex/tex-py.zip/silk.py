"""One wide stroke that fills the page, painted as a field instead of as separate hairs.

bristle.py draws every hair as its own polyline; where the runs join, the
round caps double up and read as faint bands across the stroke. Here the
stroke is laid down first as geometry only: for every pixel, which pass of
the stroke is on top, how far along it (u) and how far across (v, -1..1).
Everything else is a function of (u, v), so there are no seams anywhere:

  hairs    v sliced into fine fibres that wander a little along u,
           each with its own slow tone, gathered into soft clumps
  body     the stroke shaded as a round bundle from the light
  sheen    Kajiya-Kay highlight along the fibres, the satin look of hair
  depth    each later pass sits higher; a higher pass casts a soft shadow
           on what it covers, and buried parts get ambient occlusion

  .venv/bin/python silk.py --seed 7 -o silk.png
  .venv/bin/python silk.py --color "#7b1838" --light 200 --size 5120x2880

render(params) is the whole pipeline; studio.py drives it from a browser UI.
The composition is walked at a fixed reference size and scaled, so a small
preview and the full-size render are the same picture.
"""
import argparse
import colorsys

import cv2
import numpy as np
from PIL import Image

from bristle import RAMPS, coil, hash1, hex_rgb, noise1, noise2, smoothstep
import bones
import candy
import crochet
import crystals
import delaunay
import elephant
import forms
import ink
import knit
import mycelium
import leather
import pine
import protozoa
import rust
import scales
import amethyst
import shag
import sludge
import stone
import syrup
import wood
from fans import fans


def lut_of(stops):
    c = np.array([hex_rgb(h) for h in stops], np.float32)
    x = np.linspace(0, 1, len(c))
    return np.stack([np.interp(np.linspace(0, 1, 1024), x, c[:, i]) for i in range(3)], 1).astype(np.float32)


def raster(pts, nrm, half, W, H, ss, lo=None, hi=None, sid=None):
    """Index buffer: for each pixel, 1 + the spine point whose slab is on top (0 = bare).
    lo/hi narrow a slab to part of the width (a stroke's rounded head and tip); sid keeps slabs
    from bridging the gap between separate strokes."""
    idx = np.zeros((H * ss, W * ss), np.int32)
    n = len(pts)
    if lo is None:
        lo, hi, sid = np.full(n, -1.0), np.full(n, 1.0), np.zeros(n, int)
    last = np.empty(n, int)  # the last point of each point's stroke
    ends = np.r_[np.nonzero(np.diff(sid))[0], n - 1]
    last[:] = np.repeat(ends, np.diff(np.r_[-1, ends]))
    for k in range(n - 1):  # in order, so a later pass overwrites what it covers
        k2 = min(k + 3, last[k])  # slabs 3 steps long overlap, no cracks on the outside of a bend
        if k2 == k or lo[k] >= hi[k]:
            continue
        a, b = pts[k], pts[k2]
        l, h = lo[k], hi[k]
        q = np.array([a + nrm[k] * half[k] * h, b + nrm[k2] * half[k2] * h, b + nrm[k2] * half[k2] * l, a + nrm[k] * half[k] * l])
        cv2.fillConvexPoly(idx, np.round(q * ss * 16).astype(np.int32), k + 1, lineType=cv2.LINE_8, shift=4)
    bare = idx == 0
    if bare.any() and not bare.all():  # the last cracks and specks: the nearest stroke reaches over them
        _, lab = cv2.distanceTransformWithLabels(bare.astype(np.uint8), cv2.DIST_L2, 3, labelType=cv2.DIST_LABEL_PIXEL)
        zj, zi = np.nonzero(~bare)
        near = np.zeros(lab.max() + 1, np.int32)
        near[lab[zj, zi]] = idx[zj, zi]
        idx = near[lab]
    return idx


def occlusion(idx, arc, hw, light, ss, reach):
    """How much higher stroke lies over each pixel: a cast shadow toward the light, plus ambient occlusion.
    Height is order along the stroke. A neighbour is above only if it is a later pass, not the same
    pass a little further on: its arc must be ahead by much more than the distance between them."""
    k = idx[::ss, ::ss] - 1
    U = np.where(k >= 0, arc[np.clip(k, 0, None)], -1e9).astype(np.float32)
    h, w = U.shape
    pad = int(max(reach, 0.6 * hw)) + 2
    Up = np.pad(U, pad, constant_values=-1e9)

    def at(dx, dy):
        dx, dy = int(round(dx)), int(round(dy))
        return Up[pad + dy:pad + dy + h, pad + dx:pad + dx + w]

    def above(dx, dy):
        d = np.hypot(dx, dy)
        return (at(dx, dy) - U > 2.5 * d + 0.8 * hw).astype(np.float32)

    lx, ly = light / np.hypot(*light)
    cast = np.zeros_like(U)
    for d in np.linspace(3, reach, 14):  # toward the light: something higher there throws shade here
        cast = np.maximum(cast, above(lx * d, ly * d) * np.exp(-d / (reach * 0.45)))
    cast = cv2.GaussianBlur(cast, (0, 0), reach * 0.12)
    ao = np.zeros_like(U)
    dirs = [(np.cos(t), np.sin(t)) for t in np.linspace(0, 2 * np.pi, 12, endpoint=False)]
    for r in (0.15 * hw, 0.35 * hw, 0.6 * hw):
        for cx, cy in dirs:
            ao += above(cx * r, cy * r)
    ao = cv2.GaussianBlur(ao / (3 * len(dirs)), (0, 0), hw * 0.15)
    up = lambda a: cv2.resize(a, (w * ss, h * ss), interpolation=cv2.INTER_LINEAR)
    return up(cast), up(ao)


REF = 1440  # the stroke is walked, and every px constant is tuned, at this short side

DEFAULTS = dict(
    seed=7, width=0.3, fill=3.0, swirl=0.7,
    pitch=1.1, wander=1.5, fibre=0.08, clump=0.14, round=0.14, sheen=0.22,
    light=236.0, shadow=0.36, ao=0.35, depth=0.12,
    color="#6b645b", dark="#1b1916", light_color="#d8d0c4",
    specks=250, grain=0.05,
    # form: "coil" is the one long stroke; "fans" is Cincinnus-style strokes swept round off-page vortices
    mode="coil", strokes=60, eyes=5, fat=0.4, rough=1.0, dry=0.3, vary=0.1,
    # "crystals" paints the coil or fans strokes (path) with triangular shards instead of fibres
    path="fans", shard=16.0, size_var=0.5, elong=2.4, density=2.5, align=0.85, facet=0.22, grad=0.06,
    opacity=0.85, blend="Normal", sparkle=0.5, sparkle_blend="Screen", underlay=0.6,
    # "pumice" carves gas bubbles into the strokes (host coil/fans) or a flat slab, see stone.py
    host="fans", porosity=0.6, bubble_min=2.0, bubble_max=30.0, mix=1.7, stretch=3.0, pdepth=45.0,
    relief=1.0, cavity=0.9, rim=0.5, glint=0.25, outline=1.0,
    layer="none", layer_blend="Imprint", layer_mix=0.6,
    # the material modes; each module's docstring says what it simulates and in what order
    lea_grain=9.0, lea_grain_h=1.0, lea_creases=0.6, lea_crease_depth=1.0, lea_cracks=0.4, lea_crack_size=70.0,
    lea_wear=0.6, lea_stain=0.5,
    sl_fill=0.45, sl_visc=0.6, sl_skin=0.7, sl_wrinkle=12.0, sl_bubbles=0.5, sl_drips=0.5, sl_oil=0.35,
    cc_fibres=5000, cc_fluff=0.7, cc_loop=0.5, cc_length=500.0, cc_mix=0.35, cc_bright=1.0, cc_glow=0.5, tint="#8fc7ef",
    ink_drops=9, ink_time=1.0, ink_turb=0.6, ink_diffuse=0.5, ink_fall=90.0, ink_density=1.0,
    pz_count=30, pz_size=1.0, pz_debris=0.6, pz_focus=0.0, pz_dof=1.0, pz_halo=0.6, pz_scope=0.0, pz_dark=0.0, pz_variety=0.6,
    wc_size=85.0, wc_layers=2.5, wc_align=0.5, wc_splinter=0.6, wc_grain=0.7, wc_bark=0.15, wc_tones=0.5, wc_weather=0.3,
    sh_pile=60.0, sh_spacing=14.0, sh_fall=0.7, sh_comb=0.6, sh_curl=0.4, sh_plies=3, sh_heather=0.15, sh_sheen=0.5,
    yarn="#3f7f8c",
    el_plate=34.0, el_fine=9.0, el_depth=1.0, el_folds=0.8, el_fold_depth=1.0, el_bulge=1.0, el_dust=0.5, el_hairs=0.3,
    cr_stitch=22.0, cr_tall=0.5, cr_lace=0.2, cr_stripes=3, cr_plump=1.0, cr_twist=0.6, cr_fuzz=0.4, cr_motifs=9,
    # more stroke forms (forms.py), for the silk itself and for every material to sit on
    rg_centres=3, rg_width=56.0, rg_wobble=0.5, rg_breaks=0.12,
    rb_count=14, rb_wave=0.6, rb_angle=20.0, rb_breaks=0.03,
    db_count=450, db_size=170.0, db_order=0.7, db_curve=0.5,
    th_angle=75.0, th_length=320.0, th_width=70.0, th_overlap=0.55, th_jitter=0.3,
    wv_count=10, wv_angle=0.0, wv_width=0.85, wv_span=1,
    bu_centres=3, bu_length=260.0, bu_width=60.0, bu_curl=0.4,
    kn_stitch=110.0, kn_loose=0.6, kn_uneven=0.4, kn_twist=0.6, kn_fuzz=0.6, kn_rib=0, kn_stripes=0,
    pn_density=1.0, pn_length=150.0, pn_width=3.0, pn_align=0.3, pn_depth=1.0, pn_decay=0.5, pn_fresh=0.15,
    my_seeds=6, my_time=520, my_branch=1.0, my_wander=1.0, my_density=2, my_cords=1.0, my_glow=0.6,
    bb_density=2.4, bb_size=150.0, bb_hollow=0.4, bb_curve=0.4, bb_align=0.4, bb_pores=0.6, bb_stain=0.5,
    sy_sheet=1.0, sy_pour=1.0, sy_coil=80.0, sy_level=0.5, sy_bubbles=0.5, sy_depth=1.0, sy_gloss=0.8,
    ru_amount=0.45, ru_bloom=260.0, ru_flakes=1.0, ru_flake_size=28.0, ru_pits=0.6, ru_scale=1.0, ru_streaks=0.6,
    dl_points=1800, dl_adapt=0.6, dl_regular=0.6, dl_relief=1.0, dl_edges=0.6, dl_tones=0.5,
    sc_size=110.0, sc_rows=0.8, sc_lift=0.8, sc_dome=0.6, sc_growth=0.4, sc_uneven=0.3, sc_tones=0.5, sc_mix=0.0,
    am_size=110.0, am_density=2.6, am_lean=0.5, am_sharp=1.0, am_align=0.4, am_zone=0.6, am_clarity=0.6,
)

SURFACES = {"pumice": stone, "leather": leather, "sludge": sludge, "wood": wood, "shag": shag, "elephant": elephant,
            "crochet": crochet, "knit": knit, "pine": pine, "mycelium": mycelium, "bones": bones, "syrup": syrup, "rust": rust,
            "delaunay": delaunay, "scales": scales, "amethyst": amethyst}  # height fields, shaded from above
IMAGES = {"candy": candy, "ink": ink, "protozoa": protozoa}  # their own fields, coloured their own way
SILK = ("coil", "fans", *forms.FORMS)  # the fibre brush on each stroke form
MODES = (*SILK, "crystals", *SURFACES, *IMAGES)
HOSTED = (*SURFACES, *IMAGES)  # built on the coil or fans strokes, or on their own (host "slab")
HOSTS = (*SILK, "slab")
SHADE_KEYS = ("light", "relief", "cavity", "rim", "glint", "shadow", "ao", "outline")

PRESETS = {
    "Warm grey": ("#6b645b", "#1b1916", "#d8d0c4"),
    "Claret": ("#7b1838", "#14040a", "#f0c6c8"),
    "Ink": ("#3d3d3f", "#0b0b0c", "#e9e8e4"),
    "Sage": ("#6f7a64", "#151912", "#e1e7d6"),
    "Ochre": ("#a8742e", "#1c1206", "#f5e2b8"),
    "Slate": ("#4d5d73", "#0d121a", "#d8e0ec"),
    "Bone": ("#bdb5a8", "#3f3a33", "#fbf8f2"),
    "Saddle": ("#7a4524", "#1c0d05", "#e9c79c"),
    "Candy": ("#ee8fb9", "#2a1c33", "#fff4f9"),
    "Pond": ("#8c9f84", "#1d2620", "#f1f4e6"),
    "Sumi": ("#2e3d5c", "#0a0c12", "#f3efe6"),
    "Bog": ("#5d5a2c", "#121007", "#cfc99c"),
    "Cedar": ("#9a6a3c", "#1e1208", "#efd2a6"),
    "Wool": ("#c9b79c", "#2b241c", "#fbf3e6"),
    "Elephant": ("#77726c", "#1a1816", "#dcd5cb"),
    "Marigold": ("#d98a2b", "#2a1505", "#fde7c0"),
    "Oatmeal": ("#cbbfa8", "#2e2a24", "#faf6ee"),
    "Needles": ("#7a5a36", "#1a1209", "#e2c79a"),
    "Loam": ("#4a3b2c", "#0e0a07", "#f4efe4"),
    "Maple": ("#9a4a14", "#1c0702", "#f2c070"),
    "Teal paint": ("#3e6e6a", "#0c1a19", "#cfe3dc"),
    "Jade": ("#4f7a6e", "#0b1613", "#d9eadf"),
    "Amethyst": ("#7b3fa6", "#160620", "#f1e4fb"),
}


def _lin(h):
    c = np.array(hex_rgb(h), np.float32) / 255
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def _srgb(c):
    c = np.clip(c, 0, 1)
    return np.where(c <= 0.0031308, c * 12.92, 1.055 * c ** (1 / 2.4) - 0.055) * 255


def ramp_lut(color, dark, light):
    """Tone 0..1 -> RGB: shadow colour, the picked colour at the middle, highlight colour. Mixed in linear light."""
    t = np.linspace(0, 1, 1024, dtype=np.float32)[:, None]
    d, c, l = _lin(dark), _lin(color), _lin(light)
    lo = d + (c - d) * smoothstep(0, 0.5, t) ** 1.0
    hi = c + (l - c) * ((t - 0.5) / 0.5).clip(0, 1)
    return _srgb(np.where(t < 0.5, lo, hi)).astype(np.float32)


def derive(color):
    """A shadow and a highlight of the same hue, for when only the colour is picked."""
    r, g, b = (v / 255 for v in hex_rgb(color))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    to = lambda rgb: "#%02x%02x%02x" % tuple(int(round(v * 255)) for v in rgb)
    return to(colorsys.hls_to_rgb(h, 0.07, s * 0.6)), to(colorsys.hls_to_rgb(h, 0.88, s * 0.5))


_cache = {}


def _cached(key, make, keep=2):
    """A couple of the latest results per stage (key[0] names the stage), so a slider only redoes its own stage."""
    c = _cache.setdefault(key[0], {})
    if key in c:
        c[key] = c.pop(key)  # the most recent last, so two layered textures don't push each other out
    else:
        if len(c) >= max(keep, 2):
            c.pop(next(iter(c)))
        c[key] = make()
    return c[key]


FORM_KEYS = {"coil": ("width", "fill", "swirl"), "fans": ("strokes", "eyes", "fat", "rough"),
             "rings": ("rg_centres", "rg_width", "rg_wobble", "rg_breaks"), "ribbons": ("rb_count", "rb_wave", "rb_angle", "rb_breaks"),
             "dabs": ("db_count", "db_size", "db_order", "db_curve", "eyes"),
             "thatch": ("th_angle", "th_length", "th_width", "th_overlap", "th_jitter"),
             "weave": ("wv_count", "wv_angle", "wv_width", "wv_span"), "burst": ("bu_centres", "bu_length", "bu_width", "bu_curl")}


def form(p):
    """Which stroke geometry: crystals paint the strokes of their path."""
    f = p["path"] if p["mode"] == "crystals" else p["host"] if p["mode"] in HOSTED else p["mode"]
    return f if f in FORM_KEYS else "coil"


def geom_key(p, aspect):
    return ("geom", form(p), p["seed"], round(aspect, 4), *(p[k] for k in FORM_KEYS[form(p)]))


def geometry(p, aspect):
    """The strokes at reference size: same seed and aspect, same picture at any resolution.
    Returns the spine, the typical half width, and per-point extras (see fans.fans)."""
    def make():
        Wr, Hr = (REF * aspect, REF) if aspect >= 1 else (REF, REF / aspect)
        if form(p) == "fans":
            g, hw, extra, _ = fans(p, Wr, Hr)
            return forms.underlay(g, hw, extra, Wr, Hr, p["seed"])
        if form(p) in forms.FORMS:
            g, hw, extra, _ = forms.FORMS[form(p)](p, Wr, Hr)
            return forms.underlay(g, hw, extra, Wr, Hr, p["seed"])
        hw = REF * p["width"] / 2
        rng = np.random.default_rng(p["seed"])
        g = coil(rng, Wr, Hr, p["fill"] * Wr * Hr / (2 * hw), hw, swirl=p["swirl"], bare=0.0005, cap=3.0,
                 widen=1.3, swell=0.12)
        n, a = len(g[0]), g[2]
        extra = dict(lo=np.full(n, -1.0), hi=np.full(n, 1.0), sid=np.zeros(n, int), t=a / a[-1],
                     shw=np.full(n, hw), rank=a / a[-1])
        return forms.underlay(g, hw, extra, Wr, Hr, p["seed"])
    return _cached(geom_key(p, aspect), make)


def light_vec(deg):
    a = np.radians(deg)
    return np.array([np.cos(a), np.sin(a)]) * 0.749  # 0.749 across the page, the rest from above


LAYER_BLENDS = ("Imprint", "Underneath", "Patches", "Multiply", "Screen", "Overlay")


def render(params, W, H, ss=3, log=print):
    """Everything from params to a finished RGB PIL image of W x H; with a second texture (layer),
    the two combined by layer_blend."""
    p = {**DEFAULTS, **params}
    im = _render(p, W, H, ss, log)
    if p["layer"] not in MODES or p["layer"] == p["mode"] or p["layer_mix"] <= 0:
        return im
    q = {**p, "mode": p["layer"]}
    if p["layer"] in HOSTED and p["mode"] in SILK:  # the second texture follows the same strokes
        q["host"] = p["mode"]
    elif p["layer"] in HOSTED and p["mode"] == "crystals":
        q["host"] = p["path"]
    elif p["layer"] == "crystals" and p["mode"] in HOSTED and p["host"] in SILK:
        q["path"] = p["host"]
    return combine(p, im, _render(q, W, H, ss, log), min(W, H) / REF)


def combine(p, ia, ib, sc):
    """Two finished images into one. Imprint (A pressed with B's relief, lit by the same light),
    Underneath (B shows in A's shadows and gaps), Patches (B in soft islands), or a plain blend."""
    a = np.asarray(ia, np.float32) / 255
    b = np.asarray(ib, np.float32) / 255
    H, W = a.shape[:2]
    mix, mode = p["layer_mix"], p["layer_blend"]
    lum = lambda x: x @ np.array([0.299, 0.587, 0.114], np.float32)
    if mode == "Imprint":
        hb = cv2.GaussianBlur(lum(b), (0, 0), max(0.6, 0.8 * sc))
        gy, gx = np.gradient(hb)
        lx, ly = light_vec(p["light"])
        e = -(gx * lx + gy * ly)
        e /= np.percentile(np.abs(e[::3, ::3]), 99) + 1e-6
        detail = hb - cv2.GaussianBlur(hb, (0, 0), 8 * sc)
        detail /= np.percentile(np.abs(detail[::3, ::3]), 99) + 1e-6
        out = a * (1 + mix * (0.5 * np.clip(e, -1, 1) + 0.35 * np.clip(detail, -1, 1)))[..., None]
    else:
        if mode == "Underneath":
            la = cv2.GaussianBlur(lum(a), (0, 0), max(0.8, 1.5 * sc))
            lo, hi = np.percentile(la[::3, ::3], [2, 60])
            m = np.clip((hi - la) / (hi - lo + 1e-6), 0, 1) ** 1.5 * min(1.0, 1.6 * mix)
        elif mode == "Patches":
            from fields import fbm
            n = fbm(W, H, 420 * sc, p["seed"] + 23, 4)
            cut = np.percentile(n[::3, ::3], 100 * (1 - mix))
            m = smoothstep(cut - 0.04, cut + 0.04, n)
            m = m * (1 - 0.2 * (1 - np.clip(lum(b) * 2, 0, 1)))  # the edge of a patch is ragged with its own texture
        else:
            m = mix
        if mode == "Multiply":
            b = a * b
        elif mode == "Screen":
            b = 1 - (1 - a) * (1 - b)
        elif mode == "Overlay":
            b = np.where(a < 0.5, 2 * a * b, 1 - 2 * (1 - a) * (1 - b))
        m = np.asarray(m, np.float32)
        out = a + (b - a) * (m[..., None] if m.ndim else m)
    return Image.fromarray((np.clip(out, 0, 1) * 255 + 0.5).astype(np.uint8))


def _render(p, W, H, ss, log):
    sc = min(W, H) / REF
    if p["mode"] not in MODES:
        p["mode"] = "coil"
    mode = p["mode"]
    if mode in HOSTED:
        ss = min(ss, 2)  # shaded or accumulated fields, not sampled per fibre; 2x is plenty
        if p["host"] not in HOSTS:
            p["host"] = "fans"
    small = W * H * ss * ss < 9e6  # only previews are worth keeping around
    light = light_vec(p["light"])
    f = sc * ss
    if mode in HOSTED and p["host"] == "slab":  # no strokes: each mode lays out its own ground
        hkey = ("slab", p["seed"], p["eyes"], W, H, ss)
        if mode in IMAGES:
            return _image(p, None, hkey, W, H, ss, sc, light, small)
        make = lambda: stone.slab_host(p, W * ss, H * ss, f)
        base, theta = _cached(("slabhost", hkey), make, keep=1) if small else make()
        return _surface(p, base, theta, 0, 0, hkey, W, H, ss, sc, light, small)
    if mode in IMAGES:  # the strokes as paths, no raster needed
        (pts0, nrm0, arc0, half0), _, ex0 = geometry(p, W / H)
        return _image(p, (pts0 * f, nrm0, arc0 * f, half0 * f, ex0), (geom_key(p, W / H), W, H, ss), W, H, ss, sc, light, small)
    fans_on = form(p) != "coil"  # separate strokes: each its own load of paint, dry tails
    (pts0, nrm, arc0, half0), hw0, ex = geometry(p, W / H)
    pts, arc, half, hw = pts0 * sc, arc0 * sc, half0 * sc, hw0 * sc
    tan = np.stack([nrm[:, 1], -nrm[:, 0]], 1)
    L = arc[-1]
    lz = np.sqrt(1 - (light ** 2).sum())
    gkey = geom_key(p, W / H)

    rkey = ("raster", gkey, W, H, ss)
    ras = lambda: raster(pts, nrm, half, W, H, ss, ex["lo"], ex["hi"], ex["sid"])
    idx = _cached(rkey, ras) if small else ras()
    fkey = ("light", rkey, p["light"])
    shade = lambda: occlusion(idx, arc, hw, light, ss, reach=0.55 * hw)
    cast, ao = _cached(fkey, shade) if small else shade()
    log(f"stroke {L:.0f} px, bare {100 * (idx == 0).mean():.2f}%")

    if mode in SURFACES:  # the strokes as domes, later passes higher, then the material
        def make():
            th_k = np.arctan2(tan[:, 1], tan[:, 0]).astype(np.float32)
            base = np.zeros(idx.shape, np.float32)
            theta = np.zeros(idx.shape, np.float32)
            uu = np.zeros(idx.shape, np.float32)
            vv = np.zeros(idx.shape, np.float32)
            hh = np.zeros(idx.shape, np.float32)
            for r0 in range(0, idx.shape[0], 512):
                kk = idx[r0:r0 + 512] - 1
                k = np.clip(kk, 0, None)
                ys, xs = np.mgrid[r0:r0 + kk.shape[0], 0:idx.shape[1]]
                v = np.clip((((xs + 0.5) / ss - pts[k, 0]) * nrm[k, 0] + ((ys + 0.5) / ss - pts[k, 1]) * nrm[k, 1]) / half[k], -1, 1)
                dome = (half[k] * 0.35 * np.sqrt(1 - v * v) + ex["rank"][k] * 0.25 * hw) * ss
                base[r0:r0 + kk.shape[0]] = np.where(kk >= 0, dome, 0)
                theta[r0:r0 + kk.shape[0]] = th_k[k]
                if getattr(SURFACES[mode], "UV", False):
                    px, py = (xs + 0.5) / ss - pts[k, 0], (ys + 0.5) / ss - pts[k, 1]
                    uu[r0:r0 + kk.shape[0]] = (arc[k] + px * tan[k, 0] + py * tan[k, 1]) * ss
                    vv[r0:r0 + kk.shape[0]] = np.where(kk >= 0, v * half[k] * ss, np.nan)
                    hh[r0:r0 + kk.shape[0]] = half[k] * ss
            base = cv2.GaussianBlur(base, (0, 0), 1.2 * ss)  # the slabs step a hair apart; raking light shows it
            return base, theta, (uu, vv, hh)
        base, theta, uv = _cached(("base", rkey, getattr(SURFACES[mode], "UV", False)), make, keep=1) if small else make()
        return _surface(p, base, theta, cast, ao, rkey, W, H, ss, sc, light, small, uv)

    def tones():
        # fibres finer than ~2 samples alias into moire; fade their detail out (a small preview shows the clumps only)
        aa = float(smoothstep(1.5, 3.0, p["pitch"] * sc * ss))
        hx, hy = light / np.linalg.norm(np.array([*light, lz + 1]))  # half vector, view straight down
        out = np.empty((H * ss, W * ss), np.float32)
        band = 256
        for r0 in range(0, H * ss, band):  # rows at a time, to keep memory flat
            r1 = min(H * ss, r0 + band)
            kk = idx[r0:r1] - 1
            on = kk >= 0
            k = np.clip(kk, 0, None)
            ys, xs = np.mgrid[r0:r1, 0:W * ss]
            px, py = (xs + 0.5) / ss - pts[k, 0], (ys + 0.5) / ss - pts[k, 1]
            u = (arc[k] + px * tan[k, 0] + py * tan[k, 1]) / sc  # back in reference px
            v = np.clip((px * nrm[k, 0] + py * nrm[k, 1]) / half[k], -1, 1)
            nf = 2 * ex["shw"][k] / p["pitch"]  # fibres across this stroke

            # fibres: v sliced into nf fibres that wander smoothly along u
            warp = (p["wander"] * (noise2(v * 3.0 + p["seed"], u / 520) - 0.5) * 2
                    + 0.6 * (noise2(v * 11 + 7.7, u / 210) - 0.5) * 2)
            hc = (v + 1) / 2 * nf + warp
            fid = np.floor(hc)
            f = hc - fid
            prof = np.sin(np.pi * f) ** 0.6  # a round fibre, a hairline of shade between neighbours
            tone = (0.5 + p["depth"] * (ex["rank"][k] - 0.5)
                    + aa * p["fibre"] * (hash1(fid * 1.618 + p["seed"]) - 0.5) * 2 * (0.6 + 0.4 * noise1(u / 400 + fid * 0.37))
                    + p["clump"] * (noise2(hc / 11 + 3.3, u / 900) - 0.5) * 2
                    + 0.05 * (noise2(hc / 3 + 9.1, u / 260) - 0.5) * 2
                    - aa * 0.07 * (1 - prof))
            # the stroke as a round bundle
            q = v * 0.85
            lam = (nrm[k, 0] * light[0] + nrm[k, 1] * light[1]) * q + np.sqrt(1 - q * q) * lz
            tone += p["round"] * (lam - lz)
            # Kajiya-Kay: fibres catch the light where their direction is square to the half vector
            th = tan[k, 0] * hx + tan[k, 1] * hy
            tone += p["sheen"] * (np.sqrt(np.clip(1 - th * th, 0, 1)) ** 40) * (aa * prof + (1 - aa) * 0.75) * smoothstep(-0.2, 0.6, lam)
            tone -= p["outline"] * 0.05 * smoothstep(0.9, 1.0, np.abs(v))  # the very edge of a pass rolls under
            if fans_on:
                sid = ex["sid"][k]
                tone += p["vary"] * (hash1(sid * 3.7 + p["seed"]) - 0.5) * 2  # each stroke its own load of paint
                # dry tail: toward the end hairs run out, one by one, and the dark underneath shows
                t = ex["t"][k]
                gone = hash1(fid * 7.31 + sid * 1.37) < p["dry"] * 1.4 * t ** 4
                tone = np.where(gone, 0.45 * tone - 0.04, tone)  # the stroke underneath, in the shade of the hairs left
            tone -= p["shadow"] * cast[r0:r1] + p["outline"] * p["ao"] * ao[r0:r1]
            out[r0:r1] = np.where(on, tone, 0.02)
        return out
    tkey = ("tone", fkey, *(p[k] for k in ("pitch", "wander", "fibre", "clump", "round", "sheen", "shadow", "ao", "outline", "depth", "dry", "vary")))
    tone = _cached(tkey, tones) if small else tones()

    paint = (lambda img, lut: crystals.paint(img, p, idx, tone, lut, (pts, nrm, arc, half, ex), light, sc, ss)) \
        if p["mode"] == "crystals" else None
    return _finish(p, tone, W, H, ss, sc, paint)


def _surface(p, base, theta, cast, ao, hkey, W, H, ss, sc, light, small, uv=None):
    """A height-field material on its host: build it, shade it, let the host's strokes shade it too."""
    mod = SURFACES[p["mode"]]
    f = sc * ss
    skey = ("surf", p["mode"], hkey, *(p[k] for k in mod.KEYS))
    make = lambda: mod.surface(p, base, theta, f, uv) if getattr(mod, "UV", False) else mod.surface(p, base, theta, f)
    S = _cached(skey, make, keep=1) if small else make()
    shaded = lambda: mod.tone(p, S, light, f) - p["shadow"] * cast - p["outline"] * p["ao"] * ao
    tkey = ("surf_tone", skey, *(p[k] for k in SHADE_KEYS + mod.SHADE_KEYS))
    t = _cached(tkey, shaded, keep=1) if small else shaded()
    paint = (lambda img, lut: mod.paint(p, img, S, f)) if hasattr(mod, "paint") else None
    return _finish(p, t, W, H, ss, sc, paint)


def _image(p, geo, hkey, W, H, ss, sc, light, small):
    """A material that makes its own fields (density, dye, layers) and colours them itself."""
    mod = IMAGES[p["mode"]]
    f = sc * ss
    fkey = ("img", p["mode"], hkey, *(p[k] for k in mod.KEYS))
    make = lambda: mod.fields(p, W * ss, H * ss, f, geo)
    fl = _cached(fkey, make, keep=1) if small else make()
    return _finish(p, np.zeros((H * ss, W * ss), np.float32), W, H, ss, sc, lambda img, lut: mod.colour(p, fl, lut, light, f))


def _finish(p, tone, W, H, ss, sc, paint=None):
    """Tones through the colour ramp, then the crystals (if any), specks, downsample and grain."""
    lut = ramp_lut(p["color"], p["dark"], p["light_color"])
    img = lut[(np.clip(tone, 0, 1) * 1023).astype(np.int32)].astype(np.uint8)
    if paint:
        img = paint(img, lut)
    if p["specks"]:
        sp = np.random.default_rng(p["seed"] * 31 + 7)
        n = int(p["specks"])
        xs, ys = sp.uniform(0, W, n * 4), sp.uniform(0, H, n * 4)
        keep = noise2(xs / (260 * sc), ys / (260 * sc)) > sp.random(len(xs)) * 1.6
        dark = tuple(int(c) for c in lut[20])
        for x, y in list(zip(xs[keep], ys[keep]))[:n]:
            r = (1.0 + 3.8 * sp.random() ** 3) * sc * ss
            cv2.circle(img, (int(x * ss * 16), int(y * ss * 16)), max(1, int(r * 16)), dark, -1, cv2.LINE_AA, shift=4)
    im = Image.fromarray(img).resize((W, H), Image.LANCZOS)
    if p["grain"] > 0:
        px = np.asarray(im, np.float32)
        px += (np.random.default_rng(p["seed"]).random(px.shape[:2]) - 0.5)[..., None] * 2 * p["grain"] * 40
        im = Image.fromarray(np.clip(px, 0, 255).astype(np.uint8))
    return im


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-o", "--out", default="silk.png")
    ap.add_argument("--size", default="2560x1440")
    ap.add_argument("--ss", type=int, default=3)
    ap.add_argument("--preset", choices=list(PRESETS))
    for k, v in DEFAULTS.items():
        ap.add_argument("--" + k.replace("_", "-"), type=type(v), default=v,
                        **({"choices": list(MODES)} if k == "mode" else
                           {"choices": list(HOSTS)} if k == "host" else
                           {"choices": list(FORM_KEYS)} if k == "path" else
                           {"choices": list(crystals.BLENDS)} if k in ("blend", "sparkle_blend") else {}))
    a = ap.parse_args()
    p = {k: getattr(a, k) for k in DEFAULTS}
    if a.preset:
        p["color"], p["dark"], p["light_color"] = PRESETS[a.preset]
    elif a.color != DEFAULTS["color"] and a.dark == DEFAULTS["dark"] and a.light_color == DEFAULTS["light_color"]:
        p["dark"], p["light_color"] = derive(a.color)
    W, H = (int(v) for v in a.size.split("x"))
    render(p, W, H, a.ss).save(a.out)
    print(a.out)


if __name__ == "__main__":
    main()
