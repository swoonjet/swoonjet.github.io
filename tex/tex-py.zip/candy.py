"""Cotton candy: sugar spun into glass thread, wound into a mass that is mostly air.

The process:

  spin     molten sugar is flung out through pinholes; each jet stretches into a filament
           thinner than a hair and freezes into glass at once
  wind     the filaments are caught and wound in loose, looping turns: along the strokes, with
           their place across the stroke wandering and spilling over its edges (the fluff), or
           round a few spinning centres (the cone)
  two      two batches of sugar, two colours, wound through each other
  light    one filament is nearly invisible; where thousands cross, the light piles up. So
           every thread is splatted into a density buffer and tone-mapped by log density (the
           fractal-flame trick, as in gart's Cirrus), then scattered into a soft glow

fields() makes the two density buffers; colour() lights them.
"""
import numpy as np

from fields import Vortices, blur, deposit, lin, noise1, smoothstep, srgb

KEYS = ("cc_fibres", "cc_fluff", "cc_loop", "cc_length", "cc_mix", "eyes")
COLOUR_KEYS = ("cc_bright", "cc_glow", "tint")


def _along(geo, rng, n, f, p):
    """Filaments riding the strokes: a random stretch of a stroke, wandering across it."""
    pts, nrm, arc, half, ex = geo
    sid = ex["sid"]
    step = np.median(np.hypot(*np.diff(pts, axis=0).T)) + 1e-6
    ends = np.r_[np.nonzero(np.diff(sid))[0], len(pts) - 1]
    last = np.repeat(ends, np.diff(np.r_[-1, ends]))
    for _ in range(n):
        i0 = int(rng.integers(0, len(pts) - 2))
        m = int(p["cc_length"] * f * rng.uniform(0.4, 1.6) / step)
        i1 = min(last[i0], i0 + m)
        if i1 - i0 < 4:
            continue
        k = np.arange(i0, i1 + 1)
        s = (k - i0) * step
        v = rng.uniform(-1, 1) * (1 + 0.5 * p["cc_fluff"])
        walk = np.cumsum(rng.normal(0, 0.05 * p["cc_fluff"] + 0.005, len(k)))
        v = v + np.convolve(np.pad(walk, 6, mode="edge"), np.ones(13) / 13, mode="valid")  # its place across wanders, smoothly
        per = rng.uniform(25, 90) * f
        v = v + p["cc_loop"] * 0.9 * (noise1(s / per + rng.uniform(0, 1e3)) - 0.5) * 2  # loose, irregular curls
        yield pts[k] + nrm[k] * (v * half[k])[:, None], step


def _spun(rng, W, H, n, f, p):
    """Filaments wound round a few centres: traced through their swirl together."""
    fld = Vortices(rng, W, H, p["eyes"], inside=True)
    x, y = rng.uniform(0, W, n), rng.uniform(0, H, n)
    steps = int(p["cc_length"] * f / (1.5 * f))
    ph = rng.uniform(0, 6.3, n)
    per = rng.uniform(25, 90, n) * f
    amp = p["cc_loop"] * rng.uniform(6, 22, n) * f
    drift = np.zeros(n)
    out = np.empty((steps, n, 2), np.float32)
    for i in range(steps):
        vx, vy = fld(x, y)
        l = np.hypot(vx, vy) + 1e-9
        ux, uy = vx / l, vy / l
        x, y = x + ux * 1.5 * f, y + uy * 1.5 * f
        drift += rng.normal(0, 0.6 * f, n)  # threads cross each other
        w = amp * (noise1(i * 1.5 * f / per + ph * 100) - 0.5) * 2 + drift  # irregular curls across the way it travels
        out[i, :, 0], out[i, :, 1] = x - uy * w, y + ux * w
    for j in range(n):
        yield out[:, j], 1.5 * f


def fields(p, W, H, f, geo):
    rng = np.random.default_rng(p["seed"] * 7919 + 51)
    A = np.zeros((H, W), np.float32)
    B = np.zeros((H, W), np.float32)
    n = int(p["cc_fibres"])
    paths = _spun(rng, W, H, n, f, p) if geo is None else _along(geo, rng, n, f, p)
    for path, step in paths:
        q = max(1, int(np.ceil(step / 0.7)))  # one sample every ~0.7 px
        t = np.linspace(0, len(path) - 1, (len(path) - 1) * q + 1)
        i = np.minimum(t.astype(int), len(path) - 2)
        fr = (t - i)[:, None]
        xy = path[i] * (1 - fr) + path[i + 1] * fr
        weight = rng.uniform(0.3, 1.0)
        deposit(B if rng.random() < p["cc_mix"] else A, xy[:, 0], xy[:, 1], weight)
    return blur(A, 0.55), blur(B, 0.55)


def colour(p, fl, lut, light, f):
    A, B = fl
    tot = A + B
    k = p["cc_bright"] * 0.8
    top = np.percentile(tot[::3, ::3], 99.7) + 1e-6
    t = np.log1p(tot * k) / np.log1p(top * k)
    t = np.clip(t, 0, 1.3) ** 0.85
    glow = 0.5 * blur(t, 6 * f) + 0.5 * blur(t, 30 * f)  # light scattered through the mass
    T = t + p["cc_glow"] * glow
    hue = blur(B, 2 * f) / (blur(tot, 2 * f) + 1e-6)
    bg, cA, cB, hi = lin(p["dark"]), lin(p["color"]), lin(p["tint"]), lin(p["light_color"])
    col = cA * (1 - hue[..., None]) + cB * hue[..., None]
    a = np.clip(T, 0, 1)[..., None]
    rgb = bg * (1 - a) + col * a
    rgb += (hi - rgb) * smoothstep(0.85, 1.25, T)[..., None]  # where it is thickest it goes white-hot
    return srgb(rgb).astype(np.uint8)
