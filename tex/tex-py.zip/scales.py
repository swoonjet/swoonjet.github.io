"""Scales: half-circle plates laid in rows, each row overlapping the one below, like a fish or a roof.

Built the way they lie:

  plate    every scale is a round plate; only its lower half shows, the upper half is tucked under
           the row above, so what you see is rows of half circles (Size, Rows: how far apart)
  lift     a plate is pressed flat where it is tucked in and stands off at its free edge, so every
           rim throws a little step of shadow onto the plate below (Lift); it is gently domed (Dome)
  growth   fine lines run round the plate, parallel to its edge, as on a fish scale (Growth lines)
  hand     no two plates are the same size or set quite straight (Uneven)
  colour   each plate its own tone (Tones); a share of them in the second colour (Mix)

On the strokes the rows run along every stroke, the free edges pointing back down it; on their own
("Shingles") they cover the page in rows, swelling a little. Lengths are in px (f = px per ref px).
"""
import numpy as np

import stone
from fields import fbm, hash1
from shag import recolour

UV = True
KEYS = ("sc_size", "sc_rows", "sc_lift", "sc_dome", "sc_growth", "sc_uneven")
SHADE_KEYS = ("sc_tones", "sc_mix")


def surface(p, base, theta, f, uv=None):
    H, W = base.shape
    s = p["sc_size"] * f
    R = 0.5 * s
    rh = p["sc_rows"] * R
    if uv is None or p["host"] == "slab":  # shingles across the page, swelling a little
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        X = xx + fbm(W, H, 600 * f, p["seed"] + 4, 2) * 30 * f
        Y = yy + fbm(W, H, 700 * f, p["seed"] + 2, 2) * 40 * f
        on = np.ones((H, W), bool)
        swell = fbm(W, H, 500 * f, p["seed"], 3) * 25 * f
    else:  # the rows run along the stroke
        uu, vv, hh = uv
        on = np.isfinite(vv)
        X, Y = np.where(on, vv + hh, 0), np.where(on, uu, 0)
        swell = 0
    un = p["sc_uneven"]
    lift, dome, gl = p["sc_lift"], p["sc_dome"], p["sc_growth"]
    r0 = np.floor(Y / rh)
    k = int(np.ceil((1.2 * R + 0.1 * rh) / rh))  # the rows whose plates can reach this one, at their largest
    fbm_g = fbm(W, H, 25 * f, p["seed"] + 9, 2)  # growth lines are never quite even
    top = np.full((H, W), -np.inf, np.float32)
    sid = np.full((H, W), -1.0, np.float64)
    # the lowest rows first: every row above is laid over the one below it
    for dr in range(k, -k - 1, -1):
        row = r0 + dr
        off = (row % 2) * 0.5 * s
        c0 = np.round((X - off) / s)
        side = np.where(X - off >= c0 * s, 1, -1)  # only the neighbour on this side can reach across
        for dc in (0, 1):
            col = c0 + dc * side
            key = row * 7919.0 + col
            hs = hash1(key * 0.37 + p["seed"])
            rr = R * (1.04 + un * 0.22 * (hs - 0.5))
            cx = col * s + off + un * 0.12 * s * (hash1(key * 1.71) - 0.5)
            cy = row * rh + un * 0.12 * rh * (hash1(key * 2.93) - 0.5)
            dx, dy = X - cx, Y - cy
            tilt = un * 0.25 * (hash1(key * 4.1) - 0.5)
            dx, dy = dx + tilt * dy, dy - tilt * dx
            d = np.hypot(dx, dy) / rr
            inside = d < 1
            if not inside.any():
                continue
            # pressed flat where tucked under, standing off at the free (lower) edge
            h = lift * 0.45 * rr * np.clip(dy / rr + 0.6, 0, 1.6)
            h += dome * 0.3 * rr * np.sqrt(np.clip(1 - d * d, 0, 1))
            h -= 0.06 * rr * np.clip((d - 0.9) / 0.1, 0, 1)  # the rim rounds off
            h += gl * 0.012 * rr * np.sin(d * 2 * np.pi * rr / (2.5 * f + 0.03 * rr) + 3 * fbm_g) * np.clip(dy / rr + 0.2, 0, 1) * np.clip(d * 1.6, 0, 1)
            take = inside & on
            top = np.where(take, h, top)
            sid = np.where(take, key, sid)
    has = np.isfinite(top)
    z = base + swell + np.where(has, top, -0.2 * R)
    return dict(H=z.astype(np.float32), sid=sid, on=on)


def tone(p, S, light, f):
    t = stone.tone(p, S["H"], light, f, local=60 * f)
    sid = S["sid"]
    t += p["sc_tones"] * 0.12 * (hash1(sid * 0.61 + p["seed"] + 3) - 0.5) * 2
    return np.where(S["on"], t, stone.ground(p, t, 0.03))


def paint(p, img, S, f):
    if p["sc_mix"] <= 0:
        return img
    sid = S["sid"]
    m = S["on"] & (hash1(sid * 1.37 + p["seed"] + 11) < p["sc_mix"])
    return recolour(img, m, p["color"], p["yarn"])
