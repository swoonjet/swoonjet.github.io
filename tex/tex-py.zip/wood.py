"""Wood chips: a log through the chipper, and the chips thrown down into a pile.

Built in the order it happens:

  chip     the blades cut across the log, so every chip is a flat splinter with the grain running
           its length: long and narrow, its ends torn ragged along the grain, its edges a little
           rounded by the tumble; a few are bark, thick and fissured
  throw    chips land one at a time and settle on whatever is already highest under them, tilted
           by it; so the pile builds up in layers and every chip leans on its neighbours. They
           lie along the flow (the strokes, or a slow swirl), more or less, by Alignment
  grain    the growth rings, cut through at a slant, show on a chip as fine lines along it that
           drift and bunch; Grain sets how deep the weather has raised them
  age      every chip is its own wood and its own cut (Tones); a pile left outside goes silver
           grey from the top down (Weathering)

surface() returns the height, which chip is on top where, and which chips are bark.
"""
import numpy as np

import stone
from fields import blur, fbm, hash1, hex_rgb, smoothstep

KEYS = ("wc_size", "wc_layers", "wc_align", "wc_splinter", "wc_grain", "wc_bark")
SHADE_KEYS = ("wc_tones",)


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 81)
    slab = p["host"] == "slab"
    z = base.copy()
    if slab:  # a heap, never flat
        z += fbm(W, H, 600 * f, p["seed"], 2) * 25 * f
    on = np.ones((H, W), bool) if slab else base > 0.5 * f
    cid = np.full((H, W), -1, np.int32)
    L0 = p["wc_size"] * f
    ys, xs = np.nonzero(on[::4, ::4])
    if not len(xs):
        return dict(H=z, cid=cid, bark=np.zeros(1, bool))
    n = int(min(30000, p["wc_layers"] * len(xs) * 16 / (0.3 * L0 * L0)))
    bark = rng.random(n) < p["wc_bark"] * 0.6
    pick = rng.integers(0, len(xs), n)
    cxs, cys = xs[pick] * 4 + rng.uniform(0, 4, n), ys[pick] * 4 + rng.uniform(0, 4, n)
    for i in range(n):
        cx, cy = cxs[i], cys[i]
        th = theta[min(int(cy), H - 1), min(int(cx), W - 1)]
        a = th + rng.normal(0, 0.25) if rng.random() < p["wc_align"] else rng.uniform(0, np.pi)
        l = L0 * np.exp(rng.normal(0, 0.35))
        w = l * (rng.uniform(0.35, 0.6) if bark[i] else rng.uniform(0.16, 0.42))
        R = int(0.55 * l + 3)
        x0, x1, y0, y1 = max(0, int(cx) - R), min(W, int(cx) + R + 1), max(0, int(cy) - R), min(H, int(cy) + R + 1)
        if x0 >= x1 or y0 >= y1:
            continue
        dx = np.arange(x0, x1, dtype=np.float32)[None, :] - cx
        dy = np.arange(y0, y1, dtype=np.float32)[:, None] - cy
        ca, sa = np.cos(a), np.sin(a)
        u, v = dx * ca + dy * sa, -dx * sa + dy * ca
        # outline: the sides wobble a little; the ends are torn along the grain, so ragged and often pointed
        ph = rng.uniform(0, 100)
        side = 0.5 * w * (1 + 0.12 * np.sin(u / (0.17 * l) + ph))
        vn = v / (0.5 * w)
        tear = p["wc_splinter"] * l * 0.3 * (np.abs(np.sin(vn * rng.uniform(2, 6) + ph)) * 0.6 + 0.4 * np.abs(vn) ** 1.5)
        end_a, end_b = 0.5 * l - tear * rng.uniform(0.3, 1), 0.5 * l - tear * rng.uniform(0.3, 1)
        inside = (np.abs(v) < side) & (u < end_a) & (u > -end_b)
        if not inside.any():
            continue
        zz = z[y0:y1, x0:x1]
        # settle: on the high points under it, tilted along by what it rests on
        rest = np.percentile(zz[inside], 88)
        t = l * (0.12 if bark[i] else 0.05) * rng.uniform(0.7, 1.3)
        ui, zi = u[inside], zz[inside]
        gu = 0.6 * np.clip(np.mean((ui - ui.mean()) * (zi - zi.mean())) / (ui.var() + 1e-6), -0.25, 0.25) + rng.normal(0, 0.05)
        edge = np.minimum(side - np.abs(v), np.minimum(end_a - u, u + end_b))
        h = rest + t + gu * u + rng.normal(0, 0.04) * v - t * 0.7 * (1 - smoothstep(0, 2.2 * f, edge))
        if bark[i]:  # fissured: deep furrows along it
            h += t * 0.3 * (np.abs(np.sin(v / (0.09 * w) + 2 * np.sin(u / (0.3 * l) + ph))) - 0.6)
        else:  # growth rings cut at a slant: fine lines along the chip, drifting and bunching
            drift = v + 0.15 * w * np.sin(u / (0.4 * l) + ph)
            ring = np.sin(drift / (0.5 * f) * (1 + 0.4 * np.sin(drift / (0.2 * w) + ph)))  # lines bunch and spread
            fibre = np.sin(drift / (0.23 * f) + 3 * np.sin(u / (0.07 * l) + ph))
            h += p["wc_grain"] * f * (0.22 * ring + 0.1 * fibre)
        top = inside & (h > zz)
        zz[top] = h[top]
        cid[y0:y1, x0:x1][top] = i
    return dict(H=z, cid=cid, bark=bark)


def tone(p, S, light, f):
    z, cid, bark = S["H"], S["cid"], S["bark"]
    t = stone.tone(p, z, light, f, local=50 * f)
    c = np.clip(cid, 0, None)
    has = cid >= 0
    t += has * p["wc_tones"] * 0.22 * (hash1(c * 0.731 + p["seed"]) - 0.5) * 2  # every chip its own wood
    t -= has * bark[c] * 0.2  # bark is dark
    t -= (~has) * 0.1
    return t


def paint(p, img, S, f):
    """Weathering: the exposed pile goes silver grey, unevenly, the top chips most."""
    w = p["wc_weather"]
    if w <= 0:
        return img
    H, W = img.shape[:2]
    cid = S["cid"]
    expo = (cid >= 0) * smoothstep(-0.4, 0.6, fbm(W, H, 300 * f, p["seed"] + 13, 2) + 0.6 * (hash1(np.clip(cid, 0, None) * 1.37) - 0.5))
    im = img.astype(np.float32)
    grey = im.mean(2, keepdims=True) * np.array([0.98, 1.0, 1.04], np.float32) * 1.08
    a = (w * 0.85 * expo)[..., None]
    return np.clip(im * (1 - a) + grey * a, 0, 255).astype(np.uint8)
