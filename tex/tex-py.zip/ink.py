"""Ink in water: drops that roll up into vortex rings, sink, and shed curling filaments.

The process:

  drop     a drop enters still water and rolls into a vortex ring; seen side-on, a ring is a
           pair of opposite vortices, and the pair carries itself along (the fall direction),
           slowly widening and slowing as it spends its energy
  entrain  the dye starts as a blob round each drop (or along the strokes, as if a brush had
           been laid in the water) and is swept up into the ring's mushroom head
  unstable the flow does not stay smooth: a curl-noise disturbance grows with time and breaks
           the dye into lobes and finer and finer filaments
  wake     dye left behind on the way stays as a trail, so every particle marks the water at
           every step: early marks are the faint wake, late ones the head
  diffuse  molecules spread slower than the flow, but they spread: the older a mark, the more
           it is blurred
  light    what we see is light through the dye, Beer-Lambert: thin wisps take the ink's
           colour, dense cores go dark

fields() runs the particles and returns the dye density; colour() lights it.
"""
import numpy as np

from fields import blur, fbm, strokes_sample

KEYS = ("ink_drops", "ink_time", "ink_turb", "ink_diffuse", "ink_fall")
COLOUR_KEYS = ("ink_density",)
BUCKETS = 4


def _curl(W, H, f, seed):
    """A divergence-free disturbance: the curl of two layers of noise, on a coarse grid."""
    step = 6 * f
    gw, gh = int(W / step) + 3, int(H / step) + 3
    psi = fbm(gw, gh, 130 / 6, seed, 3) + 0.5 * fbm(gw, gh, 45 / 6, seed + 1, 2)
    gy, gx = np.gradient(psi)
    return gy / step, -gx / step, step  # u = dpsi/dy, v = -dpsi/dx (per grid cell -> per px)


def _sample(grid, x, y, step):
    gh, gw = grid.shape
    gx, gy = np.clip(x / step, 0, gw - 1.001), np.clip(y / step, 0, gh - 1.001)
    i, j = gx.astype(int), gy.astype(int)
    fx, fy = gx - i, gy - j
    return (grid[j, i] * (1 - fx) * (1 - fy) + grid[j, i + 1] * fx * (1 - fy)
            + grid[j + 1, i] * (1 - fx) * fy + grid[j + 1, i + 1] * fx * fy)


def fields(p, W, H, f, geo):
    rng = np.random.default_rng(p["seed"] * 7919 + 61)
    S = min(W, H)
    a = np.radians(p["ink_fall"])
    g = np.array([np.cos(a), np.sin(a)])
    nv = np.array([-g[1], g[0]])
    K = max(1, int(p["ink_drops"]))
    U0 = S * 0.0016  # px per step

    # drops: start upstream so they have room to fall
    if geo is None:
        c = np.stack([rng.uniform(0.1, 0.9, K) * W, rng.uniform(0.1, 0.9, K) * H], 1) - g * S * 0.18
    else:
        c, _ = strokes_sample(geo, K, rng, 0.3)
        K = len(c)
    R = rng.uniform(30, 75, K) * f
    U = U0 * rng.uniform(0.7, 1.3, K)

    # dye: a blob in every drop, and along the strokes if there are any
    N = 90000 if geo is None else 160000
    nd = N if geo is None else N // 4
    which = rng.integers(0, K, nd)
    rr = np.sqrt(rng.random(nd)) * R[which] * 0.95
    aa = rng.uniform(0, 2 * np.pi, nd)
    x = c[which, 0] + rr * np.cos(aa)
    y = c[which, 1] + rr * np.sin(aa)
    mob = np.ones(N)
    if geo is not None:  # a few stretches of stroke laid in with an inked brush: dense, so it bleeds more than it travels
        pts, nrm, arc, half, ex = geo
        sid = ex["sid"]
        step = np.median(np.hypot(*np.diff(pts, axis=0).T)) + 1e-6
        win = []
        for _ in range(K):
            i0 = int(rng.integers(0, len(pts) - 2))
            i1 = i0 + int(rng.uniform(250, 700) * f / step)
            win.append(np.arange(i0, min(i1, len(pts))) [sid[i0:min(i1, len(pts))] == sid[i0]])
        win = np.concatenate(win)
        m = N - nd
        k = win[rng.integers(0, len(win), m)]
        v = rng.normal(0, 0.28, m).clip(-1, 1)
        s = rng.uniform(0, step, m)
        tx, ty = -nrm[k, 1], nrm[k, 0]
        x = np.r_[x, pts[k, 0] + nrm[k, 0] * v * half[k] * 0.6 + tx * s]
        y = np.r_[y, pts[k, 1] + nrm[k, 1] * v * half[k] * 0.6 + ty * s]
        mob[nd:] = 0.35

    cu, cv, cstep = _curl(W, H, f, p["seed"] + 7)
    T = int(140 + 180 * p["ink_time"])
    acc = np.zeros((BUCKETS, H, W), np.float32)
    chunk_i, chunk_w = [], []
    flush_b = 0

    def flush(b):
        if chunk_i:
            idx = np.concatenate(chunk_i)
            acc[b] += np.bincount(idx, minlength=W * H).reshape(H, W).astype(np.float32)
            chunk_i.clear()

    for t in range(T):
        frac = t / T
        amp = p["ink_turb"] * U0 * 45 * f * smoothstep01(frac / 0.55)  # the instability grows
        vx = _sample(cu, x, y, cstep) * amp
        vy = _sample(cv, x, y, cstep) * amp
        for k in range(K):  # each ring: a pair of opposite vortices with soft cores
            gam = 4 * np.pi * R[k] * U[k]
            for sgn in (1, -1):
                px, py = c[k] + sgn * nv * R[k]
                dx, dy = x - px, y - py
                w = sgn * gam / (2 * np.pi) / (dx * dx + dy * dy + (0.45 * R[k]) ** 2)
                vx -= dy * w
                vy += dx * w
        x += mob * (vx + g[0] * U0 * 0.12)  # dye is a touch heavier than the water
        y += mob * (vy + g[1] * U0 * 0.12)
        c += g[None, :] * U[:, None]  # the rings carry themselves along
        R *= 1.0025
        U *= 0.997
        b = min(BUCKETS - 1, int(frac * BUCKETS))
        if b != flush_b:
            flush(flush_b)
            flush_b = b
        xi, yi = np.rint(x).astype(np.int64), np.rint(y).astype(np.int64)
        ok = (xi >= 0) & (xi < W) & (yi >= 0) & (yi < H)
        chunk_i.append(yi[ok] * W + xi[ok])
        if len(chunk_i) >= 24:
            flush(b)
    flush(flush_b)

    # diffusion: the older the mark, the further it has spread
    D = np.zeros((H, W), np.float32)
    for b in range(BUCKETS):
        age = 1 - (b + 0.5) / BUCKETS
        D += blur(acc[b], (0.7 + p["ink_diffuse"] * 14 * age) * f)
    D *= (f * f) / (N * T) * 2.5e5  # per unit of page, whatever the resolution
    return D


def smoothstep01(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def colour(p, D, lut, light, f):
    T = np.exp(-p["ink_density"] * D)  # light left after passing through the dye
    tone = np.clip(T, 0, 1) ** 0.9
    return lut[(tone * 1023).astype(np.int32)].astype(np.uint8)
