"""In the browser there is no skia-python: this is a stand-in for the few pieces Tex uses.

crystals.py draws its shards with skia's drawVertices; here the canvas is a numpy RGBA buffer and the
triangles go to the worker's OffscreenCanvas (texTris in worker.js), one flat colour per shard: the
average of its three vertex colours. bristle.py imports skia but Tex never calls its skia drawing.
"""
import numpy as np


class BlendMode:  # skia's names -> canvas globalCompositeOperation
    kSrcOver = "source-over"
    kMultiply = "multiply"
    kScreen = "screen"
    kOverlay = "overlay"
    kSoftLight = "soft-light"
    kHardLight = "hard-light"
    kDarken = "darken"
    kLighten = "lighten"
    kColorDodge = "color-dodge"
    kColorBurn = "color-burn"
    kPlus = "lighter"
    kDifference = "difference"
    kLuminosity = "luminosity"
    kDst = "dst"


kRGBA_8888_ColorType = "rgba"
kPremul_AlphaType = "premul"


class ImageInfo:
    @staticmethod
    def Make(w, h, *_):
        return (w, h)


class Image:
    @staticmethod
    def fromarray(a, *_):
        return a


class _Snapshot:
    def __init__(self, px):
        self.px = px

    def toarray(self, **_):
        return self.px


class _Canvas:
    def __init__(self, surf):
        self.surf = surf

    def drawImage(self, img, x, y):
        self.surf.px[:] = img


class Surface:
    def __init__(self, w, h):
        self.px = np.zeros((h, w, 4), np.uint8)

    @staticmethod
    def MakeRaster(info):
        return Surface(*info)

    def getCanvas(self):
        return _Canvas(self)

    def makeImageSnapshot(self):
        return _Snapshot(self.px.copy())


def draw(canvas, tri, colors, blend):
    """crystals._draw for the browser: tri (m, 3, 2) px, colors (3m,) 0xAARRGGBB, blend name."""
    if not len(tri):
        return
    import js
    from pyodide.ffi import to_js

    from crystals import BLENDS
    c = colors.astype(np.uint32).reshape(-1, 3)
    rgba = np.stack([(c >> 16) & 255, (c >> 8) & 255, c & 255, c >> 24], 2).astype(np.float32).mean(1)
    px = canvas.surf.px
    h, w = px.shape[:2]
    out = js.texTris(w, h, to_js(memoryview(np.ascontiguousarray(px).reshape(-1))),
                     to_js(memoryview(np.ascontiguousarray(tri, np.float32).reshape(-1))),
                     to_js(memoryview(np.round(rgba).astype(np.uint8).reshape(-1))), BLENDS.get(blend, BlendMode.kSrcOver))
    px[:] = np.asarray(out.to_py(), np.uint8).reshape(h, w, 4)
