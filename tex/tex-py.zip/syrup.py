"""Syrup: the whole page under thick, clear syrup, poured and slowly levelling.

Built in the order it happens:

  sheet     a layer of syrup over everything (Sheet); whatever it covers (the strokes) sinks into it
            and shows through, lighter where the syrup over it is thin
  pour      a thin stream poured from above does not just land, it coils: liquid rope coiling lays
            the syrup down in overlapping loops that travel along the flow (Pour, Coil size)
  level     then gravity pulls it flat: the loops soften and merge into broad swells (Levelling)
  bubbles   air folded in by the pour stays trapped, small and round (Bubbles)
  light     the syrup is coloured by how much of it the light passes through (Beer-Lambert):
            thin is the highlight colour, deep is the shadow (Depth); its surface is smooth and
            wet, every swell takes a sharp highlight (Gloss)

The colour ramp is the syrup: pick a maple, a golden or a dark one.
"""
import cv2
import numpy as np

from fields import blur, deposit, fbm, light3, normals

KEYS = ("sy_sheet", "sy_pour", "sy_coil", "sy_level", "sy_bubbles")
SHADE_KEYS = ("sy_depth", "sy_gloss")


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 171)
    # the pour: a rope of syrup coiling as it is carried along the flow
    rope = np.zeros((H, W), np.float32)
    rc = p["sy_coil"] * f
    n = int(p["sy_pour"] * W * H / (f * f) / 120000) + 1
    for _ in range(n):
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        ph, spin = rng.uniform(0, 2 * np.pi), rng.choice([-1, 1])
        pts = []
        for _ in range(int(rng.uniform(300, 900))):
            th = theta[int(np.clip(y, 0, H - 1)), int(np.clip(x, 0, W - 1))]
            x, y = x + np.cos(th) * 0.35 * rc, y + np.sin(th) * 0.35 * rc  # the coil travels slower than it turns
            ph += spin * rng.uniform(0.45, 0.6)
            r = rc * rng.uniform(0.85, 1.1)
            pts.append((x + r * np.cos(ph), y + r * np.sin(ph)))
        P = np.array(pts)
        q = np.linspace(0, len(P) - 1, int(len(P) * 0.6 * rc / f) + 2)  # every ~half a px along the rope
        deposit(rope, np.interp(q, np.arange(len(P)), P[:, 0]), np.interp(q, np.arange(len(P)), P[:, 1]))
    # the rope piles up where its loops overlap: height from how much was laid, spread to its thickness
    R = 0.35 * rc
    one = 2 / (np.sqrt(2 * np.pi) * 0.5 * R)  # the peak a single rope leaves
    tube = R * np.sqrt(blur(rope, 0.5 * R) / one)
    lv = p["sy_level"]
    tube = tube * (1 - lv) + blur(tube, (4 + 30 * lv) * f) * lv * 1.4  # gravity pulls it flat
    # the sheet: smooth over the strokes, deeper over the hollows between them
    sheet = p["sy_sheet"] * 12 * f
    level = blur(base, 40 * f) * 0.8 + base * 0.2 + sheet + fbm(W, H, 500 * f, p["seed"], 2) * 4 * f
    surf = np.maximum(level, base + 1.5 * f) + tube
    # bubbles trapped in it
    bub = np.zeros((H, W), np.float32)
    for _ in range(int(p["sy_bubbles"] * W * H / (f * f) / 40000)):
        bx, by = rng.uniform(0, W), rng.uniform(0, H)
        br = min(f * 2.5 * (1 - rng.random() * 0.9) ** -0.8, 14 * f)
        cv2.circle(bub, (int(bx * 4), int(by * 4)), int(br * 4), 1.0, -1, cv2.LINE_AA, shift=2)
    return dict(H=surf.astype(np.float32), depth=(surf - base).astype(np.float32), bub=blur(bub, 0.6 * f))


def tone(p, S, light, f):
    z, depth, bub = S["H"], S["depth"], S["bub"]
    n = normals(z, p["relief"])
    L = light3(light)
    lam = np.clip(n @ L, 0, 1)
    hv = L + np.array([0, 0, 1], np.float32)
    hv /= np.linalg.norm(hv)
    nh = np.clip(n @ hv, 0, 1)
    through = np.exp(-p["sy_depth"] * depth / (20 * f))  # light that makes it down and back
    t = 0.12 + 0.75 * through + 0.12 * (lam - L[2])
    t = t * (1 - 0.2 * bub * (1 - bub) * 4) + 0.15 * bub ** 4  # bubbles: a faint rim, a bright point
    t += p["sy_gloss"] * (0.9 * nh ** 120 + 0.12 * nh ** 14)
    return t
