"""Shag rug: yarn tufted through a backing, cut, and left to fall over.

Built in the order it is made:

  tuft     a gun punches yarn through the backing in close rows; each tuft is cut, so it stands
           up as a little bundle of plies, twisted round each other
  fall     long pile cannot stand: each tuft flops over and lies on its neighbours, bending as it
           goes. How flat it lies is Fall; the longer it lies, the more of it is seen from above
  comb     a rug that has been brushed (or walked across) lies one way, the flow; a new one lies
           every which way (Combed)
  light    deep down between the tufts it is dark; the tops of the tufts catch the light, and yarn
           has a sheen along its plies; some tufts are a second yarn (Heather)

Tufts are drawn one by one into a height field, each in its own frame: u from the root along the
way it lies, v across. surface() also keeps which tuft is on top and which way its yarn runs.
"""
import numpy as np

import stone
from fields import fbm, hash1, hex_rgb, lin, light3, normals, smoothstep, srgb

KEYS = ("sh_pile", "sh_spacing", "sh_fall", "sh_comb", "sh_curl", "sh_plies")
SHADE_KEYS = ("sh_sheen",)


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 91)
    slab = p["host"] == "slab"
    z = base.copy() - 6 * f  # the backing, down at the roots
    if slab:
        z += fbm(W, H, 600 * f, p["seed"], 2) * 12 * f
    on = np.ones((H, W), bool) if slab else base > 0.5 * f
    tid = np.full((H, W), -1, np.int32)
    ang = np.zeros((H, W), np.float32)
    sp = p["sh_spacing"] * f
    fall = p["sh_fall"]
    # roots on a jittered grid, only where there is rug
    gy, gx = np.mgrid[0:H:sp, 0:W:sp]
    gx = (gx + rng.uniform(0, sp, gx.shape)).ravel()
    gy = (gy + rng.uniform(0, sp, gy.shape)).ravel()
    keep = on[np.clip(gy.astype(int), 0, H - 1), np.clip(gx.astype(int), 0, W - 1)]
    gx, gy = gx[keep], gy[keep]
    n = len(gx)
    order = rng.permutation(n)
    plies = max(1, int(p["sh_plies"]))
    for j, i in enumerate(order):
        x, y = gx[i], gy[i]
        th0 = theta[int(min(y, H - 1)), int(min(x, W - 1))]
        a = th0 + rng.normal(0, 0.3) if rng.random() < p["sh_comb"] else rng.uniform(-np.pi, np.pi)
        pile = p["sh_pile"] * f * rng.uniform(0.8, 1.2)
        l = pile * (0.15 + 0.85 * fall) * rng.uniform(0.8, 1.15)  # how much of it shows from above
        w = sp * rng.uniform(0.5, 0.68)
        bend = p["sh_curl"] * rng.uniform(-1, 1) * 1.3 / max(l, 1)
        R = int(l + w + 2)
        x0, x1, y0, y1 = max(0, int(x) - R), min(W, int(x) + R + 1), max(0, int(y) - R), min(H, int(y) + R + 1)
        if x0 >= x1 or y0 >= y1:
            continue
        dx = np.arange(x0, x1, dtype=np.float32)[None, :] - x
        dy = np.arange(y0, y1, dtype=np.float32)[:, None] - y
        ca, sa = np.cos(a), np.sin(a)
        u = dx * ca + dy * sa
        v = -dx * sa + dy * ca - bend * u * u  # it curls as it lies
        s = np.clip(u / max(l, 1), 0, 1)
        wu = w * (1 - 0.35 * s * s)
        q = v / wu
        cap = np.where(u < 0, (u / w) ** 2, 0) + np.where(u > l, ((u - l) / wu) ** 2, 0)  # round root and tip
        inside = q * q + cap < 1
        if not inside.any():
            continue
        dome = np.sqrt(np.clip(1 - q * q - cap, 0, 1))
        # it stands at the root and lies at the tip, with the bend in between highest
        lift = pile * (1 - fall) * 0.5 * (1 - s) + pile * 0.25 * np.sin(np.pi * np.clip(s * 1.3, 0, 1)) * fall
        twist = np.abs(np.sin(np.pi * (q * plies * 0.5 + u / (2.2 * w) + hash1(i * 1.3) * 3)))
        h = z[int(min(y, H - 1)), int(min(x, W - 1))] + lift + 0.7 * w * dome + 0.18 * w * twist * dome
        zz = z[y0:y1, x0:x1]
        top = inside & (h > zz)
        zz[top] = h[top]
        tid[y0:y1, x0:x1][top] = i
        ang[y0:y1, x0:x1][top] = (a + np.arctan(2 * bend * u))[top]
    return dict(H=z, tid=tid, ang=ang)


def tone(p, S, light, f):
    z, tid, ang = S["H"], S["tid"], S["ang"]
    t = stone.tone(p, z, light, f, local=30 * f)
    # yarn sheen along the plies (Kajiya-Kay), view from above
    L = light3(light)
    hv = (L + np.array([0, 0, 1], np.float32))
    hv /= np.linalg.norm(hv)
    th = np.cos(ang) * hv[0] + np.sin(ang) * hv[1]
    t += p["sh_sheen"] * 0.3 * np.sqrt(np.clip(1 - th * th, 0, 1)) ** 30 * (tid >= 0)
    t += 0.05 * (hash1(np.clip(tid, 0, None) * 0.37 + p["seed"]) - 0.5) * (tid >= 0)
    return t


def recolour(img, mask, frm, to):
    """Swap the picked colour for another where mask is set, keeping every pixel's light and dark."""
    ratio = (lin(to) + 0.01) / (lin(frm) + 0.01)
    im = img.astype(np.float32) / 255
    li = np.where(im <= 0.04045, im / 12.92, ((im + 0.055) / 1.055) ** 2.4)
    out = srgb(li * ratio)
    m = mask.astype(np.float32)[..., None]
    return np.clip(img * (1 - m) + out * m, 0, 255).astype(np.uint8)


def paint(p, img, S, f):
    """Heather: a share of the tufts are the second yarn."""
    if p["sh_heather"] <= 0:
        return img
    tid = S["tid"]
    m = (tid >= 0) & (hash1(np.clip(tid, 0, None) * 2.71 + 0.5) < p["sh_heather"])
    return recolour(img, m, p["color"], p["yarn"])
