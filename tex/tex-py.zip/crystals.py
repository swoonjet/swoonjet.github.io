"""Crystals: the same strokes, painted with small triangular shards instead of fibres.

The stroke geometry (coil or fans) and the silk tone field are computed as usual; then every
stroke is strewn with shards, laid in stroke order so a later pass covers an earlier one. A shard
is a thin, slightly irregular triangle pointing along the flow. Its colour starts from the silk
tone under its centre (so it keeps the body light, the cast shadow and the occlusion) and is then
turned by its own facet: each shard leans a little out of the page, so it catches the light more
or less than its neighbours, and the ones that face the light just right flash.

  body     shards drawn with an opacity and a blend mode over a ground
  ground   the dark of the ramp, or some of the silk underneath (underlay)
  sparkle  a second pass of the same shards in the highlight colour, own blend mode

Only shards whose centre is on the visible top of their pass are drawn: a pass buried under a later
one would never show, and dropping them keeps the count near density x page / shard area.
"""
import numpy as np
import skia

BLENDS = {
    "Normal": skia.BlendMode.kSrcOver, "Multiply": skia.BlendMode.kMultiply, "Screen": skia.BlendMode.kScreen,
    "Overlay": skia.BlendMode.kOverlay, "Soft light": skia.BlendMode.kSoftLight, "Hard light": skia.BlendMode.kHardLight,
    "Darken": skia.BlendMode.kDarken, "Lighten": skia.BlendMode.kLighten, "Color dodge": skia.BlendMode.kColorDodge,
    "Color burn": skia.BlendMode.kColorBurn, "Add": skia.BlendMode.kPlus, "Difference": skia.BlendMode.kDifference,
    "Luminosity": skia.BlendMode.kLuminosity,
}

MAX_SHARDS = 1_500_000


def _argb(rgb, a):
    """Float sRGB 0..255 and alpha 0..1 -> skia's 0xAARRGGBB ints."""
    c = np.clip(np.round(rgb), 0, 255).astype(np.uint32)
    a = np.clip(np.round(a * 255), 0, 255).astype(np.uint32)
    return (a << 24) | (c[:, 0] << 16) | (c[:, 1] << 8) | c[:, 2]


def _draw(canvas, tri, colors, blend):
    if not len(tri):
        return
    xy = tri.reshape(-1, 2)
    pts = list(map(skia.Point, xy[:, 0].tolist(), xy[:, 1].tolist()))
    v = skia.Vertices(skia.Vertices.kTriangles_VertexMode, pts, None, colors.tolist())
    paint = skia.Paint()
    paint.setAntiAlias(True)
    paint.setBlendMode(BLENDS.get(blend, skia.BlendMode.kSrcOver))
    canvas.drawVertices(v, paint, skia.BlendMode.kDst)  # kDst: the vertex colours as they are


def paint(img, p, idx, tone, lut, geo, light, sc, ss):
    """Shards over img (H*ss x W*ss x 3 uint8, the silk render). Returns a new uint8 image.
    geo: pts, nrm, arc, half (screen px), ex (per-point extras); light: 2-vector across the page."""
    pts, nrm, arc, half, ex = geo
    Hs, Ws = idx.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 13)
    tan = np.stack([nrm[:, 1], -nrm[:, 0]], 1)
    n = len(pts)

    # where shards go: each spine step owns a slab of its width; a slab's share is its area
    step = np.r_[np.hypot(*np.diff(pts, axis=0).T), 0.0]
    step[np.r_[ex["sid"][1:] != ex["sid"][:-1], True]] = 0  # no slab across a gap between strokes
    span = np.clip(ex["hi"] - ex["lo"], 0, 2)
    area = half * span * step
    L0 = p["shard"] * sc  # shard length, screen px
    shard = 0.5 * L0 * L0 / p["elong"]
    m = int(min(MAX_SHARDS, p["density"] * area.sum() / shard))
    if m == 0 or area.sum() == 0:
        return img
    k = rng.choice(n, m, p=area / area.sum())
    v = ex["lo"][k] + rng.random(m) * span[k]
    c = pts[k] + tan[k] * (rng.random(m) * step[k])[:, None] + nrm[k] * (v * half[k])[:, None]

    # keep the shards whose centre is on top: the pixel there belongs to this very pass
    ci = np.clip((c * ss).astype(int), 0, [Ws - 1, Hs - 1])
    top = idx[ci[:, 1], ci[:, 0]] - 1
    on = top >= 0
    same = on & (ex["sid"][np.clip(top, 0, None)] == ex["sid"][k]) & (np.abs(arc[np.clip(top, 0, None)] - arc[k]) < 3 * half[k] + 4 * L0)
    k, v, c, ci = k[same], v[same], c[same], ci[same]
    m = len(k)
    order = np.argsort(arc[k] + rng.random(m) * L0)  # in stroke order, a little shuffled within a pass
    k, v, c, ci = k[order], v[order], c[order], ci[order]

    # shape: a thin triangle pointing along the flow, irregular
    ang = np.arctan2(tan[k, 1], tan[k, 0]) + (1 - p["align"]) * rng.uniform(-np.pi / 2, np.pi / 2, m) + rng.normal(0, 0.08, m)
    d = np.stack([np.cos(ang), np.sin(ang)], 1)
    q = np.stack([-d[:, 1], d[:, 0]], 1)
    L = L0 * np.exp(p["size_var"] * rng.normal(0, 0.6, m))
    Wd = L / p["elong"]
    tip = c + d * (L * rng.uniform(0.35, 0.6, m))[:, None] + q * (Wd * rng.uniform(-0.3, 0.3, m))[:, None]
    b1 = c - d * (L * rng.uniform(0.3, 0.55, m))[:, None] + q * (Wd * rng.uniform(0.3, 0.7, m))[:, None]
    b2 = c - d * (L * rng.uniform(0.3, 0.55, m))[:, None] - q * (Wd * rng.uniform(0.3, 0.7, m))[:, None]
    tri = np.stack([tip, b1, b2], 1) * ss

    # facet: each shard leans out of the page by up to ~55 degrees, in its own direction
    lz = np.sqrt(max(1 - (light ** 2).sum(), 0))
    L3 = np.array([light[0], light[1], lz])
    phi = rng.random(m) ** 0.7 * 0.95
    psi = rng.uniform(0, 2 * np.pi, m)
    nz = np.stack([np.sin(phi) * np.cos(psi), np.sin(phi) * np.sin(psi), np.cos(phi)], 1)
    lam = nz @ L3
    base = tone[ci[:, 1], ci[:, 0]]  # the silk tone under the centre: body light, shadow, occlusion
    t_face = base + p["facet"] * (lam - lz) * 1.6
    tv = t_face[:, None] + p["grad"] * (rng.random((m, 3)) - 0.5) * 2  # a little gradient across each face
    rgb = lut[(np.clip(tv, 0, 1) * 1023).astype(int)].reshape(-1, 3)
    alpha = np.repeat(p["opacity"] * rng.uniform(0.75, 1.0, m), 3)

    # ground: the ramp's dark, with some of the silk showing through
    ground = lut[20][None, None, :]
    under = (ground + (img.astype(np.float32) - ground) * p["underlay"]).astype(np.uint8)
    info = skia.ImageInfo.Make(Ws, Hs, skia.kRGBA_8888_ColorType, skia.kPremul_AlphaType)
    rgba = np.dstack([under, np.full((Hs, Ws), 255, np.uint8)])
    surf = skia.Surface.MakeRaster(info)
    canvas = surf.getCanvas()
    canvas.drawImage(skia.Image.fromarray(np.ascontiguousarray(rgba), skia.kRGBA_8888_ColorType), 0, 0)
    _draw(canvas, tri, _argb(rgb, alpha), p["blend"])

    if p["sparkle"] > 0:  # the shards that face the half vector flash, in the highlight colour
        h = L3 + np.array([0, 0, 1.0])
        h /= np.linalg.norm(h)
        spec = np.clip(nz @ h, 0, 1) ** 60
        hit = spec * p["sparkle"] > 0.02
        if hit.any():
            hi_rgb = np.repeat(lut[1023][None], hit.sum() * 3, 0)
            a = np.repeat(np.clip(spec[hit] * p["sparkle"] * 1.5, 0, 1), 3)
            _draw(canvas, tri[hit], _argb(hi_rgb, a), p["sparkle_blend"])
    out = surf.makeImageSnapshot().toarray(colorType=skia.kRGBA_8888_ColorType)
    return np.ascontiguousarray(out[..., :3])
