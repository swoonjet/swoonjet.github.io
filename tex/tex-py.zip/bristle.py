"""Wide bristle strokes laid scale over scale along a flow.

A riff on gart's Bristles brush (github.com/igr/gart, Crinis / Calamus).
The flow is the curl of a few soft hills over a slow drift. Each stroke
walks that flow for a while and carries 40-100 hairs at their own offsets
across it. A hair is lit as part of a round bundle, runs dry in streaks,
and lets go early at the edges, so the stroke ends ragged. Every stroke
throws a soft shadow on the ones under it. The next stroke starts where
the fewest have been so far, so the page fills itself.

  .venv/bin/python bristle.py -o bristle.png --seed 3
  .venv/bin/python bristle.py --ramp mono      # ink on paper
"""
import argparse

import numpy as np
import skia
from PIL import Image

RAMPS = {  # dark -> light
    "claret": ["#120307", "#3a0a16", "#7b1838", "#a8344f", "#cf6b7c", "#f0c2c4"],
    "warmgrey": ["#1b1916", "#35312c", "#57514a", "#7f776d", "#aaa196", "#d8d0c4"],
    "mono": ["#0b0b0a", "#262523", "#4d4b47", "#86837d", "#c2bfb8", "#f2f1ee"],
}


def hex_rgb(h):
    h = h.lstrip("#")
    return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


def hash1(i):
    return np.modf(np.abs(np.sin(i * 12.9898 + 78.233) * 43758.5453))[0]


def noise1(x):
    """Smooth value noise, 0..1."""
    i = np.floor(x)
    f = x - i
    u = f * f * (3 - 2 * f)
    return hash1(i) * (1 - u) + hash1(i + 1) * u


def noise2(x, y):
    i, j = np.floor(x), np.floor(y)
    fx, fy = x - i, y - j
    ux, uy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
    h = lambda a, b: hash1(a * 157.0 + b * 113.0)
    top = h(i, j) * (1 - ux) + h(i + 1, j) * ux
    bot = h(i, j + 1) * (1 - ux) + h(i + 1, j + 1) * ux
    return top * (1 - uy) + bot * uy


def smoothstep(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


class Flow:
    """Curl of a stream function: a drift plus gaussian hills, so the lines never cross or sink."""

    def __init__(self, rng, W, H, hills, drift):
        self.h = rng.uniform(-0.6, 0.6)
        self.drift = drift
        self.hills = [(rng.uniform(-0.1, 1.1) * W, rng.uniform(-0.1, 1.1) * H,
                       r := W * rng.uniform(0.14, 0.34), r * rng.choice([-1, 1]) * rng.uniform(0.55, 1.0))
                      for _ in range(hills)]

    def dir(self, x, y):
        # psi = drift*(y cos h - x sin h) + sum lift*exp(-d^2/r^2);  v = (dpsi/dy, -dpsi/dx)
        px, py = -self.drift * np.sin(self.h), self.drift * np.cos(self.h)
        for hx, hy, r, lift in self.hills:
            dx, dy = x - hx, y - hy
            e = lift * np.exp(-(dx * dx + dy * dy) / (r * r)) * -2 / (r * r)
            px, py = px + e * dx, py + e * dy
        vx, vy = py, -px
        n = np.hypot(vx, vy) + 1e-9
        return vx / n, vy / n


class Stroke:
    def __init__(self, pts, nrm, arc, half, tone, load, seed, ramp=None, coil=False):
        self.pts, self.nrm, self.arc, self.half = pts, nrm, arc, half
        self.tone, self.load, self.seed = tone, load, seed
        self.ramp, self.coil = ramp, coil  # tone shift along the stroke; one long self-crossing stroke


def walk(flow, start, length, step, hw, rng, W, H):
    """Follow the flow both ways from start; half width swells and pinches along it."""
    def go(sign, n):
        p = np.array(start, float)
        out = []
        prev, tight = None, 0
        for _ in range(n):
            dx, dy = flow.dir(p[0], p[1])
            if prev is not None:  # the brush lifts once its inner edge would fold over: radius under 0.8 half widths for a while
                turn = abs(np.arctan2(prev[0] * dy - prev[1] * dx, prev[0] * dx + prev[1] * dy))
                tight = tight + 1 if turn > step / (hw * 0.8) else 0
                if tight > 8:
                    break
            prev = (dx, dy)
            p = p + sign * step * np.array([dx, dy])
            out.append(p.copy())
            if not (-hw * 2 < p[0] < W + hw * 2 and -hw * 2 < p[1] < H + hw * 2):
                break
        return out
    back = rng.uniform(0.1, 0.5)
    n = int(length / step)
    pts = np.array(go(-1, int(n * back))[::-1] + [np.array(start, float)] + go(1, int(n * (1 - back))))
    if len(pts) < 20:
        return None
    d = np.gradient(pts, axis=0)
    d /= np.linalg.norm(d, axis=1, keepdims=True) + 1e-9
    nrm = np.stack([-d[:, 1], d[:, 0]], 1)
    arc = np.arange(len(pts)) * step
    half = hw * (1 + 0.35 * (noise1(arc / 700 + rng.uniform(0, 100)) - 0.5) * 2)
    return pts, nrm, arc, half


class Cover:
    """The next stroke starts in a cell the fewest strokes have covered so far."""

    def __init__(self, W, H, cell):
        self.cell, self.cw, self.ch = cell, int(W / cell) + 1, int(H / cell) + 1
        self.count = np.zeros((self.ch, self.cw), int)

    def pick(self, rng):
        ys, xs = np.nonzero(self.count == self.count.min())
        k = rng.integers(len(xs))
        return (xs[k] + rng.random()) * self.cell, (ys[k] + rng.random()) * self.cell

    def add(self, s):
        seen = np.zeros_like(self.count, bool)
        gy, gx = np.mgrid[0:self.ch, 0:self.cw]
        cx, cy = (gx + 0.5) * self.cell, (gy + 0.5) * self.cell
        for k in range(0, len(s.pts), 6):
            (x, y), r = s.pts[k], s.half[k]
            seen |= (cx - x) ** 2 + (cy - y) ** 2 < r * r
        self.count += seen


class Ink:
    def __init__(self, stops):
        c = np.array([hex_rgb(h) for h in stops], float)
        self.lut = np.stack([np.interp(np.linspace(0, 1, 1024), np.linspace(0, 1, len(c)), c[:, i]) for i in range(3)], 1)

    def __call__(self, v, a=1.0):
        r, g, b = self.lut[int(np.clip(v, 0, 1) * 1023)]
        return skia.Color4f(r / 255, g / 255, b / 255, a)


def outline(s, k0=0, k1=None, ends=True):
    """Body under the bristles: pinched at both ends where the outer hairs lift, narrowing as paint runs out.
    k0..k1 cuts out one stretch of it; ends=False leaves the stretch square, for a stroke drawn in pieces."""
    n = len(s.pts)
    L = s.arc[-1]
    gone = 1 - s.load(np.arange(n) / (n - 1))
    shape = np.clip((np.minimum(s.arc, L - s.arc) - 0.06 * L) / (0.3 * L), 0, 1)
    if s.coil:  # a long stroke pinches over a fixed length, not a share of it
        shape = np.clip((np.minimum(s.arc, L - s.arc) - 0.15 * s.half.max()) / s.half.max(), 0, 1)
    h = 0.88 * s.half * np.sqrt(shape * smoothstep(0.6, 0.2, gone))
    sl = slice(k0, k1)
    left = s.pts[sl] + s.nrm[sl] * h[sl, None]
    right = s.pts[sl] - s.nrm[sl] * h[sl, None]
    path = skia.Path()
    path.addPoly([skia.Point(*p) for p in np.concatenate([left, right[::-1]])], True)
    return path


def drop_shadow(c, path, ink, shadow):
    for sigma, a, off in ((45, 0.75, 18), (8, 0.8, 5)):
        p = skia.Paint(Color4f=ink(0.0, a * shadow), AntiAlias=True,
                       MaskFilter=skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, sigma))
        c.save(); c.translate(off * 0.4, off); c.drawPath(path, p); c.restore()


def draw_stroke(c, s, ink, rng, pitch, light, body, shadow, piece=None, alpha=0.92, smooth=0.0):
    """One stroke. With piece (in spine points) it goes down a stretch at a time, hairs and all,
    so where it comes back over itself the later stretch lies on the earlier one and shadows it.
    smooth (0..1) calms the hairs: even widths and tones, no dry gaps, no stray hairs, softer alpha."""
    rough = 1 - smooth
    n = len(s.pts)
    step = s.arc[1]
    gone = 1 - s.load(np.arange(n) / (n - 1))
    lz = np.sqrt(1 - light[0] ** 2 - light[1] ** 2)
    count = int(2 * s.half.max() / pitch)
    hairs = []
    for j in range(count):
        t0 = -1 + 2 * (j + rng.random()) / count
        if s.coil:  # the outer hairs lift over a fixed length at the very ends
            trim = int(s.half.max() * (0.2 + 1.6 * t0 * t0 + 0.6 * rng.random()) / step)
        else:  # outer hairs let go first
            trim = int(s.arc[-1] * (0.03 + 0.22 * t0 * t0 + 0.08 * rng.random()) / step)
        if n - 2 * trim >= 4:
            hairs.append((t0, pitch * rng.uniform(0.45 + 0.45 * smooth, 0.9 + 0.4 * smooth),
                          s.tone + 0.07 + 0.55 * (1 - 0.75 * smooth) * (rng.random() - 0.5),
                          rng.uniform(0, 500), trim))
    paint = skia.Paint(AntiAlias=True, Style=skia.Paint.kStroke_Style, StrokeCap=skia.Paint.kRound_Cap,
                       StrokeJoin=skia.Paint.kRound_Join)
    piece = piece or n
    lead = int(1.5 * s.half.max() / step)  # a stretch casts no shadow on the one it grows out of
    for k0 in range(0, n - 1, piece):
        k1 = min(n, k0 + piece + 1)
        mid = s.ramp[(k0 + k1) // 2] if s.ramp is not None else 0.0
        if shadow > 0:
            if k0 == 0:
                drop_shadow(c, outline(s, 0, k1), ink, shadow)
            elif k1 - k0 > lead:
                drop_shadow(c, outline(s, k0 + lead, k1), ink, shadow)
        c.drawPath(outline(s, k0, k1), skia.Paint(Color4f=ink(s.tone + mid - body * (1 - 0.7 * smooth)), AntiAlias=True))
        sl = slice(k0, k1)
        a, g, nrm = s.arc[sl], gone[sl], s.nrm[sl]
        for t0, wid, base, ph, trim in hairs:
            if k1 <= trim or k0 >= n - trim:
                continue
            t = t0 + 0.035 * (1 - 0.85 * smooth) * (noise1(a / 380 + ph) - 0.5) * 2
            dry = noise1(a / 45 + ph * 1.3)
            lim = 0.95 + 0.6 * smooth - 0.5 * t * t - 0.4 * g
            dw = smoothstep(lim, lim - 0.15, dry) * (1 - 0.2 * rough + 0.4 * rough * noise1(a / 90 + ph * 2.1))
            hi = 1.2 - 1.75 * g ** 1.5  # long dry streaks once the load runs low
            dw = np.where(g > 0, dw * (1 - 0.3 * g) * smoothstep(hi, hi - 0.2, noise1(a / 220 + ph * 0.7)), dw)
            q = t * 0.85
            lam = (nrm[:, 0] * light[0] + nrm[:, 1] * light[1]) * q + np.sqrt(np.clip(1 - q * q, 0, 1)) * lz
            v = (base + 0.22 * (lam - lz) + 0.14 * (noise1(a / 1500 + s.seed * 0.37) - 0.5)
                 + 0.2 * (1 - 0.5 * smooth) * (noise2(t * 2.2 + s.seed * 3.1, a / 700) - 0.5) * 2
                 + 0.1 * rough * (noise1(a / 140 + ph * 0.7) - 0.5) * 2
                 - 0.05 * smoothstep(0.8, 1, np.abs(t)) + 0.16 * g)
            if s.ramp is not None:
                v = v + s.ramp[sl]
            p = s.pts[sl] + nrm * (s.half[sl] * t)[:, None]
            kk = np.arange(k0, k1)
            on = (np.abs(t) <= 1.02) & (dw > 0.02) & (kk >= trim) & (kk < n - trim)
            m = len(a)
            # runs of one tone and one width: a cut where it goes dry, or where its tone has moved
            k = 0
            while k < m:
                if not on[k]:
                    k += 1
                    continue
                e = k + 1
                while e < m and on[e] and abs(v[e] - v[k]) < 0.06 and e - k < 80:
                    e += 1
                if e - k >= 2:
                    path = skia.Path()
                    path.addPoly([skia.Point(*pt) for pt in p[k:e + (e < m and on[e])]], False)
                    paint.setStrokeWidth(float(wid * np.sqrt(dw[k:e].mean())))
                    paint.setColor4f(ink(float(v[k:e].mean()), alpha))
                    c.drawPath(path, paint)
                k = e


def coil(rng, W, H, length, hw, step=2.0, swirl=0.7, bare=0.005, cap=1.6, widen=1.0, swell=0.25):
    """One long stroke that winds back over itself until the page is full: walked by its bend, two
    slow waves of curvature plus a lean that makes it loop, and always steering for the emptiest part
    of the page it has not painted yet. Never tighter than the brush can take without its inner edge
    folding."""
    kmax = 1 / (hw * 1.6 * widen)  # the inner edge of the widest part must never fold
    S = min(W, H)
    p1, p2 = S * rng.uniform(1.0, 2.0), S * rng.uniform(0.35, 0.6)
    f1, f2 = rng.uniform(0, 2 * np.pi, 2)
    a1, a2 = rng.uniform(0.4, 0.9), rng.uniform(0.1, 0.3)
    bias = swirl * rng.choice([-1, 1]) * rng.uniform(0.6, 1.0)
    # coverage: how often the stroke has gone over each cell, the page plus a margin it may paint past
    cell, m = 40, hw * 0.5
    gx, gy = np.meshgrid(np.arange(-m, W + m, cell) + cell / 2, np.arange(-m, H + m, cell) + cell / 2)
    count = np.zeros(gx.shape)
    # it lands off the page and sweeps in, so no start shows
    out = 1.6 * hw
    side = rng.integers(4)
    along = rng.uniform(0.2, 0.8)
    p, th = [(np.array([-out, H * along]), 0.0), (np.array([W + out, H * along]), np.pi),
             (np.array([W * along, -out]), np.pi / 2), (np.array([W * along, H + out]), -np.pi / 2)][side]
    th += rng.uniform(-0.4, 0.4)
    target = np.array([W / 2, H / 2])
    inside = (gx > 0) & (gx < W) & (gy > 0) & (gy < H)
    n = int(length / step)
    pts = []
    i = 0
    while i < n * cap:  # past the planned length only while bare page is left
        if i % 60 == 0:  # every 120 px: paint the last stretch into coverage, then pick where to head
            for q in pts[-60::6]:
                count += (gx - q[0]) ** 2 + (gy - q[1]) ** 2 < (0.8 * hw) ** 2
            if i >= n and (count[inside] == 0).mean() < bare:
                break
            if i >= 240:  # get onto the page first, aimed at the middle
                dist = np.hypot(gx - p[0], gy - p[1])
                score = 3 * np.minimum(count, 4) + dist / S * 0.8 + (dist < 2.5 * hw) * 1e3 + rng.random(count.shape) * 0.3
                j = np.argmin(score)
                target = np.array([gx.flat[j], gy.flat[j]])
        sarc = i * step
        k = kmax * np.clip(a1 * np.sin(2 * np.pi * sarc / p1 + f1) + a2 * np.sin(2 * np.pi * sarc / p2 + f2) + bias, -1, 1)
        off = (np.arctan2(target[1] - p[1], target[0] - p[0]) - th + np.pi) % (2 * np.pi) - np.pi
        u = min(i / n, 1)  # the loops lead early on, the hunt for bare page later
        th += (0.6 - 0.3 * u) * k * step + (0.7 + 0.6 * u) * np.clip(off, -kmax * step, kmax * step)
        p = p + step * np.array([np.cos(th), np.sin(th)])
        pts.append(p.copy())
        i += 1
    # and it leaves off the page: head for the nearest edge and carry on until the whole width is past it
    for _ in range(int(4 * (W + H) / step)):
        x, y = p
        if x < -out or x > W + out or y < -out or y > H + out:
            break
        edges = [(x, np.array([-3 * out, y])), (W - x, np.array([W + 3 * out, y])),
                 (y, np.array([x, -3 * out])), (H - y, np.array([x, H + 3 * out]))]
        target = min(edges, key=lambda e: e[0])[1]
        off = (np.arctan2(target[1] - p[1], target[0] - p[0]) - th + np.pi) % (2 * np.pi) - np.pi
        th += np.clip(off, -kmax * step, kmax * step)
        p = p + step * np.array([np.cos(th), np.sin(th)])
        pts.append(p.copy())
    pts = np.array(pts)
    for q in pts[-60::6]:
        count += (gx - q[0]) ** 2 + (gy - q[1]) ** 2 < (0.8 * hw) ** 2
    print(f"bare page {100 * (count[inside] == 0).mean():.1f}%, mean passes {count[inside].mean():.1f}")
    d = np.gradient(pts, axis=0)
    d /= np.linalg.norm(d, axis=1, keepdims=True) + 1e-9
    nrm = np.stack([-d[:, 1], d[:, 0]], 1)
    arc = np.arange(len(pts)) * step
    half = hw * (1 + swell * (noise1(arc / 900 + rng.uniform(0, 100)) - 0.5) * 2)
    return pts, nrm, arc, half


def finish(a, surf, W, H, ink):
    """Flecks, downsample, grain, save."""
    c = surf.getCanvas()
    c.save(); c.resetMatrix(); c.scale(a.ss, a.ss)
    # flecks: clumped by noise, a few big ones
    sp = np.random.default_rng(a.seed * 31 + 7)
    xs, ys = sp.uniform(0, W, a.specks * 4), sp.uniform(0, H, a.specks * 4)
    keep = noise2(xs / 260, ys / 260) > sp.random(len(xs)) * 1.6
    dot = skia.Paint(AntiAlias=True, Color4f=ink(0.0, 0.92))
    for x, y in list(zip(xs[keep], ys[keep]))[: a.specks]:
        c.drawCircle(x, y, float(1.0 + 3.8 * sp.random() ** 3), dot)
    c.restore()

    img = Image.fromarray(surf.makeImageSnapshot().toarray()[..., :3])
    img = img.resize((W, H), Image.LANCZOS)
    if a.grain > 0:
        px = np.asarray(img, np.float32)
        px += (np.random.default_rng(a.seed).random(px.shape[:2]) - 0.5)[..., None] * 2 * a.grain * 40
        img = Image.fromarray(np.clip(px, 0, 255).astype(np.uint8))
    img.save(a.out)
    print(a.out)




def render_single(a, W, H, rng, ink):
    hw = min(W, H) * a.coil_width / 2
    w = coil(rng, W, H, a.fill * W * H / (2 * hw), hw, swirl=a.swirl)
    n = len(w[0])
    # later turns lie on top, so they come up lighter; full of paint all the way, both ends off the page
    ramp = a.depth * (np.arange(n) / (n - 1) - 0.5)
    s = Stroke(*w, tone=0.52, load=lambda t: np.ones_like(t), seed=a.seed * 101,
               ramp=ramp, coil=True)
    surf = skia.Surface(W * a.ss, H * a.ss)
    with surf as c:
        c.clear(ink(0.03))
        c.scale(a.ss, a.ss)
        draw_stroke(c, s, ink, np.random.default_rng(a.seed * 7919 + 1), a.pitch, (-0.42, -0.62), 0.38,
                    a.shadow, piece=int(4 * hw / s.arc[1]), smooth=a.smooth)
    print(f"one stroke, {s.arc[-1]:.0f} px long, {int(2 * s.half.max() / a.pitch)} hairs")
    finish(a, surf, W, H, ink)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-o", "--out", default="bristle.png")
    ap.add_argument("--seed", type=int, default=3)
    ap.add_argument("--size", default="1600x2000", help="WxH; 2560x1440 is a 16:9 desktop wallpaper")
    ap.add_argument("--ss", type=int, default=2, help="supersampling")
    ap.add_argument("--strokes", type=int, default=80)
    ap.add_argument("--hills", type=int, default=6, help="whirls in the flow")
    ap.add_argument("--drift", type=float, default=0.7, help="straight current under the whirls")
    ap.add_argument("--width", type=float, default=0.17, help="stroke width, share of W")
    ap.add_argument("--length", type=float, default=0.9, help="stroke length, share of H")
    ap.add_argument("--pitch", type=float, default=2.4, help="px between hairs")
    ap.add_argument("--dry", type=float, default=0.6, help="share of strokes that run out of paint")
    ap.add_argument("--shadow", type=float, default=1.0)
    ap.add_argument("--depth", type=float, default=0.4, help="tone spread from the bottom strokes (dark) to the top (light)")
    ap.add_argument("--layers", type=int, default=4, help="depth passes: each finished pass sinks under a veil and a blur")
    ap.add_argument("--veil", type=float, default=0.3, help="darkening laid over each finished pass")
    ap.add_argument("--dof", type=float, default=2.5, help="blur on the deepest pass, px")
    ap.add_argument("--specks", type=int, default=900, help="black flecks over the top")
    ap.add_argument("--grain", type=float, default=0.12)
    ap.add_argument("--ramp", choices=list(RAMPS), default="claret")
    ap.add_argument("--smooth", type=float, default=0.0, help="0 = bristly, 1 = even, silky hairs")
    ap.add_argument("--single", action="store_true", help="one long stroke winding back over itself")
    ap.add_argument("--fill", type=float, default=3.0, help="single: stroke length as times over the whole page")
    ap.add_argument("--coil-width", type=float, default=0.3, help="single: stroke width, share of the short side")
    ap.add_argument("--swirl", type=float, default=0.7, help="single: how hard it leans into loops")
    a = ap.parse_args()

    W, H = (int(v) for v in a.size.split("x"))
    rng = np.random.default_rng(a.seed)
    ink = Ink(RAMPS[a.ramp])
    if a.single:
        render_single(a, W, H, rng, ink)
        return
    flow = Flow(rng, W, H, a.hills, a.drift)

    cover = Cover(W, H, 40)
    strokes = []
    for i in range(a.strokes):
        hw = W * a.width * rng.uniform(0.55, 1.25) / 2
        w = walk(flow, cover.pick(rng), H * a.length * rng.uniform(0.5, 1.3), 3.0, hw, rng, W, H)
        if w is None:
            continue
        dries = rng.random() < a.dry
        k = rng.uniform(0.5, 1.0)
        load = (lambda t, k=k: np.clip(1 - t, 0, 1) ** k) if dries else (lambda t: np.ones_like(t))
        depth = i / max(a.strokes - 1, 1)
        s = Stroke(*w, tone=rng.uniform(0.35, 0.65) + a.depth * (depth - 0.5), load=load, seed=i + a.seed * 101)
        cover.add(s)
        strokes.append(s)
    print(f"strokes {len(strokes)}, uncovered cells {(cover.count == 0).sum()}")

    surf = skia.Surface(W * a.ss, H * a.ss)
    with surf as c:
        c.clear(ink(0.03))
        c.scale(a.ss, a.ss)
        hair = np.random.default_rng(a.seed * 7919 + 1)
        bounds = np.linspace(0, len(strokes), a.layers + 1).astype(int)
        for L in range(a.layers):
            for s in strokes[bounds[L]:bounds[L + 1]]:
                # strokes nearer the top sit higher, so they throw longer shadows
                lift = 0.6 + 0.8 * L / max(a.layers - 1, 1)
                draw_stroke(c, s, ink, hair, a.pitch, (-0.42, -0.62), 0.38, a.shadow * lift, smooth=a.smooth)
            print(f"layer {L + 1}/{a.layers}")
            if L < a.layers - 1:  # sink what is down: soften it and darken it, more for the deeper ones
                left = a.layers - 1 - L
                sigma = a.dof * a.ss * (left / (a.layers - 1)) ** 0.5 / 2
                snap = surf.makeImageSnapshot()
                c.save(); c.resetMatrix()
                c.drawImage(snap, 0, 0, paint=skia.Paint(ImageFilter=skia.ImageFilters.Blur(sigma, sigma, skia.TileMode.kClamp)))
                c.restore()
                c.drawRect(skia.Rect(0, 0, W, H), skia.Paint(Color4f=ink(0.0, a.veil)))
    finish(a, surf, W, H, ink)


if __name__ == "__main__":
    main()
