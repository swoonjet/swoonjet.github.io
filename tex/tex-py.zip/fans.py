"""Fans: many short strokes swept round vortices, after gart's Cincinnus (arts/lines/cincinnus).

A handful of vortex eyes sit off the page; every stroke is a streamline of their sum, so the strokes
curve in families and lie on each other like feathers. A stroke starts with a rounded, lopsided head
(the scalloped edges are what read), runs a share of the way round its eye, and is never wider than its
bend allows. Strokes go where the page is least covered; the big ones are laid first, so the small
late ones sit on top.

fans(p, W, H) returns the same spine arrays as bristle.coil, concatenated over all strokes, plus the
per-point extras silk.render needs to draw separate strokes from one index buffer.
"""
import math

import cv2
import numpy as np

from bristle import hash1, noise1

DS = 3.0  # trace step, reference px


def _field(rng, W, H, eyes, S):
    """Vortex eyes off the page, spread apart; returns a fast scalar field function and the eyes."""
    def off_page():
        while True:
            x, y = W * rng.uniform(-0.4, 1.4), H * rng.uniform(-0.4, 1.4)
            if max(-x, x - W, -y, y - H) > 0.08 * S:
                return x, y
    pts = []
    for _ in range(eyes):
        cands = [off_page() for _ in range(12)]
        pts.append(max(cands, key=lambda q: min((math.hypot(q[0] - e[0], q[1] - e[1]) for e in pts), default=0)))
    vort = [(x, y, -rng.uniform(0.6, 1.4), (S * 0.3 * rng.uniform(0.7, 1.3)) ** 2) for x, y in pts]

    def f(x, y):
        vx = vy = 0.0
        for cx, cy, spin, r2max in vort:
            dx, dy = x - cx, y - cy
            r2 = dx * dx + dy * dy
            if r2 == 0:
                continue
            w = 1 / (1 + r2 / r2max) / math.sqrt(r2)
            vx -= dy * spin * w
            vy += dx * spin * w
        return vx, vy
    return f, pts


def _trace(f, x, y, steps, ds, box):
    """RK4 along the unit field."""
    def u(x, y):
        vx, vy = f(x, y)
        l = math.hypot(vx, vy) or 1.0
        return vx / l, vy / l
    out = [(x, y)]
    x0, y0, x1, y1 = box
    for _ in range(steps):
        k1 = u(x, y)
        k2 = u(x + k1[0] * ds / 2, y + k1[1] * ds / 2)
        k3 = u(x + k2[0] * ds / 2, y + k2[1] * ds / 2)
        k4 = u(x + k3[0] * ds, y + k3[1] * ds)
        x += ds * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]) / 6
        y += ds * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]) / 6
        if not (x0 < x < x1 and y0 < y < y1):
            break
        out.append((x, y))
    return out


def _radius(pts):
    """Radius of curvature at each point, over a few steps either side."""
    n = len(pts)
    d = np.diff(pts, axis=0)
    head = np.arctan2(d[:, 1], d[:, 0])
    i0 = np.clip(np.arange(n) - 4, 0, n - 2)
    i1 = np.clip(np.arange(n) + 4, 0, n - 2)
    turn = (head[i1] - head[i0] + np.pi) % (2 * np.pi) - np.pi
    with np.errstate(divide="ignore"):
        r = np.where((i1 == i0) | (np.abs(turn) < 1e-4), 1e6, (i1 - i0) * DS / np.abs(turn))
    return r


def _head(hw, rng, rough):
    """Where along the stroke each hair starts, by its place across (v in -1..1): a rounded, lopsided cap."""
    lean = rng.uniform(-0.6, 0.6)
    long = 1 + (rng.uniform(0.55, 1.2) - 1) * rough
    tilt = rough * lean * long
    lumps, ph = rng.uniform(1.5, 4), rng.uniform(0, 100)
    v = np.linspace(-1, 1, 65)
    raw = hw * (0.8 * long * (1 - np.sqrt(1 - v * v)) + tilt * v + rough * 0.18 * noise1(v * lumps + ph))
    return v, raw - raw.min()


class _Cover:
    """How often strokes have gone over each cell of the page."""
    def __init__(self, W, H, cell):
        self.cell = cell
        self.count = np.zeros((int(H / cell) + 1, int(W / cell) + 1), np.int32)

    def pick(self, rng):
        lo = self.count.min()
        j, i = np.nonzero(self.count == lo)
        k = rng.integers(len(i))
        return (i[k] + rng.random()) * self.cell, (j[k] + rng.random()) * self.cell

    def mark(self, x, y):
        j = int(np.clip(round(y / self.cell), 0, self.count.shape[0] - 1))
        i = int(np.clip(round(x / self.cell), 0, self.count.shape[1] - 1))
        self.count[j, i] += 1

    def add(self, s):
        m = np.zeros(self.count.shape, np.uint8)
        P, N, half, lo, hi = s["pts"], s["nrm"], s["half"], s["lo"], s["hi"]
        for k in range(0, len(P) - 3, 3):
            if lo[k] >= hi[k]:
                continue
            q = np.array([P[k] + N[k] * half[k] * hi[k], P[k + 3] + N[k + 3] * half[k + 3] * hi[k],
                          P[k + 3] + N[k + 3] * half[k + 3] * lo[k], P[k] + N[k] * half[k] * lo[k]])
            cv2.fillConvexPoly(m, np.round(q / self.cell).astype(np.int32), 1)
        self.count += m

    def bare(self):
        return int((self.count == 0).sum())


def _stroke(f, eyes, x, y, rng, k, W, H, p):
    S = min(W, H)
    size = min(math.hypot(x - ex, y - ey) for ex, ey in eyes)
    if size < 25 * k:
        return None
    hw = min(size * p["fat"] * rng.uniform(0.85, 1.15), 120 * k)
    v, head = _head(hw, rng, p["rough"])
    m = 500 * k
    box = (-m, -m, W + m, H + m)
    long = 1600 * k
    reach = min(0.9 * size * 2 * np.pi * rng.uniform(0.95, 1.03) + 120 * k + 0.4 * hw, long)
    fwd = _trace(f, x, y, int(reach / DS) + 1, DS, box)
    back = _trace(f, x, y, int((head.max() + 20 * k) / DS), -DS, box)[::-1]
    pts = np.array(back + fwd[1:])
    nb = len(back) - 1
    inside = (pts[:, 0] > -hw) & (pts[:, 0] < W + hw) & (pts[:, 1] > -hw) & (pts[:, 1] < H + hw)
    if not inside.any():
        return None
    most = min(len(pts), nb + int(reach / DS), np.nonzero(inside)[0][-1] + 2)
    end = max(2, int(most * rng.uniform(0.5, 1.0)))
    pts = pts[:end]
    if len(pts) < 20:
        return None
    n = len(pts)

    # never wider than the bend: the inner edge would fold
    rad = _radius(pts)
    w = max(4, int(2 * hw / DS))
    lows = np.array([0.8 * rad[max(0, i - w):i + w + 1].min() for i in range(n)])
    room = np.array([lows[max(0, i - w):i + w + 1].mean() for i in range(n)])
    t = np.arange(n) / (n - 1)
    ph = rng.uniform(0, 100)
    load = 1 - t ** 4
    landing = 1 + 0.12 * (1 - np.clip(t / 0.05, 0, 1))
    half = np.minimum(hw * (0.75 + 0.25 * load) * landing * (1 + 0.2 * (noise1(t * 3 + ph) - 0.5) * 2), room)
    if half.mean() < 30 * k:
        return None

    # cut off tight hooks: keep the longest run that bends no tighter than the brush is wide
    ok = rad >= hw
    best, run = (0, 0), 0
    for i, o in enumerate(list(ok) + [False]):
        if o:
            run += 1
        else:
            if run > best[1] - best[0]:
                best = (i - run, i)
            run = 0
    a, b = best
    if b - a < 20:
        return None
    pts, half, t = pts[a:b], half[a:b], t[a:b]
    n = len(pts)
    d = np.gradient(pts, axis=0)
    d /= np.maximum(np.hypot(d[:, 0], d[:, 1]), 1e-9)[:, None]
    nrm = np.stack([-d[:, 1], d[:, 0]], 1)
    s = np.arange(n) * DS  # arc from where this stroke begins

    # the head: hair at v starts at head(v); so at arc s the stroke covers the v where head(v) <= s
    lo, hi = np.full(n, 1.0), np.full(n, -1.0)
    if a == 0:
        for i in range(n):
            on = v[head <= s[i]]
            if len(on):
                lo[i], hi[i] = on.min(), on.max()
    else:
        lo[:], hi[:] = -1, 1
    # a rounded tip
    r = 0.6 * half[-1]
    x = np.clip((s - (s[-1] - r)) / max(r, 1e-6), 0, 1)
    lim = np.sqrt(np.clip(1 - x * x, 0, 1))
    lo, hi = np.maximum(lo, -lim), np.minimum(hi, lim)
    return dict(pts=pts, nrm=nrm, half=half, lo=lo, hi=hi, t=t, hw=hw, size=size)


def fans(p, W, H):
    S = min(W, H)
    k = S / 2000  # Cincinnus's numbers are for a 2000 px page
    rng = np.random.default_rng(p["seed"])
    f, eyes = _field(rng, W, H, int(p["eyes"]), S)
    cover = _Cover(W, H, 20 * k)
    laid, tries = [], 0
    target = int(p["strokes"])

    def place(cov, rng):
        x, y = cov.pick(rng)
        s = _stroke(f, eyes, x, y, rng, k, W, H, p)
        if s is None:  # step aside, across the flow, and try once more
            vx, vy = f(x, y)
            l = math.hypot(vx, vy) or 1
            s = _stroke(f, eyes, x - vy / l * 37 * k, y + vx / l * 37 * k, rng, k, W, H, p)
            cov.mark(x, y)
        if s is not None:
            cov.add(s)
        return s

    enough = cover.count.size * 0.002  # the last few cells are usually corners no stroke can reach
    while (len(laid) < target or cover.bare() > enough) and tries < 600:
        tries += 1
        s = place(cover, rng)
        if s is not None:
            laid.append(s)
    main = sorted(laid[:target], key=lambda s: -s["size"])
    filler = sorted(laid[target:], key=lambda s: -s["size"])
    order = filler + main  # big and early underneath, the chosen strokes on top
    depth = [0.0] * len(filler) + [i / max(len(main) - 1, 1) for i in range(len(main))]

    # concatenate: arc jumps between strokes so nothing joins them, and a later stroke always reads as higher
    P, N, A, Hf, LO, HI, SID, T, SHW, RANK = ([] for _ in range(10))
    off = 0.0
    for j, (s, dp) in enumerate(zip(order, depth)):
        n = len(s["pts"])
        P.append(s["pts"]); N.append(s["nrm"]); Hf.append(s["half"]); LO.append(s["lo"]); HI.append(s["hi"])
        A.append(off + np.arange(n) * DS)
        SID.append(np.full(n, j)); T.append(s["t"]); SHW.append(np.full(n, s["hw"])); RANK.append(np.full(n, dp))
        off += n * DS + 4 * S
    cat = lambda xs: np.concatenate(xs)
    hw = float(np.median([s["hw"] for s in order]))
    extra = dict(lo=cat(LO), hi=cat(HI), sid=cat(SID), t=cat(T), shw=cat(SHW), rank=cat(RANK) ** 2.5)
    return (cat(P), cat(N), cat(A), cat(Hf)), hw, extra, f"{len(main)} strokes + {len(filler)} filler, {tries} tries"
