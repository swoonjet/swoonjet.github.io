"""Residual sludge: what is left when the tank drains.

Built in the order it happens:

  settle   the heavy fraction sinks into the hollows of whatever it lies on (the strokes, or a
           basin of low hills) and fills them to a level, with a meniscus where it meets the rise;
           everywhere else keeps only a thin coat
  flow     it is thick: viscosity rounds every edge it covers
  skin     the top dries first and shrinks, so the pools wrinkle into a labyrinth of ridges
  gas      bubbles come up through it: some still domed under the skin, some popped into
           craters with a raised lip
  drain    from the lower lips of the pools it runs off down the page in tapering drips
  film     an oily film floats on the wet parts and throws thin-film colours

surface() returns the height and the masks tone() and paint() need (wet, pool).
"""
import cv2
import numpy as np

from fields import blur, fbm, light3, normals, smoothstep

KEYS = ("sl_fill", "sl_visc", "sl_skin", "sl_wrinkle", "sl_bubbles", "sl_drips")
SHADE_KEYS = ("sl_oil",)


def _smax(a, b, k):
    m = np.maximum(a, b)
    return m + k * np.log(np.exp((a - m) / k) + np.exp((b - m) / k))


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 41)
    ground = base.copy()
    if p["host"] == "slab":  # a basin: low hills and hollows
        ground += fbm(W, H, 320 * f, p["seed"], 3) * 42 * f + fbm(W, H, 90 * f, p["seed"] + 3, 2) * 6 * f

    # settle: fill to a level, a thin coat over the rest
    lo, hi = np.percentile(ground[::4, ::4], [2, 98])
    level = lo + (hi - lo) * p["sl_fill"]
    s = _smax(ground + 1.5 * f, np.float32(level), 5 * f)
    # flow: thick stuff rounds what it covers, but never sinks below the ground
    s = _smax(blur(s, (2 + 14 * p["sl_visc"]) * f), blur(ground, 3 * f) + 0.8 * f, 3 * f).astype(np.float32)
    pool = smoothstep(0.8 * f, 5 * f, s - ground).astype(np.float32)

    # skin: contour lines of a warped noise make the labyrinth of wrinkles
    lam = p["sl_wrinkle"] * f
    warp = fbm(W, H, lam * 9, p["seed"] + 11, 3)
    n = fbm(W, H, lam * 4, p["seed"] + 12, 3) + 0.35 * warp
    ridge = 1 - np.abs(np.cos(np.pi * n * 3.2))
    s += p["sl_skin"] * 2.4 * f * pool * ridge ** 2.5

    # gas: domes and popped craters, only where it is deep
    nb = int(p["sl_bubbles"] * W * H / (f * f) / 2200)
    ys, xs = np.nonzero(pool[::6, ::6] > 0.6)
    if nb and len(xs):
        pick = rng.integers(0, len(xs), nb)
        for x, y in zip(xs[pick] * 6 + rng.uniform(0, 6, nb), ys[pick] * 6 + rng.uniform(0, 6, nb)):
            r = f * 3 * (1 - rng.random() * 0.92) ** (-1 / 1.6)
            r = min(r, 40 * f)
            R = int(r * 1.4) + 2
            x0, x1, y0, y1 = max(0, int(x) - R), min(W, int(x) + R), max(0, int(y) - R), min(H, int(y) + R)
            if x0 >= x1 or y0 >= y1:
                continue
            d = np.hypot(np.arange(x0, x1)[None, :] - x, np.arange(y0, y1)[:, None] - y)
            if rng.random() < 0.4:  # still under the skin
                s[y0:y1, x0:x1] += 0.7 * np.sqrt(np.clip(r * r - d * d, 0, None))
            else:  # popped: a pit with a lip
                s[y0:y1, x0:x1] += -0.55 * np.sqrt(np.clip((0.8 * r) ** 2 - d * d, 0, None)) + 0.22 * r * np.exp(-((d - 0.85 * r) / (0.18 * r)) ** 2)

    # drain: drips from the lower lips of the pools, down the page
    drips = np.zeros((H, W), np.uint8)
    nd = int(p["sl_drips"] * W / f / 18)
    lip = (pool > 0.5) & (np.roll(pool, -int(3 * f) - 1, axis=0) < 0.3)
    ly, lx = np.nonzero(lip[::4, ::4])
    if nd and len(lx):
        pick = rng.integers(0, len(lx), nd)
        for x, y in zip(lx[pick] * 4.0, ly[pick] * 4.0):
            length = rng.uniform(25, 220) * f
            w0 = rng.uniform(2.5, 6) * f
            steps = max(2, int(length / (2 * f)))
            dx = 0.0
            for i in range(steps):
                t = i / steps
                dx += rng.normal(0, 0.15)
                x2, y2 = x + dx, y + 2 * f
                w = max(1, int(round(w0 * (1 - 0.7 * t))))
                cv2.line(drips, (int(x), int(y)), (int(x2), int(y2)), 255, w, cv2.LINE_AA)
                x, y = x2, y2
            cv2.circle(drips, (int(x), int(y)), max(1, int(w0 * 0.5)), 255, -1, cv2.LINE_AA)  # the bead at the end
    drip = blur(drips.astype(np.float32) / 255, 1.2 * f)
    s += 2.2 * f * drip
    wet = np.clip(pool + drip, 0, 1)
    return {"H": s, "pool": pool, "wet": wet}


def tone(p, S, light, f):
    """Goo, not stone: soft light on rounded forms, darkness only in real pits, and a gloss
    everywhere that turns into hard highlights where it is still wet."""
    z, pool, wet = S["H"], S["pool"], S["wet"]
    n = normals(z, p["relief"])
    L = light3(light)
    lam = np.clip(n @ L, 0, 1)
    pit = np.clip(blur(z, 10 * f) - z, 0, None)
    t = (0.2 + 0.6 * lam) * np.exp(-p["cavity"] * p["outline"] * pit / (6 * f))
    hv = L + np.array([0, 0, 1], np.float32)
    hv /= np.linalg.norm(hv)
    nh = np.clip(n @ hv, 0, 1)
    t += p["glint"] * (0.25 * nh ** 18 + 1.6 * wet * nh ** 140)
    return t - 0.06 * pool


def paint(p, img, S, f):
    """The oily film: thin-film colours where it is wet, strongest where the film is thickest."""
    if p["sl_oil"] <= 0:
        return img
    H, W = img.shape[:2]
    wet = S["wet"]
    thick = fbm(W, H, 140 * f, p["seed"] + 21, 4) + 0.25 * fbm(W, H, 40 * f, p["seed"] + 22, 2)
    phase = thick * 0.9 + 0.004 * blur(S["H"], 14 * f) / f  # thickness follows the big forms, not the wrinkles
    irid = 0.5 + 0.5 * np.cos(2 * np.pi * (phase[..., None] + np.array([0.0, 0.33, 0.67], np.float32)))
    a = (p["sl_oil"] * 0.6 * wet * smoothstep(-0.3, 0.6, fbm(W, H, 200 * f, p["seed"] + 23, 2)))[..., None]
    im = img.astype(np.float32)
    out = im * (1 - a) + np.clip(im * (0.55 + 1.0 * irid), 0, 255) * a
    return np.clip(out, 0, 255).astype(np.uint8)
