"""More ways to lay the strokes down, besides the one long coil and the Cincinnus fans.

  rings    strokes raked round a few centres, like a stone garden: every centre owns the part of
           the page nearest to it, so ripples from neighbouring centres meet along seams; the
           wobble is shared by all the rings of one centre (scaled with the radius) so they nest
  ribbons  long bands laid side by side across the page, all bending with one slow wave, the
           way strata or raked rows do; each overlaps the one before like shingles
  dabs     short loaded dabs of the brush, each a little curved comma with a lopsided head, laid
           where the page is least covered, turned by a vortex flow or thrown at random
  thatch   one direction only, in layers: rows of strokes all pointing one way, each row over the
           roots of the one before, so only the tips show
  weave    two sets of bands crossing, over and under (plain, or a twill when the floats are longer)
  burst    strokes thrown outward from a few centres in tiers, like petals, inner tiers on top

Each returns the same arrays as fans.fans: spines concatenated over strokes, plus per-point extras.
Everything is in reference px.
"""
import math

import numpy as np

from bristle import noise1, noise2
from fans import DS, _Cover, _head, _radius
from fields import Vortices


def _resample(pts, ds=DS):
    seg = np.hypot(*np.diff(pts, axis=0).T)
    s = np.r_[0, np.cumsum(seg)]
    if s[-1] < 2 * ds:
        return None
    q = np.arange(0, s[-1], ds)
    return np.stack([np.interp(q, s, pts[:, 0]), np.interp(q, s, pts[:, 1])], 1)


def _stroke(pts, half, rng, rough=0.0, size=0.0):
    """A spine (spaced DS) and its half widths -> a stroke dict: never wider than its bend, a
    lopsided head when rough > 0 (a round cap otherwise), and a round tip."""
    n = len(pts)
    if n < 6:
        return None
    rad = _radius(pts)
    w = max(2, int(half.max() / DS))
    room = np.array([0.8 * rad[max(0, i - w):i + w + 1].min() for i in range(n)])
    half = np.maximum(np.minimum(half, room), 1.0)
    d = np.gradient(pts, axis=0)
    d /= np.maximum(np.hypot(d[:, 0], d[:, 1]), 1e-9)[:, None]
    nrm = np.stack([-d[:, 1], d[:, 0]], 1)
    s = np.arange(n) * DS
    lo, hi = np.full(n, -1.0), np.full(n, 1.0)
    if rough > 0:
        v, head = _head(half[0], rng, rough)
        for i in range(min(n, int(head.max() / DS) + 2)):
            on = v[head <= s[i]]
            lo[i], hi[i] = (on.min(), on.max()) if len(on) else (1.0, -1.0)
    else:
        r = 0.9 * half[0]
        x = np.clip((r - s) / max(r, 1e-6), 0, 1)
        lim = np.sqrt(np.clip(1 - x * x, 0, 1))
        lo, hi = np.maximum(lo, -lim), np.minimum(hi, lim)
    r = 0.7 * half[-1]
    x = np.clip((s - (s[-1] - r)) / max(r, 1e-6), 0, 1)
    lim = np.sqrt(np.clip(1 - x * x, 0, 1))
    lo, hi = np.maximum(lo, -lim), np.minimum(hi, lim)
    return dict(pts=pts, nrm=nrm, half=half, lo=lo, hi=hi, t=s / max(s[-1], 1e-6), hw=float(np.median(half)),
                size=size or float(s[-1]))


def pack(strokes, S, rank=None):
    """Concatenate strokes (in drawing order) into one spine with per-point extras, as fans does."""
    P, N, A, Hf, LO, HI, SID, T, SHW, RANK = ([] for _ in range(10))
    off = 0.0
    m = len(strokes)
    for j, s in enumerate(strokes):
        n = len(s["pts"])
        P.append(s["pts"]); N.append(s["nrm"]); Hf.append(s["half"]); LO.append(s["lo"]); HI.append(s["hi"])
        A.append(off + np.arange(n) * DS)
        SID.append(np.full(n, j)); T.append(s["t"]); SHW.append(np.full(n, s["hw"]))
        RANK.append(np.full(n, j / max(m - 1, 1) if rank is None else rank[j]))
        off += n * DS + 4 * S
    cat = lambda xs: np.concatenate(xs)
    hw = float(np.median([s["hw"] for s in strokes]))
    extra = dict(lo=cat(LO), hi=cat(HI), sid=cat(SID), t=cat(T), shw=cat(SHW), rank=cat(RANK) ** 2.5)
    return (cat(P), cat(N), cat(A), cat(Hf)), hw, extra


def _spread(rng, n, W, H, pad):
    """n points spread apart (best of a dozen candidates each), allowed a little off the page."""
    out = []
    for _ in range(n):
        c = np.stack([rng.uniform(-pad, W + pad, 12), rng.uniform(-pad, H + pad, 12)], 1)
        if out:
            d = np.min(np.hypot(c[:, None, 0] - np.array(out)[None, :, 0], c[:, None, 1] - np.array(out)[None, :, 1]), 1)
            out.append(c[np.argmax(d)])
        else:
            out.append(c[0])
    return np.array(out)


def _runs(keep, minlen):
    """Start and end of every run of True at least minlen long."""
    k = np.r_[False, keep, False].astype(np.int8)
    st, en = np.nonzero(np.diff(k) == 1)[0], np.nonzero(np.diff(k) == -1)[0]
    return [(a, b) for a, b in zip(st, en) if b - a >= minlen]


def _breaks(n, amount, rng, gap):
    """A keep-mask along a path of n points with about amount breaks per 500 px, each gap points long."""
    keep = np.ones(n, bool)
    for _ in range(rng.poisson(amount * n * DS / 500)):
        i = int(rng.integers(0, n))
        keep[i:i + int(gap * rng.uniform(0.6, 1.6))] = False
    return keep


def rings(p, W, H):
    S = min(W, H)
    rng = np.random.default_rng(p["seed"] * 7919 + 101)
    C = _spread(rng, max(1, int(p["rg_centres"])), W, H, 0.15 * S)
    hw = p["rg_width"] / 2
    gap = 2 * hw * 0.8  # neighbours overlap a little, so no ground shows between them
    corners = np.array([[0, 0], [W, 0], [0, H], [W, H]])
    laid = []
    for ci, (cx, cy) in enumerate(C):
        others = np.delete(C, ci, 0)
        rmax = np.hypot(*(corners - [cx, cy]).T).max() + hw
        wob = [(rng.uniform(0, 100), rng.uniform(0, 100), rng.uniform(1.2, 2.6)) for _ in range(2)]
        r = hw * 1.3 + rng.uniform(0, gap)
        while r < rmax:
            n = int(2 * np.pi * r / DS) + int(2.5 * hw / DS)  # a closed ring runs on a little past its start
            a = rng.uniform(0, 2 * np.pi) + np.arange(n) * DS / r
            ca, sa = np.cos(a), np.sin(a)
            w = sum((noise2(ca * q + ox, sa * q + oy) - 0.5) * 2 for ox, oy, q in wob)  # periodic in the angle
            rr = r * (1 + p["rg_wobble"] * 0.09 * w) + p["rg_wobble"] * hw * 0.3 * (noise1(a * 3 + r * 0.01) - 0.5)
            pts = np.stack([cx + rr * ca, cy + rr * sa], 1)
            inside = (pts[:, 0] > -2 * hw) & (pts[:, 0] < W + 2 * hw) & (pts[:, 1] > -2 * hw) & (pts[:, 1] < H + 2 * hw)
            mine = np.ones(n, bool)
            if len(others):  # only the part of the page nearest this centre, and a stroke's width past it
                d = np.min(np.hypot(pts[:, None, 0] - others[None, :, 0], pts[:, None, 1] - others[None, :, 1]), 1)
                mine = rr < d + hw
            keep = inside & mine & _breaks(n, p["rg_breaks"], rng, 3 * hw / DS)
            for i0, i1 in _runs(keep, 8):
                half = hw * (1 + 0.12 * (noise1(a[i0:i1] * 2 + r) - 0.5) * 2)
                s = _stroke(pts[i0:i1], half, rng, size=r)
                if s is not None:
                    laid.append((r + rng.uniform(0, 3 * gap), s))
            r += gap * rng.uniform(0.92, 1.08)
    laid.sort(key=lambda q: q[0])  # inner rings first: each ring lies over the one inside it
    return (*pack([s for _, s in laid], S), f"{len(laid)} arcs round {len(C)} centres")


def ribbons(p, W, H):
    S = min(W, H)
    rng = np.random.default_rng(p["seed"] * 7919 + 103)
    a = np.radians(p["rb_angle"])
    d, nv = np.array([np.cos(a), np.sin(a)]), np.array([-np.sin(a), np.cos(a)])
    ext_n = abs(W * nv[0]) + abs(H * nv[1])
    ext_d = abs(W * d[0]) + abs(H * d[1])
    count = max(2, int(p["rb_count"]))
    gap = ext_n / count
    hw = gap * 0.62
    amp = p["rb_wave"] * S * 0.12
    ph = rng.uniform(0, 100, 4)
    s = np.arange(-ext_d / 2 - 3 * hw, ext_d / 2 + 3 * hw, DS)
    c = np.array([W / 2, H / 2])
    laid = []
    pad = int(amp / gap) + 2
    for i in range(-pad, count + pad):
        o = -ext_n / 2 + (i + 0.5) * gap
        # one slow wave shared by every band, varying only slowly from band to band so they stay side by side
        off = amp * ((noise2(s / (0.55 * S) + ph[0], o / (0.9 * S) + ph[1]) - 0.5) * 2
                     + 0.35 * (noise2(s / (0.21 * S) + ph[2], o / (0.6 * S) + ph[3]) - 0.5) * 2)
        off += gap * 0.12 * (noise1(s / (0.3 * S) + i * 7.3) - 0.5) * 2
        pts = c + s[:, None] * d + (o + off)[:, None] * nv
        inside = (pts[:, 0] > -2 * hw) & (pts[:, 0] < W + 2 * hw) & (pts[:, 1] > -2 * hw) & (pts[:, 1] < H + 2 * hw)
        keep = inside & _breaks(len(s), p["rb_breaks"], rng, 2.5 * hw / DS)
        for i0, i1 in _runs(keep, 8):
            half = hw * (1 + 0.15 * (noise1(s[i0:i1] / (0.4 * S) + i * 3.1) - 0.5) * 2)
            st = _stroke(pts[i0:i1], half, rng, size=float(i))
            if st is not None:
                laid.append((i + rng.uniform(0, 0.6), st))
    laid.sort(key=lambda q: q[0])  # band by band, each lapping over the last
    return (*pack([s for _, s in laid], S), f"{len(laid)} ribbon runs")


def dabs(p, W, H):
    S = min(W, H)
    rng = np.random.default_rng(p["seed"] * 7919 + 107)
    fld = Vortices(rng, W, H, p["eyes"])
    L0 = p["db_size"]
    cover = _Cover(W, H, max(6.0, 0.09 * L0))
    target = int(p["db_count"])
    laid, tries = [], 0
    enough = cover.count.size * 0.002
    while (len(laid) < target or cover.bare() > enough) and tries < target * 4 + 1500:
        tries += 1
        x, y = cover.pick(rng)
        L = L0 * math.exp(rng.normal(0, 0.3))
        vx, vy = fld(np.array([x]), np.array([y]))
        th = math.atan2(vy[0], vx[0]) + (1 - p["db_order"]) * rng.uniform(-np.pi, np.pi) + rng.normal(0, 0.15)
        bend = p["db_curve"] * rng.uniform(-1.6, 1.6) / L  # turn per px
        n = max(8, int(L / DS))
        heading = th + bend * np.arange(n) * DS - bend * L / 2
        pts = np.cumsum(np.stack([np.cos(heading), np.sin(heading)], 1) * DS, 0)
        pts += [x, y] - pts[n // 2]
        t = np.arange(n) / (n - 1)
        hw = L * rng.uniform(0.18, 0.28)
        half = hw * (1 - 0.5 * t ** 1.6) * (1 + 0.1 * (noise1(t * 3 + tries) - 0.5) * 2)
        s = _stroke(pts, half, rng, rough=0.9, size=L)
        cover.mark(x, y)
        if s is not None:
            cover.add(s)
            laid.append(s)
    laid.sort(key=lambda s: -s["size"])  # the big dabs first, the small ones on top
    return (*pack(laid, S), f"{len(laid)} dabs, {tries} tries")


def _box(pts, W, H, m):
    return (pts[:, 0] > -m).any() and (pts[:, 0] < W + m).any() and (pts[:, 1] > -m).any() and (pts[:, 1] < H + m).any() and \
        ((pts[:, 0] > -m) & (pts[:, 0] < W + m) & (pts[:, 1] > -m) & (pts[:, 1] < H + m)).any()


def thatch(p, W, H):
    """One direction only, in layers: rows of strokes all pointing the same way, each row laid over the
    roots of the row before, so only the tips show, like thatch, feathers or a pelt."""
    S = min(W, H)
    rng = np.random.default_rng(p["seed"] * 7919 + 109)
    a = np.radians(p["th_angle"])
    d, nv = np.array([np.cos(a), np.sin(a)]), np.array([-np.sin(a), np.cos(a)])
    ext_n, ext_d = abs(W * nv[0]) + abs(H * nv[1]), abs(W * d[0]) + abs(H * d[1])
    L, hw, jit = p["th_length"], p["th_width"] / 2, p["th_jitter"]
    step = max(L * (1 - p["th_overlap"]), 0.5 * hw)
    sp = 2 * hw * 0.8
    c = np.array([W / 2, H / 2])
    rows = np.arange(-ext_d / 2 - L, ext_d / 2 + step, step)
    laid = []
    for ri, s0 in enumerate(rows[::-1]):  # from the far end back: each row covers the roots of the last
        off = (ri % 2) * 0.5 * sp + rng.uniform(0, 0.3 * sp)
        for o in np.arange(-ext_n / 2 - sp + off, ext_n / 2 + sp, sp):
            Lj = L * rng.uniform(0.8, 1.2)
            n = max(8, int(Lj / DS))
            sway = 0.25 * (noise2(o / (0.7 * S), s0 / (0.7 * S) + 3.3) - 0.5) * 2  # neighbours lean together
            bend = jit * rng.normal(0, 0.5) / Lj + sway / Lj
            heading = a + sway * 0.6 + jit * rng.normal(0, 0.12) + bend * np.arange(n) * DS
            start = c + d * (s0 + jit * rng.normal(0, 0.25) * step) + nv * (o + jit * rng.normal(0, 0.25) * sp)
            pts = start + np.cumsum(np.stack([np.cos(heading), np.sin(heading)], 1) * DS, 0)
            if not _box(pts, W, H, hw):
                continue
            t = np.arange(n) / (n - 1)
            half = hw * rng.uniform(0.85, 1.15) * (1 - 0.35 * t ** 2)
            st = _stroke(pts, half, rng, rough=0.8, size=Lj)
            if st is not None:
                laid.append(st)
    return (*pack(laid, S), f"{len(laid)} strokes in {len(rows)} rows")


def weave(p, W, H):
    """Two sets of bands crossing at right angles, over and under: every band is cut into one piece
    per crossing, and the pieces that go over are laid after the ones that go under."""
    S = min(W, H)
    rng = np.random.default_rng(p["seed"] * 7919 + 127)
    a = np.radians(p["wv_angle"])
    d1, d2 = np.array([np.cos(a), np.sin(a)]), np.array([-np.sin(a), np.cos(a)])
    sp = S / max(2, int(p["wv_count"]))
    hw = sp * p["wv_width"] / 2
    span = max(1, int(p["wv_span"]))
    R = np.hypot(W, H) / 2 + sp
    offs = np.arange(-R, R, sp) + sp / 2
    c = np.array([W / 2, H / 2]) + rng.uniform(-0.5, 0.5, 2) * sp
    under, over = [], []
    for k, (dr, ac) in enumerate([(d1, d2), (d2, d1)]):
        for i, o in enumerate(offs):
            ph = rng.uniform(0, 100)
            for j, sc in enumerate(offs):
                s = np.arange(sc - sp / 2 - DS, sc + sp / 2 + 2 * DS, DS)
                wob = 0.04 * sp * (noise1(s / sp * 0.5 + ph) - 0.5) * 2  # hand-woven: never quite straight
                pts = c + s[:, None] * dr + (o + wob)[:, None] * ac
                if not _box(pts, W, H, hw):
                    continue
                ia, ib = (i, j) if k == 0 else (j, i)
                a_over = ((ib - ia) % (2 * span)) < span  # span 1 is plain weave; longer floats step along: a twill
                is_over = a_over if k == 0 else not a_over
                n = len(pts)
                dd = np.gradient(pts, axis=0)
                dd /= np.hypot(dd[:, 0], dd[:, 1])[:, None]
                half = hw * (1 + 0.06 * (noise1(s / sp + ph * 3) - 0.5) * 2)
                st = dict(pts=pts, nrm=np.stack([-dd[:, 1], dd[:, 0]], 1), half=half, lo=np.full(n, -1.0), hi=np.full(n, 1.0),
                          t=np.full(n, 0.3), hw=hw, size=sp)
                (over if is_over else under).append(st)
    rng.shuffle(under)
    rng.shuffle(over)
    laid = under + over
    rank = [0.0] * len(under) + [1.0] * len(over)
    return (*pack(laid, S, rank), f"{len(laid)} pieces")


def burst(p, W, H):
    """Strokes thrown outward from a few centres, in tiers like petals: the outer tiers first, each
    tier further in laid over the roots of the one outside it."""
    S = min(W, H)
    rng = np.random.default_rng(p["seed"] * 7919 + 131)
    C = _spread(rng, max(1, int(p["bu_centres"])), W, H, 0.1 * S)
    L, hw, curl = p["bu_length"], p["bu_width"] / 2, p["bu_curl"]
    corners = np.array([[0, 0], [W, 0], [0, H], [W, H]])
    laid = []
    for ci, (cx, cy) in enumerate(C):
        others = np.delete(C, ci, 0)
        rmax = np.hypot(*(corners - [cx, cy]).T).max()
        spin = rng.choice([-1, 1])
        tiers = np.arange(0.0, rmax, 0.5 * L)[::-1]
        for ti, r0 in enumerate(tiers):
            rr = max(r0, 0.6 * hw)
            m = max(5, int(np.ceil(2 * np.pi * rr / (1.6 * hw))))
            a0 = rng.uniform(0, 2 * np.pi)
            for q in range(m):
                a = a0 + 2 * np.pi * (q + rng.uniform(-0.2, 0.2)) / m
                Lj = L * rng.uniform(0.8, 1.2)
                n = max(8, int(Lj / DS))
                heading = a + spin * curl * (np.arange(n) * DS / Lj) * 0.9 + rng.normal(0, 0.06)
                start = np.array([cx, cy]) + rr * np.array([np.cos(a), np.sin(a)])
                pts = start + np.cumsum(np.stack([np.cos(heading), np.sin(heading)], 1) * DS, 0)
                if len(others):  # only from the part of the page nearest this centre
                    mid = pts[n // 3]
                    if np.hypot(*(others - mid).T).min() < np.hypot(*(mid - [cx, cy])):
                        continue
                if not _box(pts, W, H, hw):
                    continue
                t = np.arange(n) / (n - 1)
                half = hw * min(1.0, 0.35 + rr / (2 * L)) * rng.uniform(0.85, 1.15) * (1 - 0.3 * t ** 2)
                st = _stroke(pts, half, rng, rough=0.6, size=r0)
                if st is not None:
                    laid.append(st)
    return (*pack(laid, S), f"{len(laid)} strokes round {len(C)} centres")


FORMS = {"rings": rings, "ribbons": ribbons, "dabs": dabs, "thatch": thatch, "weave": weave, "burst": burst}


def underlay(g, hw, extra, W, H, seed):
    """Fill every bare patch of the page: strokes laid underneath everything, each following the
    direction of the nearest stroke, the largest gap first, until nothing of the page shows."""
    import cv2
    pts, nrm, arc, half = g
    if not len(pts):
        return g, hw, extra
    cell = max(3.0, hw / 3)
    gh, gw = int(np.ceil(H / cell)) + 1, int(np.ceil(W / cell)) + 1
    top = np.full((gh, gw), -1, np.int32)  # the top spine point over each cell
    lo, hi, sid = extra["lo"], extra["hi"], extra["sid"]
    n = len(pts)
    for k in range(n - 1):
        k2 = min(k + 3, n - 1)
        if sid[k2] != sid[k] or lo[k] >= hi[k]:
            continue
        a, b = pts[k], pts[k2]
        q = np.array([a + nrm[k] * half[k] * hi[k], b + nrm[k2] * half[k2] * hi[k], b + nrm[k2] * half[k2] * lo[k], a + nrm[k] * half[k] * lo[k]])
        cv2.fillConvexPoly(top, np.round(q / cell * 16).astype(np.int32), int(k), lineType=cv2.LINE_8, shift=4)
    bare = top < 0
    if not bare.any():
        return g, hw, extra
    # the direction of the nearest stroke, everywhere
    _, lab = cv2.distanceTransformWithLabels(bare.astype(np.uint8), cv2.DIST_L2, 5, labelType=cv2.DIST_LABEL_PIXEL)
    zj, zi = np.nonzero(~bare)
    near = np.zeros(lab.max() + 1, np.int32)
    near[lab[zj, zi]] = top[zj, zi]
    nk = near[lab]
    tx, ty = nrm[nk, 1], -nrm[nk, 0]
    rng = np.random.default_rng(seed * 7919 + 977)
    laid = []
    S = min(W, H)
    for _ in range(4000):
        dist = cv2.distanceTransform(bare.astype(np.uint8), cv2.DIST_L2, 5)
        j, i = np.unravel_index(np.argmax(dist), dist.shape)
        if dist[j, i] <= 0:
            break
        r = dist[j, i] * cell  # how far this gap runs from its middle to the nearest stroke
        hf = float(np.clip(1.25 * r, 0.8 * hw, 3 * hw))
        L = max(6 * hf, 2.5 * r + 2 * hf) * rng.uniform(0.9, 1.2)
        c = np.array([(i + rng.uniform(0.3, 0.7)) * cell, (j + rng.uniform(0.3, 0.7)) * cell])
        sides = []
        for sgn in (1, -1):  # trace both ways from the middle, along the flow of the strokes round it
            p0, d0, out = c.copy(), None, []
            for _s in range(int(L / 2 / DS)):
                jj = int(np.clip(p0[1] / cell, 0, gh - 1)); ii = int(np.clip(p0[0] / cell, 0, gw - 1))
                d = np.array([tx[jj, ii], ty[jj, ii]]) * sgn
                if d0 is not None:
                    if d @ d0 < 0:
                        d = -d
                    d = 0.7 * d0 + 0.3 * d
                    d /= max(np.hypot(*d), 1e-9)
                d0 = d
                p0 = p0 + d * DS
                out.append(p0.copy())
            sides.append(out)
        line = np.array(sides[1][::-1] + [c] + sides[0])
        line = _resample(line)
        st = None if line is None else _stroke(line, np.full(len(line), hf), rng)
        if st is None:  # too short to be a stroke: just mark the cell done
            bare[j, i] = False
            continue
        st["t"] = np.zeros(len(line))  # no dry tail on the ground layer
        laid.append(st)
        m = np.zeros(bare.shape, np.uint8)
        P, N, Hh = st["pts"], st["nrm"], st["half"]
        for k in range(0, len(P) - 3, 2):
            q = np.array([P[k] + N[k] * Hh[k], P[k + 3] + N[k + 3] * Hh[k + 3], P[k + 3] - N[k + 3] * Hh[k + 3], P[k] - N[k] * Hh[k]])
            cv2.fillConvexPoly(m, np.round(q / cell * 16).astype(np.int32), 1, lineType=cv2.LINE_8, shift=4)
        m = cv2.erode(m, np.ones((2, 2), np.uint8))  # count only what it covers for sure
        bare &= m == 0
        bare[j, i] = False
    if not laid:
        return g, hw, extra
    (fp, fn, fa, fh), _, fx = pack(laid, S, rank=np.zeros(len(laid)))
    shift = fa[-1] + 4 * S
    cat = np.concatenate
    g2 = (cat([fp, pts]), cat([fn, nrm]), cat([fa, arc + shift]), cat([fh, half]))
    ex2 = {k: cat([fx[k], v + (fx["sid"].max() + 1 if k == "sid" else 0)]) for k, v in extra.items() if k in fx}
    for k, v in extra.items():  # anything else a form keeps per point: the ground has none of it
        if k not in fx:
            ex2[k] = cat([np.zeros(len(fp), np.asarray(v).dtype), v]) if np.ndim(v) else v
    return g2, hw, ex2
