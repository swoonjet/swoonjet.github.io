"""Bird bones: not a skeleton, but shards that guess at one, packed so tight nothing else shows.

Built in the order it happens:

  matrix   underneath everything is spongy bone, a lattice of thin struts round open cells (the
           inside of every bird bone), so wherever the shards part, bone still shows
  shard    every shard is a guess at a piece of a bird: a hollow tube, swelling and narrowing a
           little, snapped off ragged at both ends; a curved sliver like a rib (Curve); now and
           then a thin flat blade, like a piece of the keel
  open     many are split along their length, so the smooth hollow inside shows (Hollow)
  pack     they are dropped one after another, each settling on the highest pieces under it, until
           the heap is several deep (Density); they lie along the flow, or anyhow (Alignment)
  age      the broken ends are porous; the bone stains unevenly (Pores, Stain)

surface() returns the height, which shard is on top where, and where the porous bone is.
"""
import numpy as np

import stone
from fields import fbm, hash1, smoothstep, worley

KEYS = ("bb_density", "bb_size", "bb_hollow", "bb_curve", "bb_align", "bb_pores")
SHADE_KEYS = ("bb_stain",)


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 161)
    # the matrix: struts round open cells, everywhere
    d1, d2, _ = worley(W, H, 7 * f, rng)
    strut = np.exp(-(((d2 - d1) * 0.5) / (0.9 * f)) ** 2)
    z = base + 2.5 * f * strut - 1.5 * f + fbm(W, H, 200 * f, p["seed"], 2) * 4 * f
    sponge = np.ones((H, W), np.float32)
    sid = np.full((H, W), -1, np.int32)
    on = base > 0.5 * f
    L0 = p["bb_size"] * f
    n = int(min(40000, p["bb_density"] * W * H / (0.16 * L0 * L0)))
    for i in range(n):
        cx, cy = rng.uniform(-0.1 * L0, W + 0.1 * L0), rng.uniform(-0.1 * L0, H + 0.1 * L0)
        xi, yi = int(np.clip(cx, 0, W - 1)), int(np.clip(cy, 0, H - 1))
        along = rng.random() < p["bb_align"] and (p["host"] == "slab" or on[yi, xi])
        a = theta[yi, xi] + rng.normal(0, 0.2) if along else rng.uniform(0, 2 * np.pi)
        l = L0 * np.exp(rng.normal(0, 0.45))
        blade = rng.random() < 0.12
        w0 = l * (rng.uniform(0.18, 0.3) if blade else rng.uniform(0.05, 0.11))
        bend = p["bb_curve"] * rng.normal(0, 0.9) / l
        R = int(0.6 * l + 3 * w0 + 3)
        x0, x1, y0, y1 = max(0, int(cx) - R), min(W, int(cx) + R + 1), max(0, int(cy) - R), min(H, int(cy) + R + 1)
        if x0 >= x1 or y0 >= y1:
            continue
        dx = np.arange(x0, x1, dtype=np.float32)[None, :] - cx
        dy = np.arange(y0, y1, dtype=np.float32)[:, None] - cy
        u = dx * np.cos(a) + dy * np.sin(a)
        v = -dx * np.sin(a) + dy * np.cos(a) - bend * u * u
        ph = rng.uniform(0, 100)
        # the outline: a tube swelling and narrowing a little, snapped off ragged at both ends
        w = w0 * (1 + 0.12 * np.sin(u / (0.25 * l) + ph) - 0.15 * (u / l) ** 2)
        q = v / w
        f2 = rng.uniform(2, 5)
        tear_a = l * (0.06 + 0.22 * np.abs(np.sin(q * f2 + ph)) + 0.1 * np.abs(q)) * rng.uniform(0.4, 1)
        tear_b = l * (0.06 + 0.22 * np.abs(np.sin(q * f2 * 1.3 + 2 * ph)) + 0.1 * np.abs(q)) * rng.uniform(0.4, 1)
        end = 0.5 * l - tear_a
        inside = (np.abs(q) < 1) & (u < end) & (u > -0.5 * l + tear_b)
        if not inside.any():
            continue
        if blade:  # a flat blade with a ridge down it
            h = w * (0.25 + 0.35 * np.exp(-(q / 0.2) ** 2)) * np.sqrt(np.clip(1 - q ** 8, 0, 1))
        else:
            h = w * np.sqrt(np.clip(1 - q * q, 0, 1))
            if rng.random() < p["bb_hollow"]:  # split open along its length: the smooth hollow inside
                ri = 0.72
                start = rng.uniform(-0.5, 0.1) * l
                trough = (np.abs(q) < ri) & (u > start)
                floor = w * (0.25 - 0.2 * np.sqrt(np.clip(1 - (q / ri) ** 2, 0, 1)))
                h = np.where(trough, floor, h)
        zz = z[y0:y1, x0:x1]
        rest = np.percentile(zz[inside], 85)
        hb = rest + 0.4 * w0 + h + rng.normal(0, 0.05) * u
        top = inside & (hb > zz)
        zz[top] = hb[top]
        sid[y0:y1, x0:x1][top] = i
        # porous at the snapped ends
        por = smoothstep(end - 0.1 * l, end, u) + smoothstep(-0.5 * l + tear_b + 0.1 * l, -0.5 * l + tear_b, u)
        sponge[y0:y1, x0:x1][top] = np.clip(por, 0, 1)[top]
    pores = np.clip(fbm(W, H, 2.2 * f, p["seed"] + 7, 2), 0, None)
    z -= p["bb_pores"] * 1.5 * f * sponge * pores
    return dict(H=z.astype(np.float32), sid=sid, sponge=sponge)


def tone(p, S, light, f):
    z, sid = S["H"], S["sid"]
    H, W = z.shape
    t = stone.tone(p, z, light, f, local=40 * f)
    has = sid >= 0
    c = np.clip(sid, 0, None)
    t += has * (0.1 + 0.08 * (hash1(c * 0.77 + p["seed"]) - 0.5) * 2)
    t -= (~has) * 0.12 * min(p["outline"], 1)  # the matrix sits back, in shade
    t -= p["bb_stain"] * (0.16 * smoothstep(-0.2, 0.7, fbm(W, H, 90 * f, p["seed"] + 3, 3)) + 0.08 * S["sponge"])
    return t
