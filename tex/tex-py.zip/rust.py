"""Flaking rust: painted steel left out in the rain for years.

Built in the order it happens:

  paint    a coat of paint (the main colours) over steel, a little orange peel in it
  bloom    water gets under at scratches and pinholes; rust blooms out from them, in patches that
           grow and join (Corrosion, Bloom size)
  lift     rust takes more room than the steel it eats, so round each bloom the paint blisters,
           then cracks into flakes that curl up at their edges; some have already fallen (Flakes,
           Flake size)
  scale    under the flakes is rust itself, layered and crusty, pitted where it went deep (Pits)
  run      every rain carries rust down the paint in streaks (Streaks, down the page)

surface() returns the height and where the rust, the flakes and the streaks are; paint() colours
the rust in its own browns and oranges.
"""
import numpy as np

import stone
from fields import blur, fbm, hash1, lin, smoothstep, srgb, worley

KEYS = ("ru_amount", "ru_bloom", "ru_flakes", "ru_flake_size", "ru_pits", "ru_scale")
SHADE_KEYS = ("ru_streaks",)
RUST = ["#2a1409", "#5e2a10", "#8f3f14", "#c0621f", "#d9944a"]


def surface(p, base, theta, f):
    H, W = base.shape
    rng = np.random.default_rng(p["seed"] * 7919 + 181)
    z = base.copy()
    if p["host"] == "slab":
        z += fbm(W, H, 900 * f, p["seed"], 2) * 10 * f
    z += 0.35 * f * fbm(W, H, 9 * f, p["seed"] + 1, 2)  # orange peel in the paint
    # bloom: patches growing from pinholes and scratches, joining up
    B = p["ru_bloom"] * f
    c = fbm(W, H, B, p["seed"] + 2, 5) + 0.35 * fbm(W, H, B * 0.25, p["seed"] + 3, 3)
    pin = np.zeros((H, W), np.float32)
    for _ in range(int(W * H / (f * f) / 30000)):
        x, y = rng.integers(0, W), rng.integers(0, H)
        pin[y, x] = 1
    c += 2.2 * blur(pin, 0.08 * B) * (0.08 * B) ** 2 * 6.3
    a = p["ru_amount"]
    lvl = 1.1 - 1.6 * a - 9 * max(0.0, a - 0.8)  # past 0.8 the blooms run together; at 1 no paint is left
    rust = smoothstep(lvl, lvl + 0.08, c)
    ring = smoothstep(lvl - 0.35, lvl, c) * (1 - rust)  # the zone round each bloom where paint lifts
    # flakes: paint cracked into plates over the ring, edges curled up; some fallen
    s = p["ru_flake_size"] * f
    d1, d2, cid = worley(W, H, s, rng)
    e = (d2 - d1) * 0.5
    gone = (hash1(cid * 0.913 + p["seed"]) < 0.25 + 0.6 * ring) & (ring > 0.5)
    lift = p["ru_flakes"] * ring
    flake = (ring > 0.05) & ~gone
    curl = lift * (2.5 * f * (1 - smoothstep(0, 0.45 * s, e)) + 1.0 * f)
    crack = np.exp(-(e / (0.8 * f)) ** 2) * (ring > 0.05)
    # scale: crusty layered rust, lower than the paint, pitted
    crust = fbm(W, H, 26 * p["ru_scale"] * f, p["seed"] + 5, 4) * 1.6 * f + np.abs(fbm(W, H, 7 * f, p["seed"] + 6, 2)) * f
    p1, _, _ = worley(W, H, 14 * f, rng)
    pits = p["ru_pits"] * 3 * f * np.exp(-(p1 / (2.0 * f)) ** 2) * smoothstep(0.1, 0.5, c - lvl)
    under = rust + gone * ring
    z = z + 2.0 * f * (1 - under) + flake * curl - 1.8 * f * crack * flake + under * (crust - pits - 1.0 * f)
    # run: rain carries rust down the page from every bloom
    src = blur(np.clip(under, 0, 1), 2 * f)
    run = np.zeros_like(src)
    step = max(1, int(6 * f))
    acc = src.copy()
    for _ in range(40):
        acc = np.roll(acc, step, axis=0) * 0.93
        acc[:step] = 0
        run = np.maximum(run, acc)
    streak = blur(run, 1.5 * f) * (0.6 + 0.4 * fbm(W, H, 30 * f, p["seed"] + 8, 2) ** 2 * 3)
    streak *= smoothstep(-0.3, 0.6, fbm(W, H, 12 * f, p["seed"] + 9, 1)) ** 0.5  # streaks break into runs
    return dict(H=z.astype(np.float32), rust=np.clip(under, 0, 1).astype(np.float32), flake=flake & (lift > 0.02),
                streak=np.clip(streak * (1 - under), 0, 1).astype(np.float32), crust=crust)


def tone(p, S, light, f):
    return stone.tone(p, S["H"], light, f, local=40 * f)


def paint(p, img, S, f):
    H, W = img.shape[:2]
    pal = np.array([lin(c) for c in RUST], np.float32)
    im = img.astype(np.float32) / 255
    im = np.where(im <= 0.04045, im / 12.92, ((im + 0.055) / 1.055) ** 2.4)
    Y = im @ np.array([0.2126, 0.7152, 0.0722], np.float32)
    # the rust's colour: darker in the deep crust, orange on the high scale, a mottle of both
    mix = np.clip(0.25 + 1.6 * Y ** 0.6 + 0.25 * fbm(W, H, 40 * f, p["seed"] + 11, 3), 0, 0.999) * (len(RUST) - 1)
    i = mix.astype(int)
    fr = (mix - i)[..., None]
    rc = pal[i] * (1 - fr) + pal[np.minimum(i + 1, len(RUST) - 1)] * fr
    rc *= (0.45 + 1.4 * Y)[..., None]
    a = S["rust"][..., None]
    out = im * (1 - a) + rc * a
    # flakes show their rusty undersides at the curled edges; streaks stain the paint
    st = (p["ru_streaks"] * 0.8 * S["streak"])[..., None]
    out = out * (1 - st) + out * pal[2] / (pal[2].max()) * 0.7 * st
    return srgb(out).astype(np.uint8)
