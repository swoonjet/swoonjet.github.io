"""Protozoa in solution: a drop of pond water on a slide, under the microscope.

The process (what the eye at the eyepiece is given):

  culture  a population: ciliates (slipper-shaped, an oral groove, a fringe of cilia),
           amoebae (a blob pushing out pseudopods, granular inside, a clear rim) and diatoms
           (glass boats with a central slit and fine ribs); with Variety, more of the pond:
           euglenas (a spindle full of chloroplasts, an eyespot, a whipping flagellum), rotifers
           (a trunk, a forked foot, two wheels of cilia at the head, the jaws working inside),
           volvox (a hollow ball of tiny cells carrying daughter balls), vorticellas (a bell on
           a coiled stalk), heliozoa (a foamy ball bristling with fine straight spines) and
           closterium desmids (green crescents, a clear vacuole at each tip); bacteria and
           debris everywhere
  current  they lie along the way the water moves: the strokes, or slow eddies
  depth    each sits at its own depth in the drop; the objective focuses one thin plane, so
           everything else softens the further it is from it (drawn to four depth layers,
           each layer blurred by its distance from focus)
  optics   phase contrast puts a bright halo round every edge; the field is lit unevenly and
           the field stop can show as a circle; dark field turns it inside out (edges glow)

Everything is drawn as signed distances in each organism's own frame (u along, v across).
fields() returns the change each layer makes to the bright field; colour() lights the slide.
"""
import cv2
import numpy as np

from fields import Vortices, blur, deposit, fbm, smoothstep, strokes_sample

KEYS = ("pz_count", "pz_size", "pz_debris", "pz_focus", "pz_dof", "pz_halo", "pz_variety")
COLOUR_KEYS = ("pz_scope", "pz_dark")
DEPTHS = np.array([-0.75, -0.25, 0.25, 0.75])
CLASSIC = {"ciliate": 0.45, "amoeba": 0.3, "diatom": 0.25}
MORE = ("euglena", "rotifer", "volvox", "vorticella", "heliozoan", "closterium")
SCALE = {"diatom": 0.6, "euglena": 0.7, "rotifer": 1.1, "volvox": 0.85, "vorticella": 0.9, "heliozoan": 0.8, "closterium": 0.8}


def _smin(a, b, k):
    """A smooth union of two signed distances, blended over about k."""
    h = np.clip(0.5 + 0.5 * (b - a) / k, 0, 1)
    return b + (a - b) * h - k * h * (1 - h)


def _tube(u, v, u0, u1, r0, r1, bend=None):
    """Signed distance to a tapering tube along u from u0 to u1 (radius r0 to r1), its spine
    bent off v = 0 by bend(u)."""
    t = np.clip((u - u0) / (u1 - u0), 0, 1)
    uc = u0 + t * (u1 - u0)
    vc = 0 if bend is None else bend(uc)
    return np.hypot(u - uc, v - vc) - (r0 + (r1 - r0) * t)


def _dots(shape, xs, ys, r, f):
    """Little round cells at (xs, ys) in patch px: a soft dark dot each."""
    m = np.zeros(shape, np.float32)
    deposit(m, xs, ys, np.ones(len(xs), np.float32))
    return np.clip(blur(m, r) * (r * r) * 6.3, 0, 1)


def _organism(kind, L, rng, f, halo):
    """One cell as a patch of tone change (negative = darker than the medium), in its own frame."""
    R = int(L * 0.95) + int(10 * f)
    u, v = np.meshgrid(np.arange(-R, R + 1, dtype=np.float32), np.arange(-R, R + 1, dtype=np.float32))
    w = 1.3 * f
    outer = 0  # what trails outside the body: a flagellum, a stalk, spines
    if kind == "ciliate":
        a, b = L / 2, L * 0.21
        b_u = b * (1 - 0.18 * u / a)  # narrower at the front
        q = np.sqrt((u / a) ** 2 + (v / b_u) ** 2)
        d = (q - 1) * b
        d += 0.45 * b * np.exp(-((u - 0.1 * a) / (0.35 * a)) ** 2 - ((v - 0.85 * b) / (0.45 * b)) ** 2)  # oral groove
        ang = np.arctan2(v / b, u / a)
        n = int(np.pi * (a + b) / (3.2 * f))
        cilia = np.cos(n * ang / 2) ** 16 * np.exp(-np.clip(d, 0, None) / (5 * f)) * (d > 0)
        inside = -0.09
        nuc = (u / (0.22 * a)) ** 2 + ((v + 0.1 * b) / (0.45 * b)) ** 2
        extra = -0.12 * smoothstep(1.2, 0.6, nuc)
        for su in (-0.7, 0.62):  # contractile vacuoles near each end: clear, rimmed
            cv = np.hypot(u - su * a, v + 0.2 * b) / (0.16 * b + 1.5 * f)
            extra += 0.10 * (cv < 1) - 0.10 * np.exp(-((cv - 1) / 0.15) ** 2)
        gran = 0.35
    elif kind == "amoeba":
        r0 = L * 0.33
        rho, th = np.hypot(u, v), np.arctan2(v, u)
        rr = r0 * (1 + sum(rng.uniform(0, 0.12 / k) * np.cos(k * th + rng.uniform(0, 6.3)) for k in range(2, 7)))
        for _ in range(rng.integers(2, 5)):  # pseudopods
            at = rng.uniform(-np.pi, np.pi)
            dth = np.angle(np.exp(1j * (th - at)))
            rr = rr + r0 * rng.uniform(0.4, 0.9) * np.exp(-(dth / rng.uniform(0.18, 0.35)) ** 2)
        d = rho - rr
        inside = -0.05 - 0.07 * smoothstep(-0.25 * r0, -0.5 * r0, d)  # clear rim, grainy middle
        nx, ny = rng.uniform(-0.25, 0.25, 2) * r0
        extra = -0.13 * smoothstep(1.2, 0.6, np.hypot(u - nx, v - ny) / (0.22 * r0))
        cvx, cvy = rng.uniform(-0.4, 0.4, 2) * r0
        cv = np.hypot(u - cvx, v - cvy) / (0.14 * r0)
        extra += 0.09 * (cv < 1) - 0.09 * np.exp(-((cv - 1) / 0.15) ** 2)
        gran = 0.55
        cilia = 0
    elif kind == "euglena":  # a spindle, pointed behind, an eyespot and a flagellum in front
        a = L * 0.45
        x = np.clip(u / a, -1, 1)
        hw = L * 0.1 * np.clip(1 - x * x, 0, 1) ** 0.6 * (1 + 0.3 * x)
        d = np.maximum(np.abs(v) - hw, np.abs(u) - a)
        inside = -0.04 - 0.03 * np.cos((u + 1.6 * v) / (2.2 * f))  # the pellicle's spiral strips
        extra = -0.12 * _dots(u.shape, u.shape[1] // 2 + rng.uniform(-0.75, 0.6, 26) * a,
                              u.shape[0] // 2 + rng.uniform(-0.6, 0.6, 26) * L * 0.08, 1.8 * f, f)  # chloroplasts
        extra += -0.35 * np.exp(-(np.hypot(u - 0.78 * a, v - 0.03 * L) / (1.6 * f + 0.02 * L)) ** 2)  # eyespot
        ph = rng.uniform(0, 6.3)
        wave = lambda uu: 0.06 * L * np.sin((uu - a) / (0.09 * L) + ph) * np.clip((uu - a) / (0.1 * L), 0, 1)
        outer = 0.22 * np.exp(-((v - wave(u)) / (0.8 * f)) ** 2) * (u > a) * (u < a + 0.48 * L)
        gran, cilia = 0.2, 0
    elif kind == "rotifer":  # trunk, forked foot, and the corona: two wheels of cilia at the head
        d = (np.sqrt(((u - 0.04 * L) / (0.22 * L)) ** 2 + (v / (0.14 * L)) ** 2) - 1) * 0.14 * L
        d = _smin(d, _tube(u, v, -0.14 * L, -0.4 * L, 0.06 * L, 0.025 * L), 0.04 * L)
        for s in (-1, 1):
            d = np.minimum(d, _tube(u, v, -0.4 * L, -0.47 * L, 0.02 * L, 0.007 * L, lambda uu, s=s: s * (uu + 0.4 * L) * -0.5))  # toes
            dc = np.hypot(u - 0.28 * L, v - s * 0.08 * L) - 0.075 * L
            d = _smin(d, dc, 0.03 * L)
        ring = np.minimum(np.hypot(u - 0.28 * L, v - 0.08 * L), np.hypot(u - 0.28 * L, v + 0.08 * L))
        ang = np.arctan2(v - np.sign(v) * 0.08 * L, u - 0.28 * L)
        cilia = 2.5 * (np.cos(ang * 14) ** 8 * np.exp(-np.clip(ring - 0.075 * L, 0, None) / (7 * f))
                       * (ring > 0.075 * L) * (u > 0.22 * L))
        inside = -0.06 + 0.02 * np.cos(u / (6 * f))  # the cuticle's rings
        extra = -0.2 * smoothstep(1.2, 0.7, np.hypot(u - 0.13 * L, v) / (0.045 * L))  # the mastax, chewing
        extra += -0.1 * smoothstep(1.2, 0.6, np.hypot(u + 0.02 * L, v) / (0.09 * L))  # the stomach
        gran = 0.3
    elif kind == "volvox":  # a hollow ball of tiny cells, daughter colonies inside
        r0 = L * 0.38
        rho = np.hypot(u, v)
        d = rho - r0
        k = int(np.clip((r0 / (2.6 * f)) ** 2 * 1.2, 30, 2500))
        z = rng.uniform(-1, 1, k)
        ph = rng.uniform(0, 2 * np.pi, k)
        s = np.sqrt(1 - z * z)
        c = u.shape[0] // 2
        extra = -0.22 * _dots(u.shape, c + r0 * 0.97 * s * np.cos(ph), c + r0 * 0.97 * s * np.sin(ph), 1.0 * f, f)
        for _ in range(rng.integers(2, 6)):
            rd = r0 * rng.uniform(0.14, 0.26)
            a_, b_ = rng.uniform(0, 2 * np.pi), rng.uniform(0, r0 - rd * 1.3)
            dd = np.hypot(u - b_ * np.cos(a_), v - b_ * np.sin(a_)) - rd
            extra += -0.08 * smoothstep(1.5 * f, -1.5 * f, dd) - 0.22 * np.exp(-(dd / (1.2 * f)) ** 2)
        inside = 0.02
        gran, cilia = 0, 0
    elif kind == "vorticella":  # a bell on a long stalk, coiled like a spring
        u0, u1 = 0.08 * L, 0.46 * L
        x = np.clip((u - u0) / (u1 - u0), 0, 1)
        hw = 0.035 * L + 0.18 * L * np.sin(0.5 * np.pi * x) ** 0.7  # a bell: narrow at the stalk, swelling
        lip = u1 + 0.05 * L * np.clip(1 - (v / (0.21 * L)) ** 2, 0, 1)  # the peristome bulges a little
        d = np.maximum(np.maximum(np.abs(v) - hw, u0 - u), u - lip)
        cilia = (np.cos(v / (1.4 * f)) ** 10 * np.exp(-np.clip(u - u1, 0, None) / (3.5 * f))
                 * (u > u1) * (np.abs(v) < 0.2 * L))
        coil = lambda uu: 0.025 * L * np.sin(uu / (2.2 * f))
        outer = 0.25 * np.exp(-((v - coil(u)) / (0.9 * f)) ** 2) * (u < u0) * (u > -0.5 * L)
        inside = -0.07
        extra = -0.14 * smoothstep(1.2, 0.6, np.hypot((u - 0.27 * L) / (0.13 * L), v / (0.04 * L)))  # the C-shaped nucleus
        extra += 0.08 * smoothstep(1.2, 0.6, np.hypot(u - 0.38 * L, v - 0.08 * L) / (0.035 * L))  # its vacuole
        gran = 0.35
    elif kind == "heliozoan":  # the sun animalcule: a foamy ball, straight spines all round
        r0 = L * 0.18
        rho, th = np.hypot(u, v), np.arctan2(v, u)
        d = rho - r0
        nsp = int(rng.integers(26, 44))
        a0 = rng.uniform(0, 2 * np.pi)
        dth = np.angle(np.exp(1j * (th - a0) * nsp)) / nsp
        reach = r0 + L * 0.27 * (0.85 + 0.15 * np.cos(th * 3 + a0))
        outer = 0.24 * np.exp(-((rho * np.sin(np.abs(dth))) / (0.6 * f)) ** 2) * (rho > r0) * (rho < reach)
        foam = np.cos(u / (2.6 * f) + 0.4 * np.sin(v / (3.1 * f))) * np.cos(v / (2.6 * f) + 0.4 * np.sin(u / (2.9 * f)))
        inside = -0.04 + 0.05 * np.clip(foam, 0, 1)  # vacuolated, bubbly
        extra = -0.16 * smoothstep(1.2, 0.6, rho / (0.35 * r0))
        gran, cilia = 0.15, 0
    elif kind == "closterium":  # a desmid: a green crescent, a clear vacuole at each pointed tip
        Rc, span = 0.55 * L, 0.72
        rho = np.hypot(u, v + Rc)
        phi = np.arctan2(u, v + Rc)
        x = np.clip(phi / span, -1, 1)
        hw = 0.075 * L * np.clip(1 - x * x, 0, 1) ** 0.65
        d = np.maximum(np.abs(rho - Rc) - hw, (np.abs(phi) - span) * Rc)
        inside = -0.12 + 0.04 * np.cos((rho - Rc) / (1.4 * f))  # the chloroplast's ridges
        extra = 0.1 * smoothstep(0.08, 0.02, np.abs(phi)) - 0.08 * np.exp(-(np.hypot(u, v) / (0.03 * L)) ** 2)  # nucleus band
        for s in (-1, 1):
            tip = np.hypot(u - s * Rc * np.sin(0.8 * span), v + Rc - Rc * np.cos(0.8 * span)) / (0.035 * L + f)
            extra += 0.14 * (tip < 1) - 0.25 * np.exp(-(tip / 0.3) ** 2)  # the vacuole and its dancing crystals
        gran, cilia = 0, 0
        w = 1.6 * f
    else:  # diatom: a glass boat, central slit and ribs
        a, b = L * 0.55, L * 0.11
        q = (np.abs(u / a) ** 2.3 + np.abs(v / b) ** 2.3) ** (1 / 2.3)
        d = (q - 1) * b
        ribs = 0.5 + 0.5 * np.cos(2 * np.pi * u / (3.0 * f))
        inside = 0.04 - 0.06 * ribs * smoothstep(0.2 * b, 0.45 * b, np.abs(v))
        extra = -0.18 * np.exp(-(v / (0.9 * f)) ** 2) * (np.abs(u) < 0.85 * a)  # the raphe
        extra += -0.1 * np.exp(-(np.hypot(u, v) / (0.12 * b + f)) ** 2)  # central nodule
        gran = 0.0
        cilia = 0
        w = 1.8 * f
    body = smoothstep(w, -w, d)
    out = body * (inside + extra) - 0.12 * cilia * (1 - body)  # cilia live just outside
    out -= outer * (1 - body)
    if gran:  # granules in the cytoplasm
        g = (rng.random(u.shape) < 0.012 * gran).astype(np.float32)
        out -= 0.25 * blur(g, 0.8 * f) * (0.8 * f) ** 2 * 6.3 * body
    out -= 0.34 * np.exp(-(d / w) ** 2)  # the membrane / frustule edge
    out += halo * 0.2 * np.exp(-np.clip(d, 0, None) / (4.5 * f)) * (d > w)  # phase-contrast halo
    return (1.5 * out).astype(np.float32), R


def _paste(layer, patch, cx, cy, th):
    """Rotate the patch by th and add it centred at (cx, cy)."""
    R = patch.shape[0] // 2
    M = cv2.getRotationMatrix2D((R, R), -np.degrees(th), 1.0)
    rot = cv2.warpAffine(patch, M, patch.shape[::-1], flags=cv2.INTER_LINEAR, borderValue=0)
    H, W = layer.shape
    x0, y0 = int(cx) - R, int(cy) - R
    a0, b0 = max(0, x0), max(0, y0)
    a1, b1 = min(W, x0 + patch.shape[1]), min(H, y0 + patch.shape[0])
    if a0 < a1 and b0 < b1:
        layer[b0:b1, a0:a1] += rot[b0 - y0:b1 - y0, a0 - x0:a1 - x0]


def fields(p, W, H, f, geo):
    rng = np.random.default_rng(p["seed"] * 7919 + 71)
    layers = np.zeros((len(DEPTHS), H, W), np.float32)
    n = int(p["pz_count"])
    if geo is None:
        fld = Vortices(rng, W, H, 4)
        xy = np.stack([rng.uniform(0, W, n), rng.uniform(0, H, n)], 1)
        vx, vy = fld(xy[:, 0], xy[:, 1])
        ths = np.arctan2(vy, vx)
    else:
        xy, ths = strokes_sample(geo, n, rng, 0.8)
    var = p["pz_variety"]
    names = (*CLASSIC, *MORE)
    w = np.array([*(c * (1 - 0.8 * var) for c in CLASSIC.values()), *([0.8 * var / len(MORE)] * len(MORE))])
    kinds = rng.choice(names, n, p=w / w.sum())
    zs = rng.uniform(-1, 1, n)
    order = np.argsort(-np.abs(zs - p["pz_focus"]))
    for i in order:
        L = p["pz_size"] * f * rng.uniform(140, 300) * SCALE.get(kinds[i], 1)
        patch, _ = _organism(kinds[i], L, rng, f, p["pz_halo"])
        b = int(np.argmin(np.abs(DEPTHS - zs[i])))
        _paste(layers[b], patch, xy[i, 0], xy[i, 1], ths[i] + rng.normal(0, 0.25))

    # bacteria and debris: tiny rods and specks at every depth
    m = int(p["pz_debris"] * W * H / (f * f) / 260)
    for b in range(len(DEPTHS)):
        k = m // len(DEPTHS)
        x, y = rng.uniform(0, W, k), rng.uniform(0, H, k)
        a = rng.uniform(0, np.pi, k)
        dots = np.zeros((H, W), np.float32)
        for s in (-1.5, 0, 1.5):  # three points make a rod
            deposit(dots, x + s * f * np.cos(a), y + s * f * np.sin(a), rng.uniform(0.6, 1.4, k) * 0.15)
        layers[b] -= blur(dots, 0.9 * f) * (0.9 * f) ** 2 * 6.3

    # depth of field: blur each layer by its distance from the focal plane
    out = np.zeros((H, W), np.float32)
    for b, z in enumerate(DEPTHS):
        out += blur(layers[b], 0.4 * f + p["pz_dof"] * abs(z - p["pz_focus"]) * 9 * f)
    return out


def colour(p, delta, lut, light, f):
    H, W = delta.shape
    field = 0.8 + 0.05 * fbm(W, H, 700 * f, p["seed"] + 3, 2)  # uneven illumination
    bright = field + delta
    dark = 0.05 + 2.4 * np.abs(delta) + 0.03 * fbm(W, H, 700 * f, p["seed"] + 4, 2)
    tone = bright * (1 - p["pz_dark"]) + dark * p["pz_dark"]
    if p["pz_scope"] > 0:  # the field stop: a circle, hard at the edge, a little vignette inside
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        r = np.hypot(xx - W / 2, yy - H / 2) / (0.5 * np.hypot(W, H))
        R = 1.0 - 0.45 * p["pz_scope"]
        vig = 1 - 0.25 * p["pz_scope"] * (r / R) ** 2
        tone = tone * vig * smoothstep(R, R - 0.006, r)
    return lut[(np.clip(tone, 0, 1) * 1023).astype(np.int32)].astype(np.uint8)
