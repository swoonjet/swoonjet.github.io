"""Protozoa in solution: a drop of pond water on a slide, under the microscope.

The process (what the eye at the eyepiece is given):

  culture  a population: ciliates (slipper-shaped, an oral groove, a fringe of cilia),
           amoebae (a blob pushing out pseudopods, granular inside, a clear rim) and diatoms
           (glass boats with a central slit and fine ribs); bacteria and debris everywhere
  current  they lie along the way the water moves: the strokes, or slow eddies
  depth    each sits at its own depth in the drop; the objective focuses one thin plane, so
           everything else softens the further it is from it (drawn to four depth layers,
           each layer blurred by its distance from focus)
  optics   phase contrast puts a bright halo round every edge; the field is lit unevenly and
           the field stop can show as a circle; dark field turns it inside out (edges glow)

Everything is drawn as signed distances in each organism's own frame (u along, v across).
fields() returns the change each layer makes to the bright field; colour() lights the slide.
"""
import cv2
import numpy as np

from fields import Vortices, blur, deposit, fbm, smoothstep, strokes_sample

KEYS = ("pz_count", "pz_size", "pz_debris", "pz_focus", "pz_dof", "pz_halo")
COLOUR_KEYS = ("pz_scope", "pz_dark")
DEPTHS = np.array([-0.75, -0.25, 0.25, 0.75])


def _organism(kind, L, rng, f, halo):
    """One cell as a patch of tone change (negative = darker than the medium), in its own frame."""
    R = int(L * 0.95) + int(10 * f)
    u, v = np.meshgrid(np.arange(-R, R + 1, dtype=np.float32), np.arange(-R, R + 1, dtype=np.float32))
    w = 1.3 * f
    if kind == "ciliate":
        a, b = L / 2, L * 0.21
        b_u = b * (1 - 0.18 * u / a)  # narrower at the front
        q = np.sqrt((u / a) ** 2 + (v / b_u) ** 2)
        d = (q - 1) * b
        d += 0.45 * b * np.exp(-((u - 0.1 * a) / (0.35 * a)) ** 2 - ((v - 0.85 * b) / (0.45 * b)) ** 2)  # oral groove
        ang = np.arctan2(v / b, u / a)
        n = int(np.pi * (a + b) / (3.2 * f))
        cilia = np.cos(n * ang / 2) ** 16 * np.exp(-np.clip(d, 0, None) / (5 * f)) * (d > 0)
        inside = -0.09
        nuc = (u / (0.22 * a)) ** 2 + ((v + 0.1 * b) / (0.45 * b)) ** 2
        extra = -0.12 * smoothstep(1.2, 0.6, nuc)
        for su in (-0.7, 0.62):  # contractile vacuoles near each end: clear, rimmed
            cv = np.hypot(u - su * a, v + 0.2 * b) / (0.16 * b + 1.5 * f)
            extra += 0.10 * (cv < 1) - 0.10 * np.exp(-((cv - 1) / 0.15) ** 2)
        gran = 0.35
    elif kind == "amoeba":
        r0 = L * 0.33
        rho, th = np.hypot(u, v), np.arctan2(v, u)
        rr = r0 * (1 + sum(rng.uniform(0, 0.12 / k) * np.cos(k * th + rng.uniform(0, 6.3)) for k in range(2, 7)))
        for _ in range(rng.integers(2, 5)):  # pseudopods
            at = rng.uniform(-np.pi, np.pi)
            dth = np.angle(np.exp(1j * (th - at)))
            rr = rr + r0 * rng.uniform(0.4, 0.9) * np.exp(-(dth / rng.uniform(0.18, 0.35)) ** 2)
        d = rho - rr
        inside = -0.05 - 0.07 * smoothstep(-0.25 * r0, -0.5 * r0, d)  # clear rim, grainy middle
        nx, ny = rng.uniform(-0.25, 0.25, 2) * r0
        extra = -0.13 * smoothstep(1.2, 0.6, np.hypot(u - nx, v - ny) / (0.22 * r0))
        cvx, cvy = rng.uniform(-0.4, 0.4, 2) * r0
        cv = np.hypot(u - cvx, v - cvy) / (0.14 * r0)
        extra += 0.09 * (cv < 1) - 0.09 * np.exp(-((cv - 1) / 0.15) ** 2)
        gran = 0.55
        cilia = 0
    else:  # diatom: a glass boat, central slit and ribs
        a, b = L * 0.55, L * 0.11
        q = (np.abs(u / a) ** 2.3 + np.abs(v / b) ** 2.3) ** (1 / 2.3)
        d = (q - 1) * b
        ribs = 0.5 + 0.5 * np.cos(2 * np.pi * u / (3.0 * f))
        inside = 0.04 - 0.06 * ribs * smoothstep(0.2 * b, 0.45 * b, np.abs(v))
        extra = -0.18 * np.exp(-(v / (0.9 * f)) ** 2) * (np.abs(u) < 0.85 * a)  # the raphe
        extra += -0.1 * np.exp(-(np.hypot(u, v) / (0.12 * b + f)) ** 2)  # central nodule
        gran = 0.0
        cilia = 0
        w = 1.8 * f
    body = smoothstep(w, -w, d)
    out = body * (inside + extra) - 0.12 * cilia * (1 - body)  # cilia live just outside
    if gran:  # granules in the cytoplasm
        g = (rng.random(u.shape) < 0.012 * gran).astype(np.float32)
        out -= 0.25 * blur(g, 0.8 * f) * (0.8 * f) ** 2 * 6.3 * body
    out -= 0.34 * np.exp(-(d / w) ** 2)  # the membrane / frustule edge
    out += halo * 0.2 * np.exp(-np.clip(d, 0, None) / (4.5 * f)) * (d > w)  # phase-contrast halo
    return (1.5 * out).astype(np.float32), R


def _paste(layer, patch, cx, cy, th):
    """Rotate the patch by th and add it centred at (cx, cy)."""
    R = patch.shape[0] // 2
    M = cv2.getRotationMatrix2D((R, R), -np.degrees(th), 1.0)
    rot = cv2.warpAffine(patch, M, patch.shape[::-1], flags=cv2.INTER_LINEAR, borderValue=0)
    H, W = layer.shape
    x0, y0 = int(cx) - R, int(cy) - R
    a0, b0 = max(0, x0), max(0, y0)
    a1, b1 = min(W, x0 + patch.shape[1]), min(H, y0 + patch.shape[0])
    if a0 < a1 and b0 < b1:
        layer[b0:b1, a0:a1] += rot[b0 - y0:b1 - y0, a0 - x0:a1 - x0]


def fields(p, W, H, f, geo):
    rng = np.random.default_rng(p["seed"] * 7919 + 71)
    layers = np.zeros((len(DEPTHS), H, W), np.float32)
    n = int(p["pz_count"])
    if geo is None:
        fld = Vortices(rng, W, H, 4)
        xy = np.stack([rng.uniform(0, W, n), rng.uniform(0, H, n)], 1)
        vx, vy = fld(xy[:, 0], xy[:, 1])
        ths = np.arctan2(vy, vx)
    else:
        xy, ths = strokes_sample(geo, n, rng, 0.8)
    kinds = rng.choice(["ciliate", "amoeba", "diatom"], n, p=[0.45, 0.3, 0.25])
    zs = rng.uniform(-1, 1, n)
    order = np.argsort(-np.abs(zs - p["pz_focus"]))
    for i in order:
        L = p["pz_size"] * f * rng.uniform(140, 300) * (0.6 if kinds[i] == "diatom" else 1)
        patch, _ = _organism(kinds[i], L, rng, f, p["pz_halo"])
        b = int(np.argmin(np.abs(DEPTHS - zs[i])))
        _paste(layers[b], patch, xy[i, 0], xy[i, 1], ths[i] + rng.normal(0, 0.25))

    # bacteria and debris: tiny rods and specks at every depth
    m = int(p["pz_debris"] * W * H / (f * f) / 260)
    for b in range(len(DEPTHS)):
        k = m // len(DEPTHS)
        x, y = rng.uniform(0, W, k), rng.uniform(0, H, k)
        a = rng.uniform(0, np.pi, k)
        dots = np.zeros((H, W), np.float32)
        for s in (-1.5, 0, 1.5):  # three points make a rod
            deposit(dots, x + s * f * np.cos(a), y + s * f * np.sin(a), rng.uniform(0.6, 1.4, k) * 0.15)
        layers[b] -= blur(dots, 0.9 * f) * (0.9 * f) ** 2 * 6.3

    # depth of field: blur each layer by its distance from the focal plane
    out = np.zeros((H, W), np.float32)
    for b, z in enumerate(DEPTHS):
        out += blur(layers[b], 0.4 * f + p["pz_dof"] * abs(z - p["pz_focus"]) * 9 * f)
    return out


def colour(p, delta, lut, light, f):
    H, W = delta.shape
    field = 0.8 + 0.05 * fbm(W, H, 700 * f, p["seed"] + 3, 2)  # uneven illumination
    bright = field + delta
    dark = 0.05 + 2.4 * np.abs(delta) + 0.03 * fbm(W, H, 700 * f, p["seed"] + 4, 2)
    tone = bright * (1 - p["pz_dark"]) + dark * p["pz_dark"]
    if p["pz_scope"] > 0:  # the field stop: a circle, hard at the edge, a little vignette inside
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        r = np.hypot(xx - W / 2, yy - H / 2) / (0.5 * np.hypot(W, H))
        R = 1.0 - 0.45 * p["pz_scope"]
        vig = 1 - 0.25 * p["pz_scope"] * (r / R) ** 2
        tone = tone * vig * smoothstep(R, R - 0.006, r)
    return lut[(np.clip(tone, 0, 1) * 1023).astype(np.int32)].astype(np.uint8)
